------------------------------------------------------------
-- AccionesOK
-- Casos que prueban las acciones de referencia
------------------------------------------------------------

------------------------------------------------------------
-- 1. PERSONA → USUARIO / ESPECIALISTA (CASCADE)
------------------------------------------------------------

INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
VALUES (90010001, 'Persona Cascade', 'p1@x.com', 'pass', 'Usuario');

INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo,
                      peso, altura, fecha_inicio_membresia, membresia_activa, fecha_fin_membresia)
VALUES (90010001, 'Meta', 'Básico', 2, 25, 'M', 70, 1.75, DATE '2024-01-01', '0', NULL);

INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
VALUES (90010002, 'Especialista Cascade', 'esp@x.com', 'pass', 'Especialista');

INSERT INTO EspecialistasFitness (id_persona, especialidad)
VALUES (90010002, 'Fuerza');

------------------------------------------------------------
-- 2. PLAN FITNESS Y SUS ENTIDADES RELACIONADAS (CASCADE)
------------------------------------------------------------

INSERT INTO PlanesFitness (id_plan, nombre, descripcion)
VALUES (90020001, 'Plan Cascade', 'Plan de prueba');

INSERT INTO PlanesFitnessDeUsuarios (id, usuario, planfitness)
VALUES (90030001, 90010001, 90020001);

INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion, dias_semana,
                     duracion_rutina_min, nivel_dificultad, tipo_entrenamiento)
VALUES (90040001, 90020001, 'Rutina Cascade', 'Test', 3, 30, 'Básico', 'Fuerza');

INSERT INTO Comidas (id_comida, planfitness, nombre_comida, descripcion)
VALUES (90050001, 90020001, 'Comida Cascade', 'Comida test');

INSERT INTO Habitos (id_habito, planfitness, nombre_habito, descripcion)
VALUES (90060001, 90020001, 'Habito Cascade', 'Hábito test');

INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones,
                        descripcion, duracion_min)
VALUES (90070001, 90040001, 'Ejercicio Cascade', 3, 10, 'Desc', NULL);

------------------------------------------------------------
-- 3. FEEDBACKS (CASCADE)
------------------------------------------------------------

INSERT INTO Feedbacks (id_feedback, usuario, comentario)
VALUES (90080001, 90010001, 'Buen plan');

------------------------------------------------------------
-- 4. OBJETIVOS / RECOMENDACIONES / OBJ-REC (CASCADE)
------------------------------------------------------------

INSERT INTO Objetivos (id_objetivo, usuario, descripcion)
VALUES (90090001, 90010001, 'Objetivo Cascade');

INSERT INTO Recomendaciones (id_recomendacion, especialista_fitness, descripcion)
VALUES (90090002, 90010002, 'Recomendación Cascade');

INSERT INTO ObjetivosRecomendaciones (id_objetivo, id_recomendacion)
VALUES (90090001, 90090002);

------------------------------------------------------------
-- 5. RUTINAS DE EJEMPLO (SET NULL) Y SUS EJERCICIOS (CASCADE)
------------------------------------------------------------

INSERT INTO RutinasDeEjemplo (id_rutina_ejemplo, especialista_fitness,
                              nombre_rutina, descripcion)
VALUES (90100001, 90010002, 'Rutina Ejemplo Cascade', 'Test ejemplo');

INSERT INTO EjerciciosDeRutinasDeEjemplo (id_ejercicio_ejemplo, id_rutina_ejemplo,
                                          nombre_ejercicio, series, repeticiones)
VALUES (90110001, 90100001, 'Ejercicio Ejemplo Cascade', 3, 10);

------------------------------------------------------------
-- PRUEBAS DE ACCIONES
------------------------------------------------------------

-- 1. Eliminar Usuario → elimina: Usuarios, Feedbacks, Objetivos, PlanesFitnessDeUsuarios
DELETE FROM Personas WHERE id_persona = 90010001;

-- 2. Eliminar Especialista → elimina Recomendaciones, deja NULL en RutinasDeEjemplo
DELETE FROM Personas WHERE id_persona = 90010002;

-- 3. Eliminar PlanFitness → elimina: Rutinas, Comidas, Habitos, PlanesUsuarios
DELETE FROM PlanesFitness WHERE id_plan = 90020001;

-- 4. Eliminar RutinaEjemplo → elimina EjerciciosDeRutinasDeEjemplo
DELETE FROM RutinasDeEjemplo WHERE id_rutina_ejemplo = 90100001;

COMMIT;
