------------------------------------------------------------
-- TUPLAS NO OK
-- Inserciones que VIOLAN las restricciones de tuplas
------------------------------------------------------------


------------------------------------------------------------
-- TABLA USUARIOS:
-- Violación de ck_usuario_membresia
-- membresia_activa = '1' PERO fecha_fin_membresia <= fecha_inicio_membresia
------------------------------------------------------------

INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
VALUES (90000001, 'Usuario Invalidado', 'badmem@x.com', 'pass123', 'Usuario');

INSERT INTO Usuarios (
    id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo,
    peso, altura, fecha_inicio_membresia, membresia_activa, fecha_fin_membresia
)
VALUES (
    90000001, 'Meta Incorrecta', 'Básico', 2, 30, 'M',
    70, 1.75, DATE '2024-06-01', '1', DATE '2024-01-01'
);


------------------------------------------------------------
-- TABLA RUTINAS:
-- Violación de ck_rutina_nivel_dias
-- nivel_dificultad definido PERO dias_semana = NULL
------------------------------------------------------------

INSERT INTO Rutinas (
    id_rutina, planfitness, nombre_rutina, descripcion, dias_semana,
    duracion_rutina_min, nivel_dificultad, tipo_entrenamiento
)
VALUES (
    90000002, 90000002, 'Rutina Invalidada', 'Nivel sin días definidos',
    NULL, 30, 'Intermedio', 'Fuerza'
);


------------------------------------------------------------
-- TABLA EJERCICIOS:
-- Violación de ck_ejercicio_series_rep_duracion
-- No coincide con ninguna de las tres combinaciones permitidas
------------------------------------------------------------

-- Caso A inválido: series ≠ NULL, repeticiones = NULL, duracion_min = NULL
INSERT INTO Ejercicios (
    id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones,
    descripcion, duracion_min
)
VALUES (
    90000003, 90000002, 'Ejercicio A Inválido', 3, NULL,
    'Ni repeticiones ni duración', NULL
);

-- Caso B inválido: series = NULL, repeticiones ≠ NULL, duracion_min = NULL
INSERT INTO Ejercicios (
    id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones,
    descripcion, duracion_min
)
VALUES (
    90000004, 90000002, 'Ejercicio B Inválido', NULL, 10,
    'Rango incompleto', NULL
);

-- Caso C inválido: series = NULL, repeticiones = NULL, duracion_min = NULL
INSERT INTO Ejercicios (
    id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones,
    descripcion, duracion_min
)
VALUES (
    90000005, 90000002, 'Ejercicio C Inválido', NULL, NULL,
    'Sin parámetros', NULL
);

commit;




