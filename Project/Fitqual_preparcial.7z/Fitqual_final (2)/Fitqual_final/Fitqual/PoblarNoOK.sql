-- POBLARNOOK.sql - 60 CASOS DE PRUEBA
-- Intentos de inserción de datos erróneos que deben ser rechazados por las restricciones
-- IDs altos (999xxx) para evitar conflictos con datos existentes

----------------------------
-- VIOLACIONES TABLA PERSONAS (4 casos)
----------------------------

-- 1. Violación rol no válido
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999001, 'Juan Error', 'juan@error999.com', 'pass123', 'Administrador'); 
-- Error esperado: ORA-02290 - rol debe ser 'Usuario' o 'EspecialistaFitness'

-- 2. Violación correo duplicado
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999002, 'Ana Duplicado', (SELECT correo FROM Personas WHERE ROWNUM = 1), 'pass123', 'Usuario');
-- Error esperado: ORA-00001 - correo ya existe (viola UK)

-- 3. Violación correo formato incorrecto
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999003, 'Correo Malo', 'correoinvalido', 'pass123', 'Usuario');
-- Error esperado: ORA-02290 - correo debe tener formato válido con @ y .

-- 4. Violación nombre NULL
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999004, NULL, 'noname@test999.com', 'pass123', 'Usuario');
-- Error esperado: ORA-01400 - nombre no puede ser NULL

----------------------------
-- VIOLACIONES TABLA USUARIOS (10 casos)
----------------------------

-- 5. Violación sexo no válido
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999005, 'Perder peso', 'Intermedio', 4, 25, 'X', 70.5, 1.75, DATE '2024-01-01', '1');
-- Error esperado: ORA-02290 - sexo debe ser 'M' o 'F'

-- 6. Violación edad fuera de rango (menor)
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999006, 'Ganar músculo', 'Avanzado', 5, 5, 'M', 80.0, 1.80, DATE '2024-01-01', '1');
-- Error esperado: ORA-02290 - edad debe estar entre 10 y 100

-- 7. Violación edad fuera de rango (mayor)
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999007, 'Mantenerse', 'Básico', 3, 150, 'F', 65.0, 1.65, DATE '2024-01-01', '1');
-- Error esperado: ORA-02290 - edad debe estar entre 10 y 100

-- 8. Violación peso fuera de rango (menor)
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999008, 'Mantenerse', 'Básico', 3, 30, 'F', 10.0, 1.65, DATE '2024-01-01', '1');
-- Error esperado: ORA-02290 - peso debe estar entre 30 y 400 kg

-- 9. Violación altura fuera de rango (menor)
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999010, 'Flexibilidad', 'Intermedio', 2, 28, 'F', 55.0, 0.80, DATE '2024-01-01', '1');
-- Error esperado: ORA-02290 - altura debe estar entre 1.10 y 2.40 m

-- 10. Violación frecuencia fuera de rango
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999012, 'Cardio', 'Básico', 10, 35, 'M', 75.0, 1.78, DATE '2024-01-01', '1');
-- Error esperado: ORA-02290 o ORA-01438 - frecuencia debe estar entre 1 y 7

-- 11. Violación FK - usuario que no existe en Personas
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999999, 'Meta Test', 'Básico', 3, 25, 'M', 70.0, 1.75, DATE '2024-01-01', '1');
-- Error esperado: ORA-02291 - id_persona no existe en Personas

-- 12. Violación nivel no válido
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999014, 'Usuario Nivel', 'nivel999@test.com', 'pass123', 'Usuario');
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999014, 'Meta test', 'Experto', 3, 25, 'M', 70.0, 1.75, DATE '2024-01-01', '1');
-- Error esperado: ORA-02290 - nivel debe ser 'Básico', 'Intermedio', 'Avanzado'
ROLLBACK;

-- 13. Violación nivel NULL
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999015, 'Usuario Sin Nivel', 'sinnivel999@test.com', 'pass123', 'Usuario');
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999015, 'Meta test', NULL, 3, 25, 'M', 70.0, 1.75, DATE '2024-01-01', '1');
-- Error esperado: ORA-01400 - nivel no puede ser NULL
ROLLBACK;

-- 14. Violación membresia_activa no válida
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999013, 'Usuario Membresia', 'membresia999@test.com', 'pass123', 'Usuario');
INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, fecha_inicio_membresia, membresia_activa) 
VALUES (999013, 'Fuerza', 'Intermedio', 4, 40, 'M', 85.0, 1.82, DATE '2024-01-01', '2');
-- Error esperado: ORA-02290 - membresia_activa debe ser '0' o '1'
ROLLBACK;

----------------------------
-- VIOLACIONES TABLA ESPECIALISTASFITNESS (2 casos)
----------------------------

-- 15. Violación consejos_publicados negativo
INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
VALUES (999016, 'Especialista Consejos', 'consejos999@test.com', 'pass123', 'EspecialistaFitness');
INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados) 
VALUES (999016, 'Nutrición', 'Especialista en nutrición', '5 años de experiencia', -5);
-- Error esperado: ORA-02290 - consejos_publicados debe ser >= 0
ROLLBACK;

-- 16. Violación FK - especialista que no existe
INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados) 
VALUES (999999, 'Entrenamiento', 'Descripción', 'Trayectoria', 2);
-- Error esperado: ORA-02291 - id_persona no existe en Personas

----------------------------
-- VIOLACIONES TABLA FEEDBACKS (5 casos)
----------------------------

-- 17. Violación calificación fuera de rango (mayor)
INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
VALUES (999001, 1, 'Contenido de feedback', DATE '2024-03-01', 6, 'Sistema', 'Público');
-- Error esperado: ORA-02290 - calificacion debe estar entre 1 y 5

-- 18. Violación calificación cero
INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
VALUES (999002, 1, 'Contenido de feedback', DATE '2024-03-01', 0, 'Sistema', 'Público');
-- Error esperado: ORA-02290 - calificacion debe estar entre 1 y 5

-- 19. Violación tipo_feedback no válido
INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
VALUES (999003, 1, 'Contenido de feedback', DATE '2024-03-01', 4, 'Nutrición', 'Público');
-- Error esperado: ORA-02290 - tipo_feedback debe ser 'EspecialistaFitness', 'RutinasDeEjemplo', 'Progreso', 'Sistema'

-- 20. Violación FK - usuario que no existe
INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
VALUES (999005, 999999, 'Contenido de feedback', DATE '2024-03-01', 5, 'Sistema', 'Público');
-- Error esperado: ORA-02291 - usuario no existe en Usuarios

-- 21. Violación fecha futura (Trigger)
INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
VALUES (999006, 1, 'Feedback futuro', DATE '2030-12-31', 5, 'Sistema', 'Público');
-- Error esperado: ORA-20002 - fecha no puede ser futura (trigger TR_VALIDAR_FECHA_FEEDBACK)

----------------------------
-- VIOLACIONES TABLA RECOMENDACIONES (2 casos)
----------------------------

-- 22. Violación tipo_enfoque no válido
INSERT INTO Recomendaciones (id_recomendacion, especialista_fitness, contenido, fecha_creacion, tipo_enfoque) 
VALUES (999001, 46, 'Contenido de recomendación', DATE '2024-03-01', 'Suplementación');
-- Error esperado: ORA-02290 - tipo_enfoque debe ser 'Nutrición', 'Entrenamiento', 'Salud mental', 'Descanso', 'Motivación'

-- 23. Violación FK - especialista que no existe
INSERT INTO Recomendaciones (id_recomendacion, especialista_fitness, contenido, fecha_creacion, tipo_enfoque) 
VALUES (999002, 999999, 'Contenido de recomendación', DATE '2024-03-01', 'Nutrición');
-- Error esperado: ORA-02291 - especialista_fitness no existe en EspecialistasFitness

----------------------------
-- VIOLACIONES TABLA OBJETIVOS (2 casos)
----------------------------

-- 24. Violación fecha futura (Trigger)
INSERT INTO Objetivos (id_objetivo, usuario, nombre, contenido, fecha_creacion) 
VALUES (999001, 1, 'Objetivo futuro', 'Contenido', DATE '2030-01-01');
-- Error esperado: ORA-20003 - fecha_creacion no puede ser futura (trigger TR_VALIDAR_FECHA_OBJETIVO)

-- 25. Violación FK - usuario que no existe
INSERT INTO Objetivos (id_objetivo, usuario, nombre, contenido, fecha_creacion) 
VALUES (999002, 999999, 'Objetivo Test', 'Contenido', DATE '2024-03-01');
-- Error esperado: ORA-02291 - usuario no existe en Usuarios

----------------------------
-- VIOLACIONES TABLA PROGRESOS (3 casos)
----------------------------

-- 26. Violación peso_actual fuera de rango (menor)
INSERT INTO Progresos (id_progreso, usuario, peso_actual, medidas, porcentaje_grasa, fecha_registro) 
VALUES (999001, 1, 10.5, 'Cintura: 80cm', 20.5, DATE '2024-03-01');
-- Error esperado: ORA-02290 - peso_actual debe estar entre 30 y 300 kg

-- 27. Violación porcentaje_grasa fuera de rango (mayor)
INSERT INTO Progresos (id_progreso, usuario, peso_actual, medidas, porcentaje_grasa, fecha_registro) 
VALUES (999003, 1, 75.5, 'Cintura: 82cm', 150.5, DATE '2024-03-01');
-- Error esperado: ORA-02290 - porcentaje_grasa debe estar entre 0 y 100

-- 28. Violación fecha futura (Trigger)
INSERT INTO Progresos (id_progreso, usuario, peso_actual, medidas, porcentaje_grasa, imc, fecha_registro) 
VALUES (999005, 1, 75.0, 'Medidas', 20.0, 24.5, DATE '2030-01-01');
-- Error esperado: ORA-20004 - fecha_registro no puede ser futura (trigger TR_VALIDAR_FECHA_PROGRESO)

----------------------------
-- VIOLACIONES TABLA PLANESFITNESS (2 casos)
----------------------------

-- 29. Violación UK - nombre duplicado
INSERT INTO PlanesFitness (id_plan, nombre, duracion, descripcion) 
VALUES (999001, (SELECT nombre FROM PlanesFitness WHERE ROWNUM=1), '12 semanas', 'Plan duplicado');
-- Error esperado: ORA-00001 - nombre ya existe (viola UK)

-- 30. Violación formato duración
INSERT INTO PlanesFitness (id_plan, nombre, duracion, descripcion) 
VALUES (999002, 'Plan Formato Malo', '3 años', 'Descripción');
-- Error esperado: ORA-02290 - duracion debe contener 'semanas', 'meses' o 'días'

----------------------------
-- VIOLACIONES TABLA RUTINAS (4 casos)
----------------------------

-- 31. Violación duracion_rutina_min fuera de rango
INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion, dias_semana, duracion_rutina_min, nivel_dificultad, tipo_entrenamiento) 
VALUES (999001, 1, 'Rutina Extrema', 'Descripción de rutina', 'Lunes, Miércoles', 600, 'Intermedio', 'Fuerza');
-- Error esperado: ORA-02290 - duracion_rutina_min debe estar entre 1 y 500

-- 32. Violación nivel_dificultad no válido
INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion, dias_semana, duracion_rutina_min, nivel_dificultad, tipo_entrenamiento) 
VALUES (999002, 1, 'Rutina Experimental', 'Descripción de rutina', 'Martes, Jueves', 45, 'Extremo', 'Fuerza');
-- Error esperado: ORA-02290 - nivel_dificultad debe ser 'Básico', 'Intermedio', 'Avanzado' o NULL

-- 33. Violación UK - nombre duplicado en mismo plan
INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion, dias_semana, duracion_rutina_min, nivel_dificultad, tipo_entrenamiento) 
VALUES (999004, 
    (SELECT planfitness FROM Rutinas WHERE ROWNUM=1), 
    (SELECT nombre_rutina FROM Rutinas WHERE ROWNUM=1),
    'Otra descripción', 'Lunes, Viernes', 50, 'Básico', 'Fuerza');
-- Error esperado: ORA-00001 - nombre_rutina ya existe para este planfitness

-- 34. Violación FK - plan que no existe
INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion, dias_semana, duracion_rutina_min, nivel_dificultad, tipo_entrenamiento) 
VALUES (999005, 999999, 'Rutina Fantasma', 'Descripción', 'Lunes', 45, 'Básico', 'Fuerza');
-- Error esperado: ORA-02291 - planfitness no existe en PlanesFitness

----------------------------
-- VIOLACIONES TABLA COMIDAS (4 casos)
----------------------------

-- 35. Violación calorías fuera de rango
INSERT INTO Comidas (id_comida, planfitness, nombre_comida, calorias, carbohidratos, grasas, proteinas) 
VALUES (999001, 1, 'Comida Extrema', 5000, 100.0, 50.0, 80.0);
-- Error esperado: ORA-02290 - calorias debe estar entre 0 y 3000

-- 36. Violación carbohidratos negativo
INSERT INTO Comidas (id_comida, planfitness, nombre_comida, calorias, carbohidratos, grasas, proteinas) 
VALUES (999002, 1, 'Comida Negativa', 500, -10.0, 20.0, 30.0);
-- Error esperado: ORA-02290 - carbohidratos debe ser >= 0

-- 37. Violación UK - nombre duplicado en mismo plan
INSERT INTO Comidas (id_comida, planfitness, nombre_comida, calorias, carbohidratos, grasas, proteinas) 
VALUES (999005,
    (SELECT planfitness FROM Comidas WHERE ROWNUM=1),
    (SELECT nombre_comida FROM Comidas WHERE ROWNUM=1),
    350, 25.0, 12.0, 35.0);
-- Error esperado: ORA-00001 - nombre_comida ya existe para este planfitness

-- 38. Violación FK - plan que no existe
INSERT INTO Comidas (id_comida, planfitness, nombre_comida, calorias, carbohidratos, grasas, proteinas) 
VALUES (999006, 999999, 'Comida Fantasma', 500, 50.0, 20.0, 30.0);
-- Error esperado: ORA-02291 - planfitness no existe en PlanesFitness

----------------------------
-- VIOLACIONES TABLA HABITOS (2 casos)
----------------------------

-- 39. Violación frecuencia formato incorrecto
INSERT INTO Habitos (id_habito, planfitness, nombre_habito, descripcion, frecuencia) 
VALUES (999001, 1, 'Hábito Test', 'Descripción', 'Cuando quieras');
-- Error esperado: ORA-02290 - frecuencia debe contener 'diario', 'semana', 'mes', 'sesión' o 'dia'

-- 40. Violación UK - nombre duplicado en mismo plan
INSERT INTO Habitos (id_habito, planfitness, nombre_habito, descripcion, frecuencia) 
VALUES (999002,
    (SELECT planfitness FROM Habitos WHERE ROWNUM=1),
    (SELECT nombre_habito FROM Habitos WHERE ROWNUM=1),
    'Otra descripción', 'Diario');
-- Error esperado: ORA-00001 - nombre_habito ya existe para este planfitness

----------------------------
-- VIOLACIONES TABLA EJERCICIOS (4 casos)
----------------------------

-- 41. Violación series cero
INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones, descripcion, duracion_min) 
VALUES (9991, 1, 'Ejercicio Error', 0, 10, 'Descripción', NULL);
-- Error esperado: ORA-02290 - series debe ser > 0 o NULL

-- 42. Violación repeticiones cero
INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones, descripcion, duracion_min) 
VALUES (9992, 1, 'Ejercicio Error 2', 3, 0, 'Descripción', NULL);
-- Error esperado: ORA-02290 - repeticiones debe ser > 0 o NULL

-- 43. Violación restricción series-repeticiones-duración
INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones, descripcion, duracion_min) 
VALUES (9994, 1, 'Ejercicio Incoherente', 3, 10, 'Descripción', 30);
-- Error esperado: ORA-02290 - CK_EJERCICIO_SERIES_REP_DURACION (no cumple la combinación permitida)

-- 44. Violación FK - rutina que no existe
INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones, descripcion, duracion_min) 
VALUES (9995, 999999, 'Ejercicio Fantasma', 3, 10, 'Descripción', NULL);
-- Error esperado: ORA-02291 - id_rutina no existe en Rutinas

----------------------------
-- VIOLACIONES TABLA RUTINASDEEJEMPLO (4 casos)
----------------------------

-- 45. Violación duracion_rutina fuera de rango
INSERT INTO RutinasDeEjemplo (id_rutina_ejemplo, especialista_fitness, nombre_rutina, descripcion, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento) 
VALUES (999001, 46, 'Rutina Larga', 'Descripción', 'Lunes a Viernes', 600, 'Intermedio', 'Fuerza');
-- Error esperado: ORA-02290 - duracion_rutina debe estar entre 1 y 500

-- 46. Violación nivel_dificultad no válido
INSERT INTO RutinasDeEjemplo (id_rutina_ejemplo, especialista_fitness, nombre_rutina, descripcion, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento) 
VALUES (999002, 46, 'Rutina Experimental', 'Descripción', 'Lunes, Miércoles', 45, 'Principiante', 'Fuerza');
-- Error esperado: ORA-02290 - nivel_dificultad debe ser 'Básico', 'Intermedio', 'Avanzado'

-- 47. Violación UK - nombre duplicado para mismo especialista
INSERT INTO RutinasDeEjemplo (id_rutina_ejemplo, especialista_fitness, nombre_rutina, descripcion, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento) 
VALUES (999004, 
    (SELECT especialista_fitness FROM RutinasDeEjemplo WHERE ROWNUM=1),
    (SELECT nombre_rutina FROM RutinasDeEjemplo WHERE ROWNUM=1),
    'Otra descripción', 'Lunes, Viernes', 50, 'Intermedio', 'Fuerza');
-- Error esperado: ORA-00001 - nombre_rutina ya existe para este especialista_fitness

-- 48. Violación FK - especialista que no existe
INSERT INTO RutinasDeEjemplo (id_rutina_ejemplo, especialista_fitness, nombre_rutina, descripcion, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento) 
VALUES (999006, 999999, 'Rutina Fantasma', 'Descripción', 'Lunes', 45, 'Básico', 'Fuerza');
-- Error esperado: ORA-02291 - especialista_fitness no existe en EspecialistasFitness

----------------------------
-- VIOLACIONES TABLA EJERCICIOSDERUTINASDEEJEMPLO (3 casos)
----------------------------

-- 49. Violación series cero
INSERT INTO EjerciciosDeRutinasDeEjemplo (id_ejercicio_ejemplo, id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, descripcion, duracion_min) 
VALUES (9991, 1, 'Ejercicio Error', 0, 10, 'Descripción', 5);
-- Error esperado: ORA-02290 - series debe ser > 0

-- 50. Violación repeticiones cero
INSERT INTO EjerciciosDeRutinasDeEjemplo (id_ejercicio_ejemplo, id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, descripcion, duracion_min) 
VALUES (9992, 1, 'Ejercicio Error 2', 3, 0, 'Descripción', 5);
-- Error esperado: ORA-02290 - repeticiones debe ser > 0

-- 51. Violación FK - rutina_ejemplo que no existe
INSERT INTO EjerciciosDeRutinasDeEjemplo (id_ejercicio_ejemplo, id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, descripcion, duracion_min) 
VALUES (9994, 999999, 'Ejercicio Fantasma', 3, 10, 'Descripción', 5);
-- Error esperado: ORA-02291 - id_rutina_ejemplo no existe en RutinasDeEjemplo

----------------------------
-- VIOLACIONES TABLAS INTERMEDIAS (4 casos)
----------------------------

-- 52. Violación PK duplicada en PlanesFitnessDeUsuarios
INSERT INTO PlanesFitnessDeUsuarios (usuario, planfitness, comentario_usuario) 
VALUES (
    (SELECT usuario FROM PlanesFitnessDeUsuarios WHERE ROWNUM=1),
    (SELECT planfitness FROM PlanesFitnessDeUsuarios WHERE ROWNUM=1),
    'Comentario duplicado'
);
-- Error esperado: ORA-00001 - ya existe la combinación usuario+planfitness (viola PK)

-- 53. Violación FK usuario en PlanesFitnessDeUsuarios
INSERT INTO PlanesFitnessDeUsuarios (usuario, planfitness, comentario_usuario) 
VALUES (999999, 1, 'Usuario inexistente');
-- Error esperado: ORA-02291 - usuario no existe en Usuarios

-- 54. Violación PK duplicada en ObjetivosRecomendaciones
INSERT INTO ObjetivosRecomendaciones (id_recomendacion, id_objetivo) 
VALUES (
    (SELECT id_recomendacion FROM ObjetivosRecomendaciones WHERE ROWNUM=1),
    (SELECT id_objetivo FROM ObjetivosRecomendaciones WHERE ROWNUM=1)
);
-- Error esperado: ORA-00001 - ya existe la combinación id_recomendacion+id_objetivo (viola PK)

-- 55. Violación FK recomendacion en ObjetivosRecomendaciones
INSERT INTO ObjetivosRecomendaciones (id_recomendacion, id_objetivo) 
VALUES (999999, 1);
-- Error esperado: ORA-02291 - id_recomendacion no existe en Recomendaciones

----------------------------
-- VIOLACIONES DE INTEGRIDAD REFERENCIAL - DELETE CASCADE (3 casos)
----------------------------

-- 56. Intentar eliminar persona que es Usuario (debería permitirse con CASCADE)
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Usuarios WHERE ROWNUM=1;
    IF v_count > 0 THEN
        DELETE FROM Personas WHERE id_persona = (SELECT id_persona FROM Usuarios WHERE ROWNUM=1);
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('CASO 56: DELETE CASCADE funcionó correctamente');
    END IF;
END;
/

-- 57. Intentar eliminar PlanFitness referenciado (debería permitirse con CASCADE)
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM Rutinas WHERE ROWNUM=1;
    IF v_count > 0 THEN
        DELETE FROM PlanesFitness WHERE id_plan = (SELECT planfitness FROM Rutinas WHERE ROWNUM=1);
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('CASO 57: DELETE CASCADE funcionó correctamente');
    END IF;
END;
/

-- 58. Intentar eliminar EspecialistaFitness con RutinasDeEjemplo (SET NULL falla por NOT NULL)
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count 
    FROM RutinasDeEjemplo 
    WHERE especialista_fitness IS NOT NULL 
    AND ROWNUM=1;
    
    IF v_count > 0 THEN
        DELETE FROM EspecialistasFitness 
        WHERE id_persona = (
            SELECT especialista_fitness 
            FROM RutinasDeEjemplo 
            WHERE especialista_fitness IS NOT NULL 
            AND ROWNUM=1
        );
        ROLLBACK;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('CASO 58: Error esperado ORA-01407 - No se puede SET NULL en campo NOT NULL');
END;
/



