/*PK_PERSONAS*/
CREATE OR REPLACE PACKAGE BODY PK_PERSONAS IS 
    PROCEDURE AD_PERSONAS(x_nombre IN VARCHAR2, x_correo IN VARCHAR2, x_contrasena IN VARCHAR2, x_rol IN VARCHAR2) IS 
    BEGIN 
        INSERT INTO Personas(nombre, correo, contrasena, rol) 
        VALUES (x_nombre, x_correo, x_contrasena, x_rol);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN 
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20001, 'Error al insertar en Personas');
    END AD_PERSONAS;

    PROCEDURE MO_PERSONAS(x_id_persona IN NUMBER, x_nombre IN VARCHAR2, x_correo IN VARCHAR2, x_contrasena IN VARCHAR2, x_rol IN VARCHAR2) IS
    BEGIN
        UPDATE Personas 
        SET nombre = x_nombre, correo = x_correo, contrasena = x_contrasena, rol = x_rol 
        WHERE id_persona = x_id_persona;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20002, 'Error al modificar Personas');
    END MO_PERSONAS;

    PROCEDURE DEL_PERSONAS(x_id_persona IN NUMBER) IS
    BEGIN
        DELETE FROM Personas
        WHERE id_persona = x_id_persona;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20003, 'Error al eliminar en Personas');
    END DEL_PERSONAS;
    
    PROCEDURE CO_PERSONAS IS
        cursor_personas SYS_REFCURSOR;
    BEGIN
        OPEN cursor_personas FOR
            SELECT * FROM Personas;
        DBMS_SQL.RETURN_RESULT(cursor_personas);
    END CO_PERSONAS;
    
    FUNCTION CO_MI_HISTORIAL_PROGRESO_FISICO RETURN SYS_REFCURSOR IS
        cursor_progreso SYS_REFCURSOR;
    BEGIN
        OPEN cursor_progreso FOR
            SELECT p.id_progreso, p.peso_actual, p.medidas, p.porcentaje_grasa, p.imc, p.fecha_registro
            FROM Progresos p
            JOIN Usuarios u ON p.usuario = u.id_persona
            ORDER BY p.fecha_registro DESC;
        RETURN cursor_progreso;
    END CO_MI_HISTORIAL_PROGRESO_FISICO;
    
    FUNCTION CO_OBJETIVOS_USUARIOS RETURN SYS_REFCURSOR IS
        cursor_objetivos SYS_REFCURSOR;
    BEGIN
        OPEN cursor_objetivos FOR
            SELECT o.id_objetivo, o.nombre, o.contenido, o.fecha_creacion, u.id_persona
            FROM Objetivos o
            JOIN Usuarios u ON o.usuario = u.id_persona;
        RETURN cursor_objetivos;
    END CO_OBJETIVOS_USUARIOS;
    
    FUNCTION CO_ACTIVIDAD_ESTADO_USUARIOS RETURN SYS_REFCURSOR IS
        cursor_actividad SYS_REFCURSOR;
    BEGIN
        OPEN cursor_actividad FOR
            SELECT u.id_persona, p.nombre, u.membresia_activa, u.fecha_inicio_membresia, u.fecha_fin_membresia, u.frecuencia_entreno_semanal
            FROM Usuarios u
            JOIN Personas p ON u.id_persona = p.id_persona;
        RETURN cursor_actividad;
    END CO_ACTIVIDAD_ESTADO_USUARIOS;

END PK_PERSONAS;
/

/*PK_PLANFITNESS*/
CREATE OR REPLACE PACKAGE BODY PK_PLANFITNESS IS
    PROCEDURE AD_PLANFITNESS(x_nombre IN VARCHAR2, x_duracion IN VARCHAR2, x_descripcion IN VARCHAR2) IS
    BEGIN 
        INSERT INTO PlanesFitness(nombre, duracion, descripcion) 
        VALUES (x_nombre, x_duracion, x_descripcion);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20004, 'Error al insertar en PlanesFitness');
    END AD_PLANFITNESS;
    
    PROCEDURE MO_PLANFITNESS(x_id_plan IN NUMBER, x_nombre IN VARCHAR2, x_duracion IN VARCHAR2, x_descripcion IN VARCHAR2) IS
    BEGIN
        UPDATE PlanesFitness 
        SET nombre = x_nombre, duracion = x_duracion, descripcion = x_descripcion 
        WHERE id_plan = x_id_plan;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'Error al modificar PlanesFitness');
    END MO_PLANFITNESS;
    
    PROCEDURE DEL_PLANFITNESS(x_id_plan IN NUMBER) IS
    BEGIN
        DELETE FROM PlanesFitness
        WHERE id_plan = x_id_plan;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20006, 'Error al eliminar en PlanesFitness');
    END DEL_PLANFITNESS;
    
    PROCEDURE CO_PLANFITNESS IS
        cursor_planes SYS_REFCURSOR;
    BEGIN
        OPEN cursor_planes FOR
            SELECT * FROM PlanesFitness;
        DBMS_SQL.RETURN_RESULT(cursor_planes);
    END CO_PLANFITNESS;
    
    FUNCTION CO_MIS_PLANES_FITNESS RETURN SYS_REFCURSOR IS
        cursor_mis_planes SYS_REFCURSOR;
    BEGIN
        OPEN cursor_mis_planes FOR
            SELECT pf.id_plan, pf.nombre, pf.duracion, pf.descripcion, pfu.comentario_usuario
            FROM PlanesFitness pf
            JOIN PlanesFitnessDeUsuarios pfu ON pf.id_plan = pfu.planfitness;
        RETURN cursor_mis_planes;
    END CO_MIS_PLANES_FITNESS;
    
    FUNCTION CO_PLANES_FITNESS_USUARIOS RETURN SYS_REFCURSOR IS
        cursor_planes_usuarios SYS_REFCURSOR;
    BEGIN
        OPEN cursor_planes_usuarios FOR
            SELECT pf.id_plan, pf.nombre, pfu.usuario, p.nombre AS nombre_usuario
            FROM PlanesFitness pf
            JOIN PlanesFitnessDeUsuarios pfu ON pf.id_plan = pfu.planfitness
            JOIN Personas p ON pfu.usuario = p.id_persona;
        RETURN cursor_planes_usuarios;
    END CO_PLANES_FITNESS_USUARIOS;

END PK_PLANFITNESS;
/

/*PK_ESPECIALISTA_FITNESS*/
CREATE OR REPLACE PACKAGE BODY PK_ESPECIALISTA_FITNESS IS
    PROCEDURE AD_RUTINAS_EJEMPLO(x_especialista_fitness IN NUMBER, x_nombre_rutina IN VARCHAR2, x_descripcion IN VARCHAR2, x_dias_semana IN VARCHAR2, x_duracion_rutina IN NUMBER, x_nivel_dificultad IN VARCHAR2, x_tipo_entrenamiento IN VARCHAR2) IS
    BEGIN 
        INSERT INTO RutinasDeEjemplo(especialista_fitness, nombre_rutina, descripcion, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento) 
        VALUES (x_especialista_fitness, x_nombre_rutina, x_descripcion, x_dias_semana, x_duracion_rutina, x_nivel_dificultad, x_tipo_entrenamiento);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'Error al insertar en RutinasDeEjemplo');
    END AD_RUTINAS_EJEMPLO;
    
    PROCEDURE MO_RUTINAS_EJEMPLO(x_id_rutina_ejemplo IN NUMBER, x_nombre_rutina IN VARCHAR2, x_descripcion IN VARCHAR2, x_dias_semana IN VARCHAR2, x_duracion_rutina IN NUMBER, x_nivel_dificultad IN VARCHAR2, x_tipo_entrenamiento IN VARCHAR2) IS
    BEGIN
        UPDATE RutinasDeEjemplo 
        SET nombre_rutina = x_nombre_rutina, descripcion = x_descripcion, dias_semana = x_dias_semana, 
            duracion_rutina = x_duracion_rutina, nivel_dificultad = x_nivel_dificultad, tipo_entrenamiento = x_tipo_entrenamiento 
        WHERE id_rutina_ejemplo = x_id_rutina_ejemplo;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20008, 'Error al modificar RutinasDeEjemplo');
    END MO_RUTINAS_EJEMPLO;
    
    PROCEDURE DEL_RUTINAS_EJEMPLO(x_id_rutina_ejemplo IN NUMBER) IS
    BEGIN
        DELETE FROM RutinasDeEjemplo
        WHERE id_rutina_ejemplo = x_id_rutina_ejemplo;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20009, 'Error al eliminar en RutinasDeEjemplo');
    END DEL_RUTINAS_EJEMPLO;
    
    PROCEDURE CO_RUTINAS_EJEMPLO IS
        cursor_rutinas SYS_REFCURSOR;
    BEGIN
        OPEN cursor_rutinas FOR
            SELECT * FROM RutinasDeEjemplo;
        DBMS_SQL.RETURN_RESULT(cursor_rutinas);
    END CO_RUTINAS_EJEMPLO;
    
    FUNCTION CO_RUTINAS_EJEMPLO_NIVEL_DIFICULTAD RETURN SYS_REFCURSOR IS
        cursor_rutinas_nivel SYS_REFCURSOR;
    BEGIN
        OPEN cursor_rutinas_nivel FOR
            SELECT re.id_rutina_ejemplo, re.nombre_rutina, re.nivel_dificultad, re.tipo_entrenamiento, re.duracion_rutina
            FROM RutinasDeEjemplo re
            ORDER BY re.nivel_dificultad;
        RETURN cursor_rutinas_nivel;
    END CO_RUTINAS_EJEMPLO_NIVEL_DIFICULTAD;
    
    FUNCTION CO_RECOMENDACIONES_ESPECIALISTAS_FITNESS RETURN SYS_REFCURSOR IS
        cursor_recomendaciones SYS_REFCURSOR;
    BEGIN
        OPEN cursor_recomendaciones FOR
            SELECT r.id_recomendacion, r.contenido, r.tipo_enfoque, r.fecha_creacion, ef.id_persona
            FROM Recomendaciones r
            JOIN EspecialistasFitness ef ON r.especialista_fitness = ef.id_persona;
        RETURN cursor_recomendaciones;
    END CO_RECOMENDACIONES_ESPECIALISTAS_FITNESS;

END PK_ESPECIALISTA_FITNESS;
/

/*PK_OBJETIVOS*/
CREATE OR REPLACE PACKAGE BODY PK_OBJETIVOS IS
    PROCEDURE AD_OBJETIVOS(x_usuario IN NUMBER, x_nombre IN VARCHAR2, x_contenido IN VARCHAR2, x_fecha_creacion IN DATE) IS
    BEGIN 
        INSERT INTO Objetivos(usuario, nombre, contenido, fecha_creacion) 
        VALUES (x_usuario, x_nombre, x_contenido, x_fecha_creacion);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'Error al insertar en Objetivos');
    END AD_OBJETIVOS;
    
    PROCEDURE MO_OBJETIVOS(x_id_objetivo IN NUMBER, x_nombre IN VARCHAR2, x_contenido IN VARCHAR2) IS
    BEGIN
        UPDATE Objetivos 
        SET nombre = x_nombre, contenido = x_contenido 
        WHERE id_objetivo = x_id_objetivo;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'Error al modificar Objetivos');
    END MO_OBJETIVOS;
    
    PROCEDURE DEL_OBJETIVOS(x_id_objetivo IN NUMBER) IS
    BEGIN
        DELETE FROM Objetivos
        WHERE id_objetivo = x_id_objetivo;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20012, 'Error al eliminar en Objetivos');
    END DEL_OBJETIVOS;
    
    PROCEDURE CO_OBJETIVOS IS
        cursor_objetivos SYS_REFCURSOR;
    BEGIN
        OPEN cursor_objetivos FOR
            SELECT * FROM Objetivos;
        DBMS_SQL.RETURN_RESULT(cursor_objetivos);
    END CO_OBJETIVOS;
    
    PROCEDURE AD_RECOMENDACIONES(x_especialista_fitness IN NUMBER, x_contenido IN VARCHAR2, x_fecha_creacion IN DATE, x_tipo_enfoque IN VARCHAR2) IS
    BEGIN 
        INSERT INTO Recomendaciones(especialista_fitness, contenido, fecha_creacion, tipo_enfoque) 
        VALUES (x_especialista_fitness, x_contenido, x_fecha_creacion, x_tipo_enfoque);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20013, 'Error al insertar en Recomendaciones');
    END AD_RECOMENDACIONES;
    
    PROCEDURE MO_RECOMENDACIONES(x_id_recomendacion IN NUMBER, x_contenido IN VARCHAR2, x_fecha_creacion IN DATE, x_tipo_enfoque IN VARCHAR2) IS
    BEGIN
        UPDATE Recomendaciones 
        SET contenido = x_contenido, fecha_creacion = x_fecha_creacion, tipo_enfoque = x_tipo_enfoque 
        WHERE id_recomendacion = x_id_recomendacion;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20014, 'Error al modificar Recomendaciones');
    END MO_RECOMENDACIONES;
    
    PROCEDURE DEL_RECOMENDACIONES(x_id_recomendacion IN NUMBER) IS
    BEGIN
        DELETE FROM Recomendaciones
        WHERE id_recomendacion = x_id_recomendacion;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20015, 'Error al eliminar en Recomendaciones');
    END DEL_RECOMENDACIONES;
    
    PROCEDURE CO_RECOMENDACIONES IS
        cursor_recomendaciones SYS_REFCURSOR;
    BEGIN
        OPEN cursor_recomendaciones FOR
            SELECT * FROM Recomendaciones;
        DBMS_SQL.RETURN_RESULT(cursor_recomendaciones);
    END CO_RECOMENDACIONES;
    
    FUNCTION CO_RECOMENDACIONES_SOBRE_MIS_OBJETIVOS RETURN SYS_REFCURSOR IS
        cursor_recomendaciones_objetivos SYS_REFCURSOR;
    BEGIN
        OPEN cursor_recomendaciones_objetivos FOR
            SELECT r.id_recomendacion, r.contenido, r.tipo_enfoque, o.id_objetivo, o.nombre AS nombre_objetivo
            FROM Recomendaciones r
            JOIN ObjetivosRecomendaciones ore ON r.id_recomendacion = ore.id_recomendacion
            JOIN Objetivos o ON ore.id_objetivo = o.id_objetivo;
        RETURN cursor_recomendaciones_objetivos;
    END CO_RECOMENDACIONES_SOBRE_MIS_OBJETIVOS;
    
    FUNCTION CO_OBJETIVOS_USUARIOS RETURN SYS_REFCURSOR IS
        cursor_objetivos_usuarios SYS_REFCURSOR;
    BEGIN
        OPEN cursor_objetivos_usuarios FOR
            SELECT o.id_objetivo, o.nombre, o.contenido, o.fecha_creacion, u.id_persona
            FROM Objetivos o
            JOIN Usuarios u ON o.usuario = u.id_persona;
        RETURN cursor_objetivos_usuarios;
    END CO_OBJETIVOS_USUARIOS;

END PK_OBJETIVOS;
/