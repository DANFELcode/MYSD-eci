-- --------------
-- ActoresI - CORREGIDO
-- Implementación de los paquetes de actores
-- -------------


-- =====================================================
-- IMPLEMENTACIÓN: PA_GERENTE
-- Rol: Gerente - Acceso a consultas globales y reportes
-- =====================================================
CREATE OR REPLACE PACKAGE BODY PA_GERENTE IS
    
    FUNCTION CO_OBJETIVOS_COMUNES_USUARIOS RETURN SYS_REFCURSOR IS 
        OBJETIVOS SYS_REFCURSOR;
    BEGIN 
        OBJETIVOS := PK_OBJETIVOS.CO_OBJETIVOS_COMUNES_USUARIOS();
        RETURN OBJETIVOS;
    END CO_OBJETIVOS_COMUNES_USUARIOS;
    
    FUNCTION CO_USUARIOS_RENOVARON_MEMBRESIA RETURN SYS_REFCURSOR IS 
        USUARIOS SYS_REFCURSOR;
    BEGIN 
        USUARIOS := PK_PERSONAS.CO_USUARIOS_RENOVARON_MEMBRESIA();
        RETURN USUARIOS;
    END CO_USUARIOS_RENOVARON_MEMBRESIA;
    
    FUNCTION CO_FUNCIONALIDADES_PEOR_CALIFICACION RETURN SYS_REFCURSOR IS 
        FUNCIONALIDADES SYS_REFCURSOR;
    BEGIN 
        FUNCIONALIDADES := PK_PERSONAS.CO_FUNCIONALIDADES_PEOR_CALIFICACION();
        RETURN FUNCIONALIDADES;
    END CO_FUNCIONALIDADES_PEOR_CALIFICACION;
    
    FUNCTION CO_USUARIOS_ACTIVOS_MES RETURN SYS_REFCURSOR IS 
        USUARIOS SYS_REFCURSOR;
    BEGIN 
        USUARIOS := PK_PERSONAS.CO_USUARIOS_ACTIVOS_MES();
        RETURN USUARIOS;
    END CO_USUARIOS_ACTIVOS_MES;
    
    FUNCTION CO_SATISFACCION_GLOBAL_APLICACION RETURN SYS_REFCURSOR IS 
        SATISFACCION SYS_REFCURSOR;
    BEGIN 
        SATISFACCION := PK_PERSONAS.CO_SATISFACCION_GLOBAL_APLICACION();
        RETURN SATISFACCION;
    END CO_SATISFACCION_GLOBAL_APLICACION;
    
END PA_GERENTE;
/

-- =====================================================
-- IMPLEMENTACIÓN: PA_USUARIO - CORREGIDO
-- Rol: Usuario - Gestión de objetivos, planes y consultas
-- IMPORTANTE: Las funciones ahora reciben p_id_usuario como parámetro
-- =====================================================
CREATE OR REPLACE PACKAGE BODY PA_USUARIO IS
    
    -- CRUD de Objetivos
    PROCEDURE AD_OBJETIVOS(Xusuario IN NUMBER, Xnombre IN VARCHAR2, Xcontenido IN VARCHAR2, Xfecha_creacion IN DATE) IS
    BEGIN
        PK_OBJETIVOS.AD_OBJETIVOS(Xusuario, Xnombre, Xcontenido, Xfecha_creacion);
    END AD_OBJETIVOS;
    
    PROCEDURE MO_OBJETIVOS(Xid_objetivo IN NUMBER, Xnombre IN VARCHAR2, Xcontenido IN VARCHAR2) IS
    BEGIN
        PK_OBJETIVOS.MO_OBJETIVOS(Xid_objetivo, Xnombre, Xcontenido);
    END MO_OBJETIVOS;
    
    PROCEDURE DEL_OBJETIVOS(Xid_objetivo IN NUMBER) IS
    BEGIN
        PK_OBJETIVOS.DEL_OBJETIVOS(Xid_objetivo);
    END DEL_OBJETIVOS;
    
    PROCEDURE CO_OBJETIVOS IS
    BEGIN         
        PK_OBJETIVOS.CO_OBJETIVOS();
    END CO_OBJETIVOS;
    
    -- CRUD de Planes Fitness
    PROCEDURE AD_PLANFITNESS(Xnombre IN VARCHAR2, Xduracion IN VARCHAR2, Xdescripcion IN VARCHAR2) IS
    BEGIN
        PK_PLANFITNESS.AD_PLANFITNESS(Xnombre, Xduracion, Xdescripcion);
    END AD_PLANFITNESS;
    
    PROCEDURE MO_PLANFITNESS(Xid_plan IN NUMBER, Xnombre IN VARCHAR2, Xduracion IN VARCHAR2, Xdescripcion IN VARCHAR2) IS
    BEGIN
        PK_PLANFITNESS.MO_PLANFITNESS(Xid_plan, Xnombre, Xduracion, Xdescripcion);
    END MO_PLANFITNESS;
    
    PROCEDURE DEL_PLANFITNESS(Xid_plan IN NUMBER) IS
    BEGIN
        PK_PLANFITNESS.DEL_PLANFITNESS(Xid_plan);
    END DEL_PLANFITNESS;
    
    PROCEDURE CO_PLANFITNESS IS
    BEGIN         
        PK_PLANFITNESS.CO_PLANFITNESS();
    END CO_PLANFITNESS;
    
    -- CORREGIDO: Consultas con parámetro p_id_usuario
    FUNCTION CO_MIS_PLANES_FITNESS(p_id_usuario IN NUMBER) RETURN SYS_REFCURSOR IS 
        PLANES SYS_REFCURSOR;
    BEGIN 
        PLANES := PK_PLANFITNESS.CO_MIS_PLANES_FITNESS(p_id_usuario);
        RETURN PLANES;
    END CO_MIS_PLANES_FITNESS;
    
    FUNCTION CO_MI_HISTORIAL_PROGRESO_FISICO(p_id_usuario IN NUMBER) RETURN SYS_REFCURSOR IS 
        PROGRESO SYS_REFCURSOR;
    BEGIN 
        PROGRESO := PK_PERSONAS.CO_MI_HISTORIAL_PROGRESO_FISICO(p_id_usuario);
        RETURN PROGRESO;
    END CO_MI_HISTORIAL_PROGRESO_FISICO;
    
    FUNCTION CO_RECOMENDACIONES_SOBRE_MIS_OBJETIVOS(p_id_usuario IN NUMBER) RETURN SYS_REFCURSOR IS 
        RECOMENDACIONES SYS_REFCURSOR;
    BEGIN 
        RECOMENDACIONES := PK_OBJETIVOS.CO_RECOMENDACIONES_SOBRE_MIS_OBJETIVOS(p_id_usuario);
        RETURN RECOMENDACIONES;
    END CO_RECOMENDACIONES_SOBRE_MIS_OBJETIVOS;
    
END PA_USUARIO;
/

-- =====================================================
-- IMPLEMENTACIÓN: PA_ADMINISTRADOR_APP
-- Rol: Administrador - Control total del sistema
-- =====================================================
CREATE OR REPLACE PACKAGE BODY PA_ADMINISTRADOR_APP IS
    
    -- CRUD de Personas
    PROCEDURE AD_PERSONAS(Xnombre IN VARCHAR2, Xcorreo IN VARCHAR2, Xcontrasena IN VARCHAR2, Xrol IN VARCHAR2) IS
    BEGIN
        PK_PERSONAS.AD_PERSONAS(Xnombre, Xcorreo, Xcontrasena, Xrol);
    END AD_PERSONAS;
    
    PROCEDURE MO_PERSONAS(Xid_persona IN NUMBER, Xnombre IN VARCHAR2, Xcorreo IN VARCHAR2, Xcontrasena IN VARCHAR2, Xrol IN VARCHAR2) IS
    BEGIN
        PK_PERSONAS.MO_PERSONAS(Xid_persona, Xnombre, Xcorreo, Xcontrasena, Xrol);
    END MO_PERSONAS;
    
    PROCEDURE DEL_PERSONAS(Xid_persona IN NUMBER) IS
    BEGIN
        PK_PERSONAS.DEL_PERSONAS(Xid_persona);
    END DEL_PERSONAS;
    
    PROCEDURE CO_PERSONAS IS
    BEGIN         
        PK_PERSONAS.CO_PERSONAS();
    END CO_PERSONAS;
    
    -- Consultas administrativas
    FUNCTION CO_PLANES_FITNESS_USUARIOS RETURN SYS_REFCURSOR IS 
        PLANES SYS_REFCURSOR;
    BEGIN 
        PLANES := PK_PLANFITNESS.CO_PLANES_FITNESS_USUARIOS();
        RETURN PLANES;
    END CO_PLANES_FITNESS_USUARIOS;
    
    FUNCTION CO_ACTIVIDAD_ESTADO_USUARIOS RETURN SYS_REFCURSOR IS 
        USUARIOS SYS_REFCURSOR;
    BEGIN 
        USUARIOS := PK_PERSONAS.CO_ACTIVIDAD_ESTADO_USUARIOS();
        RETURN USUARIOS;
    END CO_ACTIVIDAD_ESTADO_USUARIOS;
    
    FUNCTION CO_RECOMENDACIONES_ESPECIALISTAS_FITNESS RETURN SYS_REFCURSOR IS 
        RECOMENDACIONES SYS_REFCURSOR;
    BEGIN 
        RECOMENDACIONES := PK_ESPECIALISTA_FITNESS.CO_RECOMENDACIONES_ESPECIALISTAS_FITNESS();
        RETURN RECOMENDACIONES;
    END CO_RECOMENDACIONES_ESPECIALISTAS_FITNESS;
    
END PA_ADMINISTRADOR_APP;
/

-- =====================================================
-- IMPLEMENTACIÓN: PA_ESPECIALISTA_FITNESS
-- Rol: Especialista Fitness - Gestión de recomendaciones y rutinas
-- =====================================================
CREATE OR REPLACE PACKAGE BODY PA_ESPECIALISTA_FITNESS IS
    
    -- CRUD de Recomendaciones
    PROCEDURE AD_RECOMENDACIONES(Xespecialista_fitness IN NUMBER, Xcontenido IN VARCHAR2, Xfecha_creacion IN DATE, Xtipo_enfoque IN VARCHAR2) IS
    BEGIN
        PK_OBJETIVOS.AD_RECOMENDACIONES(Xespecialista_fitness, Xcontenido, Xfecha_creacion, Xtipo_enfoque);
    END AD_RECOMENDACIONES;
    
    PROCEDURE MO_RECOMENDACIONES(Xid_recomendacion IN NUMBER, Xcontenido IN VARCHAR2, Xfecha_creacion IN DATE, Xtipo_enfoque IN VARCHAR2) IS
    BEGIN
        PK_OBJETIVOS.MO_RECOMENDACIONES(Xid_recomendacion, Xcontenido, Xfecha_creacion, Xtipo_enfoque);
    END MO_RECOMENDACIONES;
    
    PROCEDURE DEL_RECOMENDACIONES(Xid_recomendacion IN NUMBER) IS
    BEGIN
        PK_OBJETIVOS.DEL_RECOMENDACIONES(Xid_recomendacion);
    END DEL_RECOMENDACIONES;
    
    PROCEDURE CO_RECOMENDACIONES IS
    BEGIN         
        PK_OBJETIVOS.CO_RECOMENDACIONES();
    END CO_RECOMENDACIONES;
    
    -- CRUD de Rutinas de Ejemplo
    PROCEDURE AD_RUTINAS_EJEMPLO(Xespecialista_fitness IN NUMBER, Xnombre_rutina IN VARCHAR2, Xdescripcion IN VARCHAR2, Xdias_semana IN VARCHAR2, Xduracion_rutina IN NUMBER, Xnivel_dificultad IN VARCHAR2, Xtipo_entrenamiento IN VARCHAR2) IS
    BEGIN
        PK_ESPECIALISTA_FITNESS.AD_RUTINAS_EJEMPLO(Xespecialista_fitness, Xnombre_rutina, Xdescripcion, Xdias_semana, Xduracion_rutina, Xnivel_dificultad, Xtipo_entrenamiento);
    END AD_RUTINAS_EJEMPLO;
    
    PROCEDURE MO_RUTINAS_EJEMPLO(Xid_rutina_ejemplo IN NUMBER, Xnombre_rutina IN VARCHAR2, Xdescripcion IN VARCHAR2, Xdias_semana IN VARCHAR2, Xduracion_rutina IN NUMBER, Xnivel_dificultad IN VARCHAR2, Xtipo_entrenamiento IN VARCHAR2) IS
    BEGIN
        PK_ESPECIALISTA_FITNESS.MO_RUTINAS_EJEMPLO(Xid_rutina_ejemplo, Xnombre_rutina, Xdescripcion, Xdias_semana, Xduracion_rutina, Xnivel_dificultad, Xtipo_entrenamiento);
    END MO_RUTINAS_EJEMPLO;
    
    PROCEDURE DEL_RUTINAS_EJEMPLO(Xid_rutina_ejemplo IN NUMBER) IS
    BEGIN
        PK_ESPECIALISTA_FITNESS.DEL_RUTINAS_EJEMPLO(Xid_rutina_ejemplo);
    END DEL_RUTINAS_EJEMPLO;
    
    PROCEDURE CO_RUTINAS_EJEMPLO IS
    BEGIN         
        PK_ESPECIALISTA_FITNESS.CO_RUTINAS_EJEMPLO();
    END CO_RUTINAS_EJEMPLO;
    
    -- Consultas adicionales
    FUNCTION CO_OBJETIVOS_USUARIOS RETURN SYS_REFCURSOR IS 
        OBJETIVOS SYS_REFCURSOR;
    BEGIN 
        OBJETIVOS := PK_PERSONAS.CO_OBJETIVOS_USUARIOS();
        RETURN OBJETIVOS;
    END CO_OBJETIVOS_USUARIOS;
    
    FUNCTION CO_RUTINAS_EJEMPLO_NIVEL_DIFICULTAD RETURN SYS_REFCURSOR IS 
        RUTINAS SYS_REFCURSOR;
    BEGIN 
        RUTINAS := PK_ESPECIALISTA_FITNESS.CO_RUTINAS_EJEMPLO_NIVEL_DIFICULTAD();
        RETURN RUTINAS;
    END CO_RUTINAS_EJEMPLO_NIVEL_DIFICULTAD;
    
END PA_ESPECIALISTA_FITNESS;
/

COMMIT;