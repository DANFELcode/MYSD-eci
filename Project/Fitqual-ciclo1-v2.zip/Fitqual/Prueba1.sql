--------------------------------------------------------------------------------
-- HISTORIAS DE USO - VERSIÓN FINAL CORREGIDA
--------------------------------------------------------------------------------
SET SERVEROUTPUT ON;

-- =====================================================
-- HISTORIA 1: USUARIO PABLO
-- =====================================================

--------------------------------------------------------------------------------
-- 1. Registrar nuevo usuario Pablo
--------------------------------------------------------------------------------
-- Primero registrar en Personas
EXECUTE PK_PERSONAS.AD_PERSONAS('Pablo', 'pablo.fitqual@gmail.com', 'contra0001', 'Usuario');

-- Crear registro en Usuarios
DECLARE
    v_id_pablo NUMBER;
BEGIN
    SELECT id_persona INTO v_id_pablo 
    FROM Personas 
    WHERE correo = 'pablo.fitqual@gmail.com';
    
    INSERT INTO Usuarios (
        id_persona, nivel, edad, sexo, peso, altura, 
        membresia_activa, frecuencia_entreno_semanal,
        fecha_inicio_membresia, fecha_fin_membresia
    ) VALUES (
        v_id_pablo, 'Básico', 25, 'M', 75.50, 1.75,
        '1', 3, SYSDATE, ADD_MONTHS(SYSDATE, 12)
    );
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Usuario Pablo registrado completamente');
END;
/

-- Verificación
SELECT p.nombre, p.correo, u.nivel, u.edad 
FROM Personas p 
JOIN Usuarios u ON p.id_persona = u.id_persona
WHERE p.correo = 'pablo.fitqual@gmail.com';


--------------------------------------------------------------------------------
-- 2. Pablo modifica su contraseña
--------------------------------------------------------------------------------
DECLARE
    v_id_pablo NUMBER;
BEGIN
    SELECT id_persona INTO v_id_pablo 
    FROM Personas 
    WHERE correo = 'pablo.fitqual@gmail.com';
    
    PK_PERSONAS.MO_PERSONAS(v_id_pablo, 'Pablo', 'pablo.fitqual@gmail.com', 'Perrito4321', 'Usuario');
    DBMS_OUTPUT.PUT_LINE('✓ Contraseña actualizada');
END;
/


--------------------------------------------------------------------------------
-- 3. Se elimina cuenta antigua y se crea una nueva
--------------------------------------------------------------------------------
DECLARE
    v_id_pablo NUMBER;
BEGIN
    SELECT id_persona INTO v_id_pablo 
    FROM Personas 
    WHERE correo = 'pablo.fitqual@gmail.com';
    
    -- Primero eliminar de Usuarios
    DELETE FROM Usuarios WHERE id_persona = v_id_pablo;
    
    -- Luego eliminar de Personas
    PK_PERSONAS.DEL_PERSONAS(v_id_pablo);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Cuenta antigua eliminada');
END;
/

-- Nueva cuenta
EXECUTE PK_PERSONAS.AD_PERSONAS('Pablito', 'pablo.nuevo@gmail.com', 'Perrito555', 'Usuario');

DECLARE
    v_id_pablo NUMBER;
BEGIN
    SELECT id_persona INTO v_id_pablo 
    FROM Personas 
    WHERE correo = 'pablo.nuevo@gmail.com';
    
    INSERT INTO Usuarios (
        id_persona, nivel, edad, sexo, peso, altura, 
        membresia_activa, frecuencia_entreno_semanal,
        fecha_inicio_membresia, fecha_fin_membresia, meta
    ) VALUES (
        v_id_pablo, 'Intermedio', 25, 'M', 76.00, 1.75,
        '1', 4, SYSDATE, ADD_MONTHS(SYSDATE, 12), 
        'Aumentar masa muscular'
    );
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Nueva cuenta creada');
END;
/


--------------------------------------------------------------------------------
-- 4. Pablo crea un plan fitness
--------------------------------------------------------------------------------
EXECUTE PK_PLANFITNESS.AD_PLANFITNESS('Plan Hipertrofia Pablo', '3 meses', 'Plan enfocado en hipertrofia muscular con rutinas intensas y alimentación alta en proteína.');

-- Asociar el plan al usuario
DECLARE
    v_id_pablo NUMBER;
    v_id_plan NUMBER;
BEGIN
    SELECT id_persona INTO v_id_pablo 
    FROM Personas 
    WHERE correo = 'pablo.nuevo@gmail.com';
    
    SELECT id_plan INTO v_id_plan 
    FROM PlanesFitness 
    WHERE nombre = 'Plan Hipertrofia Pablo';
    
    INSERT INTO PlanesFitnessDeUsuarios (usuario, planfitness, comentario_usuario)
    VALUES (v_id_pablo, v_id_plan, 'Mi primer plan de hipertrofia');
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Plan asignado a Pablo');
END;
/


--------------------------------------------------------------------------------
-- 5. Pablo actualiza la duración del plan
--------------------------------------------------------------------------------
DECLARE
    v_id_plan NUMBER;
BEGIN
    SELECT id_plan INTO v_id_plan 
    FROM PlanesFitness 
    WHERE nombre = 'Plan Hipertrofia Pablo';
    
    PK_PLANFITNESS.MO_PLANFITNESS(v_id_plan, 'Plan Hipertrofia Pablo', '5 meses', 'Plan ajustado para hipertrofia progresiva con nuevos ajustes de carga.');
    DBMS_OUTPUT.PUT_LINE('✓ Duración del plan actualizada');
END;
/


--------------------------------------------------------------------------------
-- 6. Crear especialista y rutina de ejemplo
--------------------------------------------------------------------------------
-- Crear especialista si no existe
DECLARE
    v_count NUMBER;
    v_id_especialista NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count 
    FROM Personas 
    WHERE correo = 'juan.trainer@fitqual.com';
    
    IF v_count = 0 THEN
        PK_PERSONAS.AD_PERSONAS('Juan Trainer', 'juan.trainer@fitqual.com', 'Trainer123', 'EspecialistaFitness');
        
        SELECT id_persona INTO v_id_especialista 
        FROM Personas 
        WHERE correo = 'juan.trainer@fitqual.com';
        
        INSERT INTO EspecialistasFitness (
            id_persona, especialidad, descripcion_perfil, 
            trayectoria_profesional, consejos_publicados
        ) VALUES (
            v_id_especialista, 
            'Entrenamiento de fuerza',
            'Especialista en hipertrofia y fuerza',
            '5 años de experiencia en culturismo',
            0
        );
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('✓ Especialista creado');
    END IF;
END;
/

-- Crear rutina de ejemplo
DECLARE
    v_id_especialista NUMBER;
BEGIN
    SELECT id_persona INTO v_id_especialista 
    FROM Personas 
    WHERE correo = 'juan.trainer@fitqual.com';
    
    PK_ESPECIALISTA_FITNESS.AD_RUTINAS_EJEMPLO(
        v_id_especialista,
        'Rutina FullBody intermedia Juan',
        'Rutina diseñada para mejorar fuerza general con énfasis en movimientos compuestos.',
        'Lunes, Miércoles, Viernes',
        60,
        'Intermedio',
        'Fuerza'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Rutina de ejemplo creada');
END;
/


--------------------------------------------------------------------------------
-- 7. Actualizar rutina a versión avanzada
--------------------------------------------------------------------------------
DECLARE
    v_id_rutina NUMBER;
BEGIN
    SELECT id_rutina_ejemplo INTO v_id_rutina
    FROM RutinasDeEjemplo 
    WHERE nombre_rutina = 'Rutina FullBody intermedia Juan';
    
    PK_ESPECIALISTA_FITNESS.MO_RUTINAS_EJEMPLO(
        v_id_rutina,
        'Rutina FullBody avanzada Juan',
        'Rutina optimizada para fuerza máxima y resistencia muscular.',
        'Lunes, Martes, Jueves, Sábado',
        75,
        'Avanzado',
        'Fuerza'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Rutina actualizada a nivel avanzado');
END;
/


--------------------------------------------------------------------------------
-- 8. Pablo establece un objetivo personal
--------------------------------------------------------------------------------
DECLARE
    v_id_pablo NUMBER;
BEGIN
    SELECT id_persona INTO v_id_pablo 
    FROM Personas 
    WHERE correo = 'pablo.nuevo@gmail.com';
    
    PK_OBJETIVOS.AD_OBJETIVOS(
        v_id_pablo,
        'Aumentar fuerza en sentadilla',
        'Incrementar carga en sentadilla de 70 kg a 100 kg para 5 repeticiones',
        SYSDATE
    );
    DBMS_OUTPUT.PUT_LINE('✓ Objetivo creado');
END;
/


--------------------------------------------------------------------------------
-- 9. Especialista crea recomendación
--------------------------------------------------------------------------------
DECLARE
    v_id_especialista NUMBER;
BEGIN
    SELECT id_persona INTO v_id_especialista 
    FROM Personas 
    WHERE correo = 'juan.trainer@fitqual.com';
    
    PK_OBJETIVOS.AD_RECOMENDACIONES(
        v_id_especialista,
        'Consumir 150 g de proteína diaria, mantener superávit calórico de 300 kcal y realizar progresión de cargas semanal.',
        SYSDATE,
        'Nutrición'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Recomendación creada');
END;
/


--------------------------------------------------------------------------------
-- 10. Actualizar objetivo y eliminar recomendación
--------------------------------------------------------------------------------
DECLARE
    v_id_objetivo NUMBER;
    v_id_recomendacion NUMBER;
BEGIN
    SELECT id_objetivo INTO v_id_objetivo 
    FROM Objetivos 
    WHERE nombre = 'Aumentar fuerza en sentadilla'
    AND ROWNUM = 1;
    
    SELECT id_recomendacion INTO v_id_recomendacion 
    FROM Recomendaciones 
    WHERE tipo_enfoque = 'Nutrición'
    AND ROWNUM = 1;
    
    PK_OBJETIVOS.MO_OBJETIVOS(
        v_id_objetivo,
        'Aumentar fuerza en peso muerto',
        'Incrementar peso muerto de 100 kg a 140 kg para 3 repeticiones'
    );
    
    PK_OBJETIVOS.DEL_RECOMENDACIONES(v_id_recomendacion);
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Objetivo actualizado y recomendación eliminada');
END;
/

COMMIT;


-- =====================================================
-- HISTORIA 2: ESPECIALISTA CARLOS
-- =====================================================

--------------------------------------------------------------------------------
-- 1. Registrar especialista Carlos
--------------------------------------------------------------------------------
EXECUTE PK_PERSONAS.AD_PERSONAS('Carlos', 'carlos.especialista@fitqual.com', 'FitXpert001', 'EspecialistaFitness');

DECLARE
    v_id_carlos NUMBER;
BEGIN
    SELECT id_persona INTO v_id_carlos 
    FROM Personas 
    WHERE correo = 'carlos.especialista@fitqual.com';
    
    INSERT INTO EspecialistasFitness (
        id_persona, especialidad, descripcion_perfil, 
        trayectoria_profesional, consejos_publicados
    ) VALUES (
        v_id_carlos,
        'Fitness y nutrición',
        'Especialista en planes personalizados de fitness',
        '10 años de experiencia en el sector',
        0
    );
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Especialista Carlos registrado');
END;
/


--------------------------------------------------------------------------------
-- 2. Carlos actualiza su contraseña
--------------------------------------------------------------------------------
DECLARE
    v_id_carlos NUMBER;
BEGIN
    SELECT id_persona INTO v_id_carlos 
    FROM Personas 
    WHERE correo = 'carlos.especialista@fitqual.com';
    
    PK_PERSONAS.MO_PERSONAS(v_id_carlos, 'Carlos', 'carlos.especialista@fitqual.com', 'StrongPass2025', 'EspecialistaFitness');
    DBMS_OUTPUT.PUT_LINE('✓ Contraseña actualizada');
END;
/


--------------------------------------------------------------------------------
-- 3. Eliminar cuenta antigua y crear nueva
--------------------------------------------------------------------------------
DECLARE
    v_id_carlos NUMBER;
BEGIN
    SELECT id_persona INTO v_id_carlos 
    FROM Personas 
    WHERE correo = 'carlos.especialista@fitqual.com';
    
    DELETE FROM EspecialistasFitness WHERE id_persona = v_id_carlos;
    PK_PERSONAS.DEL_PERSONAS(v_id_carlos);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Cuenta antigua eliminada');
END;
/

-- Nueva cuenta
EXECUTE PK_PERSONAS.AD_PERSONAS('CarlosEF', 'carlos.entrenador.nuevo@gmail.com', 'MuscleMaster55', 'EspecialistaFitness');

DECLARE
    v_id_carlos NUMBER;
BEGIN
    SELECT id_persona INTO v_id_carlos 
    FROM Personas 
    WHERE correo = 'carlos.entrenador.nuevo@gmail.com';
    
    INSERT INTO EspecialistasFitness (
        id_persona, especialidad, descripcion_perfil, 
        trayectoria_profesional, consejos_publicados
    ) VALUES (
        v_id_carlos,
        'Entrenamiento avanzado',
        'Experto en programas de fuerza y potencia',
        '12 años entrenando atletas profesionales',
        0
    );
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Nueva cuenta de Carlos creada');
END;
/


--------------------------------------------------------------------------------
-- 4. Carlos crea un plan de entrenamiento
--------------------------------------------------------------------------------
EXECUTE PK_PLANFITNESS.AD_PLANFITNESS('Plan Fuerza Total Carlos', '8 semanas', 'Programa intensivo de fuerza para progresión continua en ejercicios compuestos.');


--------------------------------------------------------------------------------
-- 5. Ajustar duración del plan
--------------------------------------------------------------------------------
DECLARE
    v_id_plan NUMBER;
BEGIN
    SELECT id_plan INTO v_id_plan 
    FROM PlanesFitness 
    WHERE nombre = 'Plan Fuerza Total Carlos';
    
    PK_PLANFITNESS.MO_PLANFITNESS(v_id_plan, 'Plan Fuerza Total Carlos', '12 semanas', 'Plan optimizado con progresión estructurada y ajustes de carga.');
    DBMS_OUTPUT.PUT_LINE('✓ Duración ajustada');
END;
/


--------------------------------------------------------------------------------
-- 6. Carlos diseña una rutina de ejemplo
--------------------------------------------------------------------------------
DECLARE
    v_id_carlos NUMBER;
BEGIN
    SELECT id_persona INTO v_id_carlos 
    FROM Personas 
    WHERE correo = 'carlos.entrenador.nuevo@gmail.com';
    
    PK_ESPECIALISTA_FITNESS.AD_RUTINAS_EJEMPLO(
        v_id_carlos,
        'Rutina Push Pull Legs Carlos',
        'Entrenamiento estructurado para fuerza, hipertrofia y equilibrio muscular.',
        'Lunes, Miércoles, Viernes, Domingo',
        90,
        'Avanzado',
        'Fuerza'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Rutina creada');
END;
/


--------------------------------------------------------------------------------
-- 7. Actualizar rutina
--------------------------------------------------------------------------------
DECLARE
    v_id_rutina NUMBER;
BEGIN
    SELECT id_rutina_ejemplo INTO v_id_rutina 
    FROM RutinasDeEjemplo 
    WHERE nombre_rutina = 'Rutina Push Pull Legs Carlos';
    
    PK_ESPECIALISTA_FITNESS.MO_RUTINAS_EJEMPLO(
        v_id_rutina,
        'Rutina Push Pull Legs Elite Carlos',
        'Versión avanzada con sobrecarga progresiva y nuevos ejercicios.',
        'Martes, Jueves, Sábado, Domingo',
        100,
        'Avanzado',
        'Fuerza'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Rutina actualizada');
END;
/


--------------------------------------------------------------------------------
-- 8. Carlos registra objetivo para cliente
--------------------------------------------------------------------------------
DECLARE
    v_id_pablo NUMBER;
BEGIN
    SELECT id_persona INTO v_id_pablo 
    FROM Personas 
    WHERE correo = 'pablo.nuevo@gmail.com';
    
    PK_OBJETIVOS.AD_OBJETIVOS(
        v_id_pablo,
        'Mejorar técnica peso muerto',
        'Perfeccionar técnica y aumentar el levantamiento a 180 kg.',
        SYSDATE
    );
    DBMS_OUTPUT.PUT_LINE('✓ Objetivo del cliente creado');
END;
/


--------------------------------------------------------------------------------
-- 9. Carlos crea recomendaciones
--------------------------------------------------------------------------------
DECLARE
    v_id_carlos NUMBER;
BEGIN
    SELECT id_persona INTO v_id_carlos 
    FROM Personas 
    WHERE correo = 'carlos.entrenador.nuevo@gmail.com';
    
    PK_OBJETIVOS.AD_RECOMENDACIONES(
        v_id_carlos,
        'Incluir movilidad lumbar diaria, aumentar ingesta proteica a 180 g, y realizar trabajo accesorio posterior.',
        SYSDATE,
        'Entrenamiento'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Recomendación creada');
END;
/


--------------------------------------------------------------------------------
-- 10. Actualizar objetivo y eliminar recomendación
--------------------------------------------------------------------------------
DECLARE
    v_id_objetivo NUMBER;
    v_id_recomendacion NUMBER;
BEGIN
    SELECT id_objetivo INTO v_id_objetivo 
    FROM Objetivos 
    WHERE nombre = 'Mejorar técnica peso muerto'
    AND ROWNUM = 1;
    
    SELECT r.id_recomendacion INTO v_id_recomendacion 
    FROM Recomendaciones r
    JOIN Personas p ON r.especialista_fitness = p.id_persona
    WHERE r.tipo_enfoque = 'Entrenamiento'
    AND p.correo = 'carlos.entrenador.nuevo@gmail.com'
    AND ROWNUM = 1;
    
    PK_OBJETIVOS.MO_OBJETIVOS(
        v_id_objetivo,
        'Mejorar técnica sentadilla profunda',
        'Aumentar sentadilla profunda a 160 kg manteniendo técnica perfecta.'
    );
    
    PK_OBJETIVOS.DEL_RECOMENDACIONES(v_id_recomendacion);
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Objetivo actualizado y recomendación eliminada');
END;
/

COMMIT;

-- Mensaje final
BEGIN
    DBMS_OUTPUT.PUT_LINE('========================================');
    DBMS_OUTPUT.PUT_LINE('TODAS LAS HISTORIAS DE USO COMPLETADAS');
    DBMS_OUTPUT.PUT_LINE('========================================');
END;
/

ROLLBACK;
