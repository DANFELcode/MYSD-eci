------------------
-- AccionesOK
-- Casos que prueban las acciones de referencia
------------------

SET SERVEROUTPUT ON;

PROMPT '=== Probando Acciones de Referencia ===';

------------------
-- 1. PERSONA → USUARIO (ON DELETE CASCADE)
------------------
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('1. CASCADE: Persona → Usuario');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_id, 'Usuario Cascade', 'cascade1@test.com', 'pass123', 'Usuario');
    
    -- Usuario SIN membresía activa (más simple)
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa)
    VALUES (v_id, 'Básico', 28, 'M', 75.5, 1.75, '0');
    
    DBMS_OUTPUT.PUT_LINE('   Usuario creado');
    
    DELETE FROM Personas WHERE id_persona = v_id;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Usuario eliminado en CASCADE');
    COMMIT;
END;
/

------------------
-- 2. PERSONA → ESPECIALISTA (ON DELETE CASCADE)
------------------
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('2. CASCADE: Persona → EspecialistaFitness');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_id, 'Especialista Cascade', 'cascade2@test.com', 'pass123', 'EspecialistaFitness');
    
    INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados)
    VALUES (v_id, 'Nutrición', 'Especialista', 'Trayectoria', 10);
    
    DELETE FROM Personas WHERE id_persona = v_id;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Especialista eliminado en CASCADE');
    COMMIT;
END;
/

------------------
-- 3. USUARIO → FEEDBACKS (ON DELETE CASCADE)
------------------
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('3. CASCADE: Usuario → Feedbacks');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_id, 'Usuario FB', 'feedback@test.com', 'pass123', 'Usuario');
    
    -- Usuario SIN membresía activa
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa)
    VALUES (v_id, 'Intermedio', 25, 'M', 80.0, 1.78, '0');
    
    INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
    VALUES (v_id, 'Feedback prueba', SYSDATE, 5, 'Sistema', 'Público');
    
    DELETE FROM Usuarios WHERE id_persona = v_id;
    DELETE FROM Personas WHERE id_persona = v_id;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Feedbacks eliminados en CASCADE');
    COMMIT;
END;
/

------------------
-- 4. USUARIO → OBJETIVOS (ON DELETE CASCADE)
------------------
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('4. CASCADE: Usuario → Objetivos');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_id, 'Usuario Obj', 'objetivo@test.com', 'pass123', 'Usuario');
    
    -- Usuario SIN membresía activa
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa)
    VALUES (v_id, 'Avanzado', 30, 'F', 60.0, 1.65, '0');
    
    INSERT INTO Objetivos (usuario, nombre, contenido, fecha_creacion)
    VALUES (v_id, 'Objetivo prueba', 'Contenido', SYSDATE);
    
    DELETE FROM Usuarios WHERE id_persona = v_id;
    DELETE FROM Personas WHERE id_persona = v_id;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Objetivos eliminados en CASCADE');
    COMMIT;
END;
/

------------------
-- 5. USUARIO → PROGRESOS (ON DELETE CASCADE)
------------------
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('5. CASCADE: Usuario → Progresos');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_id, 'Usuario Prog', 'progreso@test.com', 'pass123', 'Usuario');
    
    -- Usuario SIN membresía activa
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa)
    VALUES (v_id, 'Básico', 22, 'F', 58.0, 1.62, '0');
    
    INSERT INTO Progresos (usuario, peso_actual, fecha_registro)
    VALUES (v_id, 57.5, SYSDATE);
    
    DELETE FROM Usuarios WHERE id_persona = v_id;
    DELETE FROM Personas WHERE id_persona = v_id;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Progresos eliminados en CASCADE');
    COMMIT;
END;
/

------------------
-- 6. PLANFITNESS → RUTINAS/COMIDAS/HABITOS (ON DELETE CASCADE)
------------------
DECLARE
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('6. CASCADE: PlanFitness → Rutinas/Comidas/Hábitos');
    
    SELECT NVL(MAX(id_plan), 0) + 1 INTO v_plan FROM PlanesFitness;
    
    INSERT INTO PlanesFitness (id_plan, nombre, duracion, descripcion)
    VALUES (v_plan, 'Plan CASCADE Test ' || v_plan, '8 semanas', 'Test');
    
    INSERT INTO Rutinas (planfitness, nombre_rutina, descripcion)
    VALUES (v_plan, 'Rutina Test', 'Descripción');
    
    INSERT INTO Comidas (planfitness, nombre_comida, calorias)
    VALUES (v_plan, 'Comida Test', 450);
    
    INSERT INTO Habitos (planfitness, nombre_habito, descripcion, frecuencia)
    VALUES (v_plan, 'Hábito Test', 'Descripción', 'Diario');
    
    DELETE FROM PlanesFitness WHERE id_plan = v_plan;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Rutinas, Comidas y Hábitos eliminados en CASCADE');
    COMMIT;
END;
/

------------------
-- 7. RUTINA → EJERCICIOS (ON DELETE CASCADE)
------------------
DECLARE
    v_plan NUMBER;
    v_rutina NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('7. CASCADE: Rutina → Ejercicios');
    
    SELECT NVL(MAX(id_plan), 0) + 1 INTO v_plan FROM PlanesFitness;
    
    INSERT INTO PlanesFitness (id_plan, nombre, duracion, descripcion)
    VALUES (v_plan, 'Plan Ejercicios ' || v_plan, '6 semanas', 'Test');
    
    INSERT INTO Rutinas (planfitness, nombre_rutina, descripcion)
    VALUES (v_plan, 'Rutina Cardio', 'Test');
    
    SELECT MAX(id_rutina) INTO v_rutina FROM Rutinas WHERE planfitness = v_plan;
    
    INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones)
    VALUES (1, v_rutina, 'Burpees', 4, 15);
    
    INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones)
    VALUES (2, v_rutina, 'Mountain Climbers', 3, 20);
    
    DELETE FROM Rutinas WHERE id_rutina = v_rutina;
    DELETE FROM PlanesFitness WHERE id_plan = v_plan;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Ejercicios eliminados en CASCADE');
    COMMIT;
END;
/

------------------
-- 8. ESPECIALISTA → RECOMENDACIONES (ON DELETE CASCADE)
------------------
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('8. CASCADE: Especialista → Recomendaciones');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_id, 'Especialista Rec', 'recomenda@test.com', 'pass123', 'EspecialistaFitness');
    
    INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados)
    VALUES (v_id, 'Motivación', 'Especialista', 'Trayectoria', 5);
    
    INSERT INTO Recomendaciones (especialista_fitness, contenido, fecha_creacion, tipo_enfoque)
    VALUES (v_id, 'Recomendación de prueba', SYSDATE, 'Motivación');
    
    DELETE FROM EspecialistasFitness WHERE id_persona = v_id;
    DELETE FROM Personas WHERE id_persona = v_id;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Recomendaciones eliminadas en CASCADE');
    COMMIT;
END;
/

------------------
-- 9. RUTINAEJEMPLO → EJERCICIOSDERUTINASDEEJEMPLO (ON DELETE CASCADE)
------------------
DECLARE
    v_esp NUMBER;
    v_rutina NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('9. CASCADE: RutinaEjemplo → EjerciciosDeRutinasDeEjemplo');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_esp FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_esp, 'Especialista Ej', 'ejercicios@test.com', 'pass123', 'EspecialistaFitness');
    
    INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados)
    VALUES (v_esp, 'CrossFit', 'Entrenador', 'Trayectoria', 30);
    
    INSERT INTO RutinasDeEjemplo (especialista_fitness, nombre_rutina, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento)
    VALUES (v_esp, 'WOD Test ' || v_esp, 'Lunes', 50, 'Avanzado', 'Fuerza');
    
    SELECT MAX(id_rutina_ejemplo) INTO v_rutina FROM RutinasDeEjemplo WHERE especialista_fitness = v_esp;
    
    INSERT INTO EjerciciosDeRutinasDeEjemplo (id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, duracion_min)
    VALUES (v_rutina, 'Clean and Jerk', 5, 5, 3);
    
    DELETE FROM RutinasDeEjemplo WHERE id_rutina_ejemplo = v_rutina;
    DELETE FROM EspecialistasFitness WHERE id_persona = v_esp;
    DELETE FROM Personas WHERE id_persona = v_esp;
    
    DBMS_OUTPUT.PUT_LINE('   ✓ EjerciciosDeRutinasDeEjemplo eliminados en CASCADE');
    COMMIT;
END;
/

------------------
-- 10. ESPECIALISTA → RUTINASDEEJEMPLO (ON DELETE SET NULL)
-- La rutina queda huérfana con especialista_fitness = NULL
------------------
DECLARE
    v_id NUMBER;
    v_rutina NUMBER;
    v_esp_final NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('10. SET NULL: Especialista → RutinasDeEjemplo');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_id, 'Especialista SET NULL', 'setnull@test.com', 'pass123', 'EspecialistaFitness');
    
    INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados)
    VALUES (v_id, 'Calistenia', 'Experto', 'Trayectoria', 20);
    
    INSERT INTO RutinasDeEjemplo (especialista_fitness, nombre_rutina, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento)
    VALUES (v_id, 'Rutina SET NULL ' || v_id, 'Lunes', 40, 'Básico', 'Fuerza');
    
    SELECT MAX(id_rutina_ejemplo) INTO v_rutina FROM RutinasDeEjemplo WHERE especialista_fitness = v_id;
    
    COMMIT;
    
    -- Eliminar el especialista (debería poner NULL en la rutina)
    DELETE FROM EspecialistasFitness WHERE id_persona = v_id;
    DELETE FROM Personas WHERE id_persona = v_id;
    
    -- Verificar que especialista_fitness quedó en NULL
    SELECT especialista_fitness INTO v_esp_final FROM RutinasDeEjemplo WHERE id_rutina_ejemplo = v_rutina;
    
    IF v_esp_final IS NULL THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ Especialista puesto en NULL correctamente (rutina huérfana)');
    ELSE
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Especialista NO se puso en NULL');
    END IF;
    
    -- Limpiar la rutina huérfana
    DELETE FROM RutinasDeEjemplo WHERE id_rutina_ejemplo = v_rutina;
    
    COMMIT;
END;
/

