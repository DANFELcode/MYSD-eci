"""
Generador MEJORADO de datos REALISTAS para sistema FitQual.
Genera UN SOLO archivo PoblarTablas.sql con TODAS las tablas pobladas.
Datos variados y coherentes como una app fitness real.
LÓGICA: Usuarios crean planes privados basados en recomendaciones y rutinas de ejemplo de especialistas.
"""

import random
from datetime import datetime, timedelta


class FitQualCompletoDatabaseGenerator:
    """Generador completo para todas las tablas de FitQual"""
    
    def __init__(self, num_personas: int = 10000):
        self.num_personas = num_personas
        self.num_especialistas = int(num_personas * 0.10)  # 10%
        self.num_usuarios = num_personas - self.num_especialistas  # 90%
        
        # Datos generales (NO MODIFICAR - MANTENER IGUAL)
        self.NOMBRES = [
            "Carmen", "Daniela", "Paula", "Sofia", "Alba", "Juliana", "Marta", "María",
            "Helena", "Adriana", "Martin", "Ana", "Ivanna", "Laura", "Lara", "Lorena",
            "Patricia", "Noa", "Mia", "Juan", "Sebastian", "Roberto", "Jose", "Nacho",
            "Miguel", "Diego", "Carlos", "Gustavo", "Hector", "Marcos", "Alfonso",
            "Oscar", "Fernando", "Ricardo", "Agustin", "German", "Nestor", "Alvaro",
            "Alfredo", "Ruben", "Vicente", "Rafael", "Victor", "Silvestre", "Berto",
            "Enrique", "Luis", "Elias", "Bruno", "Javier", "Darío", "Daniel", "Santiago",
            "Rodrigo", "Guillermo", "Cristian", "Jorge", "Arturo", "Pablo", "Borja",
            "Ivan", "Pedro", "Andrea", "Valentina", "Isabella", "Camila", "Natalia",
            "Sara", "Lucia", "Emma", "Valeria", "Catalina", "Mariana", "Gabriela"
        ]
        
        self.APELLIDOS = [
            "Rodriguez", "Gomez", "Lopez", "Gonzalez", "Garcia", "Martinez",
            "Villamil", "Bermudez", "Rubio", "Pinto", "Ramirez", "Sanchez",
            "Hernandez", "Diaz", "Perez", "Torres", "Rojas", "Vargas", "Moreno",
            "Gutierrez", "Jimenez", "Muñoz", "Castro", "Ortiz", "Alvarez", "Ruiz",
            "Suarez", "Romero", "Herrera", "Valencia", "Quintero", "Morales"
        ]
        
        self.DOMINIOS_EMAIL = ["@gmail.com", "@hotmail.com", "@yahoo.com", "@outlook.com"]
        
        self.ESPECIALIDADES = [
            "Entrenamiento de Fuerza", "Pérdida de Peso", "Nutrición Deportiva",
            "Yoga y Flexibilidad", "Entrenamiento Funcional", "Crossfit", "Pilates"
        ]
        
        # DATOS MEJORADOS PARA REALISMO
        self.PERFILES_ESPECIALISTA = [
            "Apasionado por transformar vidas a través del fitness y la nutrición",
            "Coach dedicado a ayudar personas a alcanzar su mejor versión",
            "Especialista en rendimiento deportivo y bienestar integral",
            "Entrenador certificado enfocado en resultados sostenibles",
            "Profesional del fitness con enfoque holístico mente-cuerpo",
            "Experto en programas personalizados según objetivos individuales",
            "Coach motivacional especializado en cambios de hábitos",
            "Instructor certificado en técnicas de entrenamiento avanzado"
        ]
        
        self.GIMNASIOS = ["Gold's Gym", "Smart Fit", "Bodytech", "Fitness People", "CrossFit Box", 
                         "Spinning Center", "Yoga Studio", "Total Fitness"]
        
        self.CERTIFICACIONES = ["NSCA", "ACE", "ISSA", "NASM", "CrossFit Level 2", 
                               "Yoga Alliance RYT-200", "Nutrición Deportiva"]
        
        # FEEDBACKS SEGÚN TIPO (CORRECTO)
        self.FEEDBACKS_ESPECIALISTA = {
            'positivos': [
                "Los especialistas son muy profesionales y responden todas mis dudas",
                "Excelente la asesoría de los especialistas, me han ayudado mucho",
                "Me encanta poder consultar con especialistas certificados",
                "Las recomendaciones de los especialistas son muy útiles y prácticas",
                "Gran calidad de los profesionales, se nota su experiencia",
            ],
            'regulares': [
                "Buenos especialistas pero tardan en responder a veces",
                "La calidad es buena pero podrían ser más especialistas disponibles",
                "Está bien pero me gustaría más interacción directa",
            ],
            'negativos': [
                "Esperaba más personalización en las recomendaciones",
                "Los especialistas no responden lo suficientemente rápido",
            ]
        }
        
        self.FEEDBACKS_RUTINAS = {
            'positivos': [
                "Las rutinas de ejemplo son excelentes, muy bien explicadas",
                "Me encantan las rutinas de ejemplo, me sirven mucho de guía",
                "Gran variedad de rutinas de ejemplo para todos los niveles",
                "Las rutinas de ejemplo están muy completas y profesionales",
                "Perfectas las rutinas de ejemplo para crear mis propios planes",
            ],
            'regulares': [
                "Buenas rutinas pero podría haber más variedad",
                "Las rutinas están bien pero le faltan videos explicativos",
                "Útiles pero podrían actualizarse más seguido",
            ],
            'negativos': [
                "Pocas rutinas de ejemplo para nivel avanzado",
                "Necesitan más rutinas de ejemplo especializadas",
            ]
        }
        
        self.FEEDBACKS_PROGRESO = {
            'positivos': [
                "Me encanta poder ver mi progreso día a día, muy motivador",
                "El sistema de seguimiento de progreso es excelente",
                "Las gráficas de progreso me ayudan a mantenerme enfocado",
                "Perfecto para trackear mi evolución semana a semana",
                "El registro de progreso es intuitivo y completo",
            ],
            'regulares': [
                "Buen sistema de progreso pero podría tener más métricas",
                "Útil pero le faltan gráficas más detalladas",
                "Está bien pero podría sincronizar con báscula inteligente",
            ],
            'negativos': [
                "El sistema de progreso es muy básico",
                "Falta integración con otras apps de seguimiento",
            ]
        }
        
        self.FEEDBACKS_SISTEMA = {
            'positivos': [
                "Excelente app, muy completa y fácil de usar",
                "La mejor app de fitness que he probado",
                "Interfaz intuitiva y todas las funciones que necesito",
                "App muy completa, vale cada peso de la membresía",
                "Totalmente recomendada, ha cambiado mi vida",
            ],
            'regulares': [
                "Buena app pero a veces se pone lenta",
                "Cumple su función aunque el diseño podría mejorar",
                "Está bien pero le falta modo offline",
                "Funciona correctamente, 4 estrellas",
            ],
            'negativos': [
                "La app se cierra constantemente, muy frustrante",
                "Demasiados bugs, necesita optimización",
                "Esperaba más por el precio de la membresía",
                "Hay opciones gratuitas mejores",
            ]
        }
        
        self.OBJETIVOS_NOMBRES = [
            "Perder 10 kilos", "Ganar masa muscular", "Correr mi primer 5K", 
            "Tonificar abdomen", "Mejorar flexibilidad", "Aumentar fuerza en piernas",
            "Preparar maratón", "Definición corporal", "Reducir grasa abdominal",
            "Aumentar resistencia cardiovascular", "Mejorar postura", "Ganar 5kg de músculo",
            "Bajar porcentaje de grasa", "Entrenar para competencia", "Mantener peso ideal"
        ]
        
        # PLANES FITNESS: Nombres normales (privados del usuario)
        self.TIPOS_PLANES = [
            ("Plan Pérdida de Peso", "Plan diseñado para pérdida de peso con déficit calórico controlado"),
            ("Plan Ganancia Muscular", "Programa de hipertrofia con énfasis en ejercicios compuestos"),
            ("Plan Definición", "Reducir grasa mientras mantengo masa muscular"),
            ("Plan Resistencia", "Mejora de capacidad aeróbica y resistencia física"),
            ("Plan Fuerza", "Desarrollo de fuerza máxima con cargas progresivas"),
            ("Plan Transformación", "Plan integral combinando fuerza, cardio y nutrición"),
            ("Plan Iniciación", "Comienzo de mi viaje fitness con fundamentos sólidos"),
            ("Plan Atlético", "Maximizar mi potencial deportivo"),
            ("Plan Wellness", "Equilibrio entre fitness, nutrición y bienestar"),
            ("Plan HIIT", "Entrenamientos de alta intensidad para quemar grasa"),
        ]
        
        self.EJERCICIOS_FUERZA = [
            ("Sentadillas", "Ejercicio fundamental para tren inferior", 3, 4, 10, 15),
            ("Press de Banca", "Desarrollo de pecho, hombros y tríceps", 3, 4, 8, 12),
            ("Peso Muerto", "Ejercicio completo para cadena posterior", 3, 4, 6, 10),
            ("Dominadas", "Excelente para desarrollar espalda", 3, 4, 6, 12),
            ("Press Militar", "Desarrollo de hombros y core", 3, 4, 8, 12),
            ("Remo con Barra", "Fortalece toda la espalda", 3, 4, 8, 12),
            ("Fondos en Paralelas", "Tríceps y pecho inferior", 3, 4, 8, 15),
            ("Curl de Bíceps", "Aislamiento de bíceps", 3, 3, 10, 15),
            ("Extensiones de Tríceps", "Desarrollo de tríceps", 3, 3, 10, 15),
            ("Zancadas", "Piernas y glúteos", 3, 4, 10, 15),
            ("Hip Thrust", "Glúteos e isquiotibiales", 3, 4, 10, 15),
            ("Press Inclinado", "Pecho superior", 3, 4, 8, 12),
            ("Remo en T", "Espalda media y grosor", 3, 4, 8, 12),
            ("Face Pulls", "Hombro posterior y salud escapular", 3, 3, 12, 15),
            ("Plancha", "Core y estabilidad", 3, 3, 30, 60),
        ]
        
        self.EJERCICIOS_CARDIO = [
            ("Burpees", "Ejercicio explosivo de cuerpo completo", 3, 5),
            ("Mountain Climbers", "Cardio intenso con trabajo de core", 4, 7),
            ("Running", "Carrera continua a ritmo moderado", 20, 40),
            ("Jumping Jacks", "Calentamiento y activación", 5, 10),
            ("Box Jumps", "Pliometría para potencia", 4, 8),
            ("Battle Ropes", "Acondicionamiento de tren superior", 3, 6),
            ("Bicicleta Estática", "Cardio de bajo impacto", 15, 35),
            ("Remo Indoor", "Cardio completo bajo impacto", 15, 30),
            ("Saltos de Cuerda", "Cardio intenso y coordinación", 5, 12),
            ("Sprint Intervals", "Intervalos de alta intensidad", 10, 20),
        ]
        
        self.COMIDAS_TEMPLATES = [
            ("Desayuno Proteico", 450, 520, 35, 55, 15, 25, 30, 45),
            ("Almuerzo Balanceado", 550, 700, 50, 80, 18, 28, 40, 55),
            ("Cena Ligera", 400, 500, 30, 50, 12, 20, 35, 48),
            ("Snack Pre-Entreno", 200, 300, 35, 50, 5, 10, 10, 18),
            ("Batido Post-Entreno", 300, 400, 40, 60, 8, 15, 25, 35),
            ("Merienda Saludable", 150, 250, 20, 35, 5, 12, 8, 15),
        ]
        
        self.HABITOS_TEMPLATES = [
            ("Hidratación Diaria", "Consumir 2-3 litros de agua al día", "Diario"),
            ("Estiramientos Matutinos", "10 minutos de movilidad al despertar", "Diario"),
            ("Descanso Nocturno", "Dormir 7-9 horas para óptima recuperación", "Diario"),
            ("Meditación y Mindfulness", "15 minutos de práctica mental", "5 veces por semana"),
            ("Preparación de Comidas", "Meal prep semanal los domingos", "Semanal"),
            ("Suplementación", "Vitaminas y proteína según plan", "Diario"),
            ("Registro de Progresos", "Pesar y medir avances", "Semanal"),
            ("Caminata Activa", "10,000 pasos diarios", "Diario"),
        ]
        
        self.DIAS_SEMANA_OPCIONES = [
            "Lunes, Miércoles, Viernes",
            "Martes, Jueves, Sábado",
            "Lunes, Martes, Jueves, Viernes",
            "Lunes, Miércoles, Viernes, Sábado",
            "Lunes a Viernes",
            "Lunes, Miércoles, Viernes, Domingo",
        ]
        
        self.NIVELES = ['Básico', 'Intermedio', 'Avanzado']
        self.SEXOS = ['M', 'F']
        self.TIPOS_FEEDBACK = ['EspecialistaFitness', 'RutinasDeEjemplo', 'Progreso', 'Sistema']
        self.TIPOS_ENFOQUE = ['Nutrición', 'Entrenamiento', 'Salud mental', 'Descanso', 'Motivación']
        self.TIPOS_ENTRENAMIENTO = ['Cardio', 'Fuerza']
    
    def escapar_comillas(self, texto: str) -> str:
        return texto.replace("'", "''")
    
    def generar_contrasena(self) -> str:
        longitud = random.randint(8, 15)
        caracteres = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return ''.join(random.choice(caracteres) for _ in range(longitud))
    
    def generar_personas(self, output):
        """Genera Personas - NO MODIFICAR"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: PERSONAS (10,000 registros)\n")
        output.write("-- =================================================\n\n")
        
        roles = ['EspecialistaFitness'] * self.num_especialistas + ['Usuario'] * self.num_usuarios
        random.shuffle(roles)
        
        for i in range(self.num_personas):
            id_persona = i + 1
            nombre = f"{random.choice(self.NOMBRES)} {random.choice(self.APELLIDOS)}"
            correo = f"{random.choice(self.NOMBRES).lower()}{id_persona}{random.choice(self.DOMINIOS_EMAIL)}"
            contrasena = self.generar_contrasena()
            rol = roles[i]
            
            output.write(f"INSERT INTO Personas VALUES ({id_persona}, '{nombre}', '{correo}', '{contrasena}', '{rol}');\n")
            
            if (id_persona % 100 == 0):
                output.write("COMMIT;\n\n")
        
        output.write("COMMIT;\n")
        output.write("-- Personas: 10,000 registros insertados\n\n")
    
    def generar_especialistas(self, output):
        """Genera EspecialistasFitness MEJORADO con datos realistas"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: ESPECIALISTASFITNESS (1,000 registros)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    v_count NUMBER := 0;
    v_especialidad VARCHAR2(100);
    v_perfil VARCHAR2(500);
    v_trayectoria VARCHAR2(500);
BEGIN
    FOR rec IN (SELECT id_persona FROM Personas WHERE rol = 'EspecialistaFitness') LOOP
        -- Especialidad
        v_especialidad := CASE MOD(v_count, 7)
            WHEN 0 THEN 'Entrenamiento de Fuerza'
            WHEN 1 THEN 'Pérdida de Peso'
            WHEN 2 THEN 'Nutrición Deportiva'
            WHEN 3 THEN 'Yoga y Flexibilidad'
            WHEN 4 THEN 'Entrenamiento Funcional'
            WHEN 5 THEN 'Crossfit'
            ELSE 'Pilates'
        END;
        
        -- Perfil variado
        v_perfil := CASE MOD(v_count, 8)
            WHEN 0 THEN 'Apasionado por transformar vidas a través del fitness y la nutrición'
            WHEN 1 THEN 'Coach dedicado a ayudar personas a alcanzar su mejor versión'
            WHEN 2 THEN 'Especialista en rendimiento deportivo y bienestar integral'
            WHEN 3 THEN 'Entrenador certificado enfocado en resultados sostenibles'
            WHEN 4 THEN 'Profesional del fitness con enfoque holístico mente-cuerpo'
            WHEN 5 THEN 'Experto en programas personalizados según objetivos individuales'
            WHEN 6 THEN 'Coach motivacional especializado en cambios de hábitos'
            ELSE 'Instructor certificado en técnicas de entrenamiento avanzado'
        END;
        
        -- Trayectoria realista
        v_trayectoria := CASE MOD(v_count, 10)
            WHEN 0 THEN 'Entrenador en Gold''s Gym (8 años). Certificación NSCA. +500 clientes.'
            WHEN 1 THEN '12 años en fitness. Certificado ACE. Especialista en programas personalizados.'
            WHEN 2 THEN 'Coach independiente (5 años). ISSA certified. Enfoque en resultados.'
            WHEN 3 THEN 'Instructor en Bodytech. 10 años experiencia. Certificación NASM.'
            WHEN 4 THEN '7 años transformando vidas. CrossFit Level 2. Ex-atleta profesional.'
            WHEN 5 THEN 'Entrenador Smart Fit (6 años). Nutrición Deportiva. +300 casos éxito.'
            WHEN 6 THEN '15 años experiencia. Yoga Alliance RYT-200. Mindfulness coach.'
            WHEN 7 THEN 'Coach Fitness People (9 años). NSCA certified. Especialista fuerza.'
            WHEN 8 THEN '4 años dedicado. ACE certified. Enfoque pérdida peso sostenible.'
            ELSE '11 años industria. ISSA + NASM. Programas transformación integral.'
        END;
        
        INSERT INTO EspecialistasFitness VALUES (
            rec.id_persona,
            v_especialidad,
            v_perfil,
            v_trayectoria,
            0
        );
        
        v_count := v_count + 1;
        
        IF MOD(v_count, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_usuarios(self, output):
        """Genera Usuarios - NO MODIFICAR (ya está bien)"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: USUARIOS (9,000 registros)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    v_count NUMBER := 0;
    v_con_membresia NUMBER := 0;
    v_total NUMBER;
    v_limite_membresia NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_total FROM Personas WHERE rol = 'Usuario';
    v_limite_membresia := ROUND(v_total * 0.20);
    
    FOR rec IN (SELECT id_persona FROM Personas WHERE rol = 'Usuario') LOOP
        v_count := v_count + 1;
        v_con_membresia := CASE WHEN v_count <= v_limite_membresia THEN 1 ELSE 0 END;
        
        INSERT INTO Usuarios (
            id_persona, meta, nivel, frecuencia_entreno_semanal,
            edad, sexo, peso, altura,
            fecha_inicio_membresia, membresia_activa, fecha_fin_membresia
        ) VALUES (
            rec.id_persona,
            CASE MOD(v_count, 6)
                WHEN 0 THEN 'Pérdida de peso'
                WHEN 1 THEN 'Ganancia muscular'
                WHEN 2 THEN 'Definición corporal'
                WHEN 3 THEN 'Mejorar resistencia'
                WHEN 4 THEN 'Aumentar fuerza'
                ELSE 'Tonificar cuerpo'
            END,
            CASE MOD(v_count, 3)
                WHEN 0 THEN 'Básico'
                WHEN 1 THEN 'Intermedio'
                ELSE 'Avanzado'
            END,
            DBMS_RANDOM.VALUE(2, 6),
            DBMS_RANDOM.VALUE(18, 60),
            CASE WHEN MOD(v_count, 2) = 0 THEN 'M' ELSE 'F' END,
            ROUND(DBMS_RANDOM.VALUE(55, 95), 2),
            ROUND(DBMS_RANDOM.VALUE(1.55, 1.85), 2),
            CASE WHEN v_con_membresia = 1 THEN SYSDATE - DBMS_RANDOM.VALUE(30, 300) ELSE NULL END,
            CASE WHEN v_con_membresia = 1 THEN '1' ELSE '0' END,
            CASE WHEN v_con_membresia = 1 THEN ADD_MONTHS(SYSDATE - DBMS_RANDOM.VALUE(30, 300), 12) ELSE NULL END
        );
        
        IF MOD(v_count, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_feedbacks(self, output):
        """Genera Feedbacks CORREGIDOS según tipo_feedback"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: FEEDBACKS (10,000 registros CORREGIDOS)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_usuarios id_array;
    v_idx NUMBER;
    v_contenido VARCHAR2(500);
    v_calificacion NUMBER;
    v_tipo VARCHAR2(50);
BEGIN
    SELECT id_persona BULK COLLECT INTO v_usuarios FROM Usuarios;
    
    FOR i IN 1..10000 LOOP
        v_idx := MOD(i, v_usuarios.COUNT) + 1;
        
        -- Tipo de feedback
        v_tipo := CASE MOD(i, 4)
            WHEN 0 THEN 'EspecialistaFitness'
            WHEN 1 THEN 'RutinasDeEjemplo'
            WHEN 2 THEN 'Progreso'
            ELSE 'Sistema'
        END;
        
        -- 70% positivos (4-5), 20% regulares (3), 10% negativos (1-2)
        IF MOD(i, 10) < 7 THEN
            -- POSITIVOS
            v_calificacion := CASE WHEN MOD(i, 2) = 0 THEN 5 ELSE 4 END;
            v_contenido := CASE v_tipo
                WHEN 'EspecialistaFitness' THEN CASE MOD(i, 5)
                    WHEN 0 THEN 'Los especialistas son muy profesionales y responden todas mis dudas'
                    WHEN 1 THEN 'Excelente la asesoría de los especialistas, me han ayudado mucho'
                    WHEN 2 THEN 'Me encanta poder consultar con especialistas certificados'
                    WHEN 3 THEN 'Las recomendaciones de los especialistas son muy útiles y prácticas'
                    ELSE 'Gran calidad de los profesionales, se nota su experiencia'
                END
                WHEN 'RutinasDeEjemplo' THEN CASE MOD(i, 5)
                    WHEN 0 THEN 'Las rutinas de ejemplo son excelentes, muy bien explicadas'
                    WHEN 1 THEN 'Me encantan las rutinas de ejemplo, me sirven mucho de guía'
                    WHEN 2 THEN 'Gran variedad de rutinas de ejemplo para todos los niveles'
                    WHEN 3 THEN 'Las rutinas de ejemplo están muy completas y profesionales'
                    ELSE 'Perfectas las rutinas de ejemplo para crear mis propios planes'
                END
                WHEN 'Progreso' THEN CASE MOD(i, 5)
                    WHEN 0 THEN 'Me encanta poder ver mi progreso día a día, muy motivador'
                    WHEN 1 THEN 'El sistema de seguimiento de progreso es excelente'
                    WHEN 2 THEN 'Las gráficas de progreso me ayudan a mantenerme enfocado'
                    WHEN 3 THEN 'Perfecto para trackear mi evolución semana a semana'
                    ELSE 'El registro de progreso es intuitivo y completo'
                END
                ELSE CASE MOD(i, 5)
                    WHEN 0 THEN 'Excelente app, muy completa y fácil de usar'
                    WHEN 1 THEN 'La mejor app de fitness que he probado'
                    WHEN 2 THEN 'Interfaz intuitiva y todas las funciones que necesito'
                    WHEN 3 THEN 'App muy completa, vale cada peso de la membresía'
                    ELSE 'Totalmente recomendada, ha cambiado mi vida'
                END
            END;
        ELSIF MOD(i, 10) < 9 THEN
            -- REGULARES
            v_calificacion := 3;
            v_contenido := CASE v_tipo
                WHEN 'EspecialistaFitness' THEN CASE MOD(i, 3)
                    WHEN 0 THEN 'Buenos especialistas pero tardan en responder a veces'
                    WHEN 1 THEN 'La calidad es buena pero podrían ser más especialistas disponibles'
                    ELSE 'Está bien pero me gustaría más interacción directa'
                END
                WHEN 'RutinasDeEjemplo' THEN CASE MOD(i, 3)
                    WHEN 0 THEN 'Buenas rutinas pero podría haber más variedad'
                    WHEN 1 THEN 'Las rutinas están bien pero le faltan videos explicativos'
                    ELSE 'Útiles pero podrían actualizarse más seguido'
                END
                WHEN 'Progreso' THEN CASE MOD(i, 3)
                    WHEN 0 THEN 'Buen sistema de progreso pero podría tener más métricas'
                    WHEN 1 THEN 'Útil pero le faltan gráficas más detalladas'
                    ELSE 'Está bien pero podría sincronizar con báscula inteligente'
                END
                ELSE CASE MOD(i, 4)
                    WHEN 0 THEN 'Buena app pero a veces se pone lenta'
                    WHEN 1 THEN 'Cumple su función aunque el diseño podría mejorar'
                    WHEN 2 THEN 'Está bien pero le falta modo offline'
                    ELSE 'Funciona correctamente, 4 estrellas'
                END
            END;
        ELSE
            -- NEGATIVOS
            v_calificacion := CASE WHEN MOD(i, 2) = 0 THEN 2 ELSE 1 END;
            v_contenido := CASE v_tipo
                WHEN 'EspecialistaFitness' THEN CASE MOD(i, 2)
                    WHEN 0 THEN 'Esperaba más personalización en las recomendaciones'
                    ELSE 'Los especialistas no responden lo suficientemente rápido'
                END
                WHEN 'RutinasDeEjemplo' THEN CASE MOD(i, 2)
                    WHEN 0 THEN 'Pocas rutinas de ejemplo para nivel avanzado'
                    ELSE 'Necesitan más rutinas de ejemplo especializadas'
                END
                WHEN 'Progreso' THEN CASE MOD(i, 2)
                    WHEN 0 THEN 'El sistema de progreso es muy básico'
                    ELSE 'Falta integración con otras apps de seguimiento'
                END
                ELSE CASE MOD(i, 4)
                    WHEN 0 THEN 'La app se cierra constantemente, muy frustrante'
                    WHEN 1 THEN 'Demasiados bugs, necesita optimización'
                    WHEN 2 THEN 'Esperaba más por el precio de la membresía'
                    ELSE 'Hay opciones gratuitas mejores'
                END
            END;
        END IF;
        
        INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
        VALUES (
            v_usuarios(v_idx),
            v_contenido,
            SYSDATE - DBMS_RANDOM.VALUE(1, 365),
            v_calificacion,
            v_tipo,
            CASE WHEN MOD(i, 10) < 7 THEN 'Público' ELSE 'Privado' END
        );
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_objetivos(self, output):
        """Genera Objetivos MEJORADOS con variedad"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: OBJETIVOS (10,000 registros)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_usuarios id_array;
    v_idx NUMBER;
    v_nombre VARCHAR2(100);
    v_contenido VARCHAR2(500);
BEGIN
    SELECT id_persona BULK COLLECT INTO v_usuarios FROM Usuarios;
    
    FOR i IN 1..10000 LOOP
        v_idx := MOD(i, v_usuarios.COUNT) + 1;
        
        v_nombre := CASE MOD(i, 15)
            WHEN 0 THEN 'Perder 10 kilos'
            WHEN 1 THEN 'Ganar masa muscular'
            WHEN 2 THEN 'Correr mi primer 5K'
            WHEN 3 THEN 'Tonificar abdomen'
            WHEN 4 THEN 'Mejorar flexibilidad'
            WHEN 5 THEN 'Aumentar fuerza en piernas'
            WHEN 6 THEN 'Preparar maratón'
            WHEN 7 THEN 'Definición corporal'
            WHEN 8 THEN 'Reducir grasa abdominal'
            WHEN 9 THEN 'Aumentar resistencia cardiovascular'
            WHEN 10 THEN 'Mejorar postura'
            WHEN 11 THEN 'Ganar 5kg de músculo'
            WHEN 12 THEN 'Bajar porcentaje de grasa'
            WHEN 13 THEN 'Entrenar para competencia'
            ELSE 'Mantener peso ideal'
        END;
        
        v_contenido := CASE MOD(i, 10)
            WHEN 0 THEN 'Meta: ' || v_nombre || '. Plazo: 6 meses. Estrategia: déficit calórico + cardio'
            WHEN 1 THEN 'Objetivo: ' || v_nombre || '. Tiempo estimado: 3 meses. Plan de entrenamiento 5x semana'
            WHEN 2 THEN 'Propósito: ' || v_nombre || '. Duración: 4 meses. Enfoque en progresión gradual'
            WHEN 3 THEN 'Reto personal: ' || v_nombre || '. Seguimiento semanal con especialista'
            WHEN 4 THEN 'Mi objetivo: ' || v_nombre || '. Compromiso diario con alimentación y ejercicio'
            WHEN 5 THEN 'Quiero lograr: ' || v_nombre || '. Plan estructurado con mediciones mensuales'
            WHEN 6 THEN 'Desafío: ' || v_nombre || '. Entrenamiento inteligente + descanso adecuado'
            WHEN 7 THEN 'Aspiración: ' || v_nombre || '. Combinación de fuerza y nutrición'
            WHEN 8 THEN 'Proyecto fitness: ' || v_nombre || '. Metodología científica aplicada'
            ELSE 'Transformación: ' || v_nombre || '. Compromiso total con el proceso'
        END;
        
        INSERT INTO Objetivos (usuario, nombre, contenido, fecha_creacion)
        VALUES (
            v_usuarios(v_idx),
            v_nombre,
            v_contenido,
            SYSDATE - DBMS_RANDOM.VALUE(1, 180)
        );
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_recomendaciones(self, output):
        """Genera Recomendaciones de especialistas"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: RECOMENDACIONES (500 registros)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_especialistas id_array;
    v_idx NUMBER;
    v_contenido VARCHAR2(1000);
    v_tipo VARCHAR2(50);
BEGIN
    SELECT id_persona BULK COLLECT INTO v_especialistas FROM EspecialistasFitness;
    
    FOR i IN 1..500 LOOP
        v_idx := MOD(i, v_especialistas.COUNT) + 1;
        
        v_tipo := CASE MOD(i, 5)
            WHEN 0 THEN 'Nutrición'
            WHEN 1 THEN 'Entrenamiento'
            WHEN 2 THEN 'Salud mental'
            WHEN 3 THEN 'Descanso'
            ELSE 'Motivación'
        END;
        
        v_contenido := CASE v_tipo
            WHEN 'Nutrición' THEN CASE MOD(i, 5)
                WHEN 0 THEN 'Incrementa tu consumo de proteína a 1.8g por kg de peso corporal'
                WHEN 1 THEN 'Consume carbohidratos complejos antes del entrenamiento para energía sostenida'
                WHEN 2 THEN 'Mantén un superávit calórico de 300-500 calorías para ganancia muscular'
                WHEN 3 THEN 'Prioriza alimentos integrales sobre procesados para mejor composición corporal'
                ELSE 'Distribuye tus comidas en 5-6 porciones pequeñas para metabolismo activo'
            END
            WHEN 'Entrenamiento' THEN CASE MOD(i, 5)
                WHEN 0 THEN 'Implementa progresión gradual: aumenta peso o repeticiones cada semana'
                WHEN 1 THEN 'Alterna entre días de fuerza y cardio para recuperación óptima'
                WHEN 2 THEN 'Enfócate en ejercicios compuestos: sentadillas, peso muerto, press banca'
                WHEN 3 THEN 'Incluye 2-3 sesiones de HIIT semanales para maximizar quema de grasa'
                ELSE 'Varía tu rutina cada 6-8 semanas para evitar adaptación y estancamiento'
            END
            WHEN 'Salud mental' THEN CASE MOD(i, 4)
                WHEN 0 THEN 'Practica mindfulness 10 minutos diarios para reducir estrés y ansiedad'
                WHEN 1 THEN 'Establece metas semanales alcanzables para mantener motivación alta'
                WHEN 2 THEN 'Celebra pequeños logros en el camino hacia tu objetivo final'
                ELSE 'Rodéate de personas que apoyen tu transformación fitness'
            END
            WHEN 'Descanso' THEN CASE MOD(i, 4)
                WHEN 0 THEN 'Duerme 7-9 horas para óptima recuperación muscular y hormonal'
                WHEN 1 THEN 'Toma 1-2 días de descanso activo por semana (caminata, yoga)'
                WHEN 2 THEN 'Incorpora estiramientos y foam rolling después de entrenar'
                ELSE 'Respeta las señales de tu cuerpo: fatiga excesiva indica necesidad de descanso'
            END
            ELSE CASE MOD(i, 4)
                WHEN 0 THEN 'Visualiza tu objetivo cumplido cada mañana al despertar'
                WHEN 1 THEN 'Lleva un diario de progresos para ver cuánto has avanzado'
                WHEN 2 THEN 'Recuerda: la consistencia es más importante que la perfección'
                ELSE 'Tu única competencia eres tú mismo de ayer. Mejora 1% cada día'
            END
        END;
        
        INSERT INTO Recomendaciones (especialista_fitness, contenido, fecha_creacion, tipo_enfoque)
        VALUES (v_especialistas(v_idx), v_contenido, SYSDATE - DBMS_RANDOM.VALUE(1, 365), v_tipo);
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_objetivos_recomendaciones(self, output):
        """Genera tabla intermedia"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: OBJETIVOSRECOMENDACIONES\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_objetivos id_array;
    v_recomendaciones id_array;
    v_rec_idx NUMBER;
    v_contador NUMBER := 0;
BEGIN
    SELECT id_objetivo BULK COLLECT INTO v_objetivos FROM Objetivos;
    SELECT id_recomendacion BULK COLLECT INTO v_recomendaciones FROM Recomendaciones;
    
    FOR i IN 1..v_objetivos.COUNT LOOP
        FOR j IN 1..DBMS_RANDOM.VALUE(1, 3) LOOP
            v_rec_idx := MOD(i + j, v_recomendaciones.COUNT) + 1;
            
            BEGIN
                INSERT INTO ObjetivosRecomendaciones VALUES (v_recomendaciones(v_rec_idx), v_objetivos(i));
                v_contador := v_contador + 1;
                EXCEPTION
                    WHEN DUP_VAL_ON_INDEX THEN 
                        NULL;
            END;
        END LOOP;
        
        IF MOD(v_contador, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_progresos(self, output):
        """Genera Progresos con datos realistas"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: PROGRESOS (10,000 registros)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_usuarios id_array;
    v_idx NUMBER;
    v_peso_inicial NUMBER(5,2);
BEGIN
    SELECT id_persona BULK COLLECT INTO v_usuarios FROM Usuarios;
    
    FOR i IN 1..10000 LOOP
        v_idx := MOD(i, v_usuarios.COUNT) + 1;
        v_peso_inicial := ROUND(DBMS_RANDOM.VALUE(60, 90), 2);
        
        INSERT INTO Progresos (usuario, peso_actual, medidas, porcentaje_grasa, imc, fecha_registro)
        VALUES (
            v_usuarios(v_idx),
            v_peso_inicial,
            'Pecho: ' || ROUND(DBMS_RANDOM.VALUE(85, 110)) || 'cm, ' ||
            'Cintura: ' || ROUND(DBMS_RANDOM.VALUE(70, 95)) || 'cm, ' ||
            'Cadera: ' || ROUND(DBMS_RANDOM.VALUE(85, 105)) || 'cm',
            ROUND(DBMS_RANDOM.VALUE(15, 30), 2),
            ROUND(v_peso_inicial / POWER(DBMS_RANDOM.VALUE(1.60, 1.80), 2), 2),
            SYSDATE - DBMS_RANDOM.VALUE(1, 365)
        );
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_planes_fitness(self, output):
        """Genera PlanesFitness CORREGIDOS - Planes privados de usuarios con membresía"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: PLANESFITNESS (Planes privados de usuarios con membresía)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_usuarios_membresia id_array;
    v_nombre VARCHAR2(100);
    v_duracion VARCHAR2(50);
    v_descripcion VARCHAR2(500);
    v_count NUMBER := 0;
BEGIN
    -- Solo usuarios con membresía crean planes
    SELECT id_persona BULK COLLECT INTO v_usuarios_membresia 
    FROM Usuarios WHERE membresia_activa = '1';
    
    -- Cada usuario con membresía crea 1-2 planes
    FOR i IN 1..v_usuarios_membresia.COUNT LOOP
        FOR j IN 1..DBMS_RANDOM.VALUE(1, 2) LOOP
            v_count := v_count + 1;
            
            -- Nombres de planes privados (sin "Mi Plan")
            v_nombre := CASE MOD(v_count, 10)
                WHEN 0 THEN 'Plan Pérdida de Peso'
                WHEN 1 THEN 'Plan Ganancia Muscular'
                WHEN 2 THEN 'Plan Definición'
                WHEN 3 THEN 'Plan Resistencia'
                WHEN 4 THEN 'Plan Fuerza'
                WHEN 5 THEN 'Plan Transformación'
                WHEN 6 THEN 'Plan Iniciación'
                WHEN 7 THEN 'Plan Atlético'
                WHEN 8 THEN 'Plan Wellness'
                ELSE 'Plan HIIT'
            END;
            
            -- Duraciones variadas
            v_duracion := CASE MOD(v_count, 6)
                WHEN 0 THEN '4 semanas'
                WHEN 1 THEN '6 semanas'
                WHEN 2 THEN '8 semanas'
                WHEN 3 THEN '12 semanas'
                WHEN 4 THEN '16 semanas'
                ELSE '20 semanas'
            END;
            
            -- Descripciones realistas
            v_descripcion := CASE MOD(v_count, 10)
                WHEN 0 THEN 'Plan diseñado para pérdida de peso con déficit calórico controlado'
                WHEN 1 THEN 'Programa de hipertrofia con énfasis en ejercicios compuestos'
                WHEN 2 THEN 'Reducir grasa mientras mantengo masa muscular'
                WHEN 3 THEN 'Mejora de capacidad aeróbica y resistencia física'
                WHEN 4 THEN 'Desarrollo de fuerza máxima con cargas progresivas'
                WHEN 5 THEN 'Plan integral combinando fuerza, cardio y nutrición'
                WHEN 6 THEN 'Comienzo de mi viaje fitness con fundamentos sólidos'
                WHEN 7 THEN 'Maximizar mi potencial deportivo'
                WHEN 8 THEN 'Equilibrio entre fitness, nutrición y bienestar'
                ELSE 'Entrenamientos de alta intensidad para quemar grasa'
            END;
            
            INSERT INTO PlanesFitness (nombre, duracion, descripcion)
            VALUES (v_nombre, v_duracion, v_descripcion);
            
            IF MOD(v_count, 200) = 0 THEN
                COMMIT;
            END IF;
        END LOOP;
    END LOOP;
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE('PlanesFitness creados: ' || v_count);
END;
/

""")
    
    def generar_planes_usuarios(self, output):
        """Genera PlanesFitnessDeUsuarios - Relación usuario-plan"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: PLANESFITNESSDE USUARIOS\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_usuarios_membresia id_array;
    v_planes id_array;
    v_usuario_idx NUMBER := 1;
    v_contador NUMBER := 0;
BEGIN
    SELECT id_persona BULK COLLECT INTO v_usuarios_membresia FROM Usuarios WHERE membresia_activa = '1';
    SELECT id_plan BULK COLLECT INTO v_planes FROM PlanesFitness;
    
    -- Asignar planes a usuarios (cada plan a su creador)
    FOR i IN 1..v_planes.COUNT LOOP
        INSERT INTO PlanesFitnessDeUsuarios (usuario, planfitness, comentario_usuario)
        VALUES (
            v_usuarios_membresia(v_usuario_idx),
            v_planes(i),
            CASE WHEN MOD(i, 3) = 0 THEN 
                CASE MOD(i, 4)
                    WHEN 0 THEN 'Siguiendo este plan fielmente'
                    WHEN 1 THEN 'Me está funcionando muy bien'
                    WHEN 2 THEN 'Plan basado en recomendaciones del especialista'
                    ELSE NULL
                END
            ELSE NULL END
        );
        
        v_contador := v_contador + 1;
        
        -- Avanzar al siguiente usuario cada 1-2 planes
        IF MOD(i, CASE WHEN MOD(i, 2) = 0 THEN 2 ELSE 1 END) = 0 THEN
            v_usuario_idx := v_usuario_idx + 1;
            IF v_usuario_idx > v_usuarios_membresia.COUNT THEN
                v_usuario_idx := 1;
            END IF;
        END IF;
        
        IF MOD(v_contador, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_rutinas(self, output):
        """Genera Rutinas - Parte de planes privados de usuarios"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: RUTINAS (Parte de planes de usuarios)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_planes id_array;
    v_plan_idx NUMBER;
    v_count NUMBER := 0;
    v_nombre VARCHAR2(100);
    v_descripcion VARCHAR2(1000);
    v_dias VARCHAR2(50);
BEGIN
    SELECT id_plan BULK COLLECT INTO v_planes FROM PlanesFitness;
    
    -- 3-5 rutinas por plan
    FOR i IN 1..v_planes.COUNT LOOP
        v_plan_idx := v_planes(i);
        
        FOR j IN 1..DBMS_RANDOM.VALUE(3, 5) LOOP
            SELECT COUNT(*) INTO v_count FROM Rutinas WHERE planfitness = v_plan_idx;
            
            -- Nombres variados
            v_nombre := CASE MOD(j, 8)
                WHEN 0 THEN 'Tren Superior'
                WHEN 1 THEN 'Tren Inferior'
                WHEN 2 THEN 'Full Body'
                WHEN 3 THEN 'Cardio HIIT'
                WHEN 4 THEN 'Cardio Moderado'
                WHEN 5 THEN 'Fuerza'
                WHEN 6 THEN 'Circuito'
                ELSE 'Resistencia'
            END;
            
            v_descripcion := CASE MOD(j, 6)
                WHEN 0 THEN 'Rutina enfocada en desarrollo de fuerza máxima con cargas pesadas'
                WHEN 1 THEN 'Entrenamiento de volumen para hipertrofia muscular'
                WHEN 2 THEN 'Sesión de cuerpo completo con ejercicios compuestos'
                WHEN 3 THEN 'Intervalos de alta intensidad para máxima quema calórica'
                WHEN 4 THEN 'Cardio steady-state para mejora cardiovascular'
                ELSE 'Circuito funcional con movimientos multiarticulares'
            END;
            
            -- Días variados
            v_dias := CASE MOD(j, 6)
                WHEN 0 THEN 'Lunes, Miércoles, Viernes'
                WHEN 1 THEN 'Martes, Jueves, Sábado'
                WHEN 2 THEN 'Lunes, Martes, Jueves, Viernes'
                WHEN 3 THEN 'Lunes, Miércoles, Viernes, Sábado'
                WHEN 4 THEN 'Lunes a Viernes'
                ELSE 'Lunes, Miércoles, Viernes, Domingo'
            END;
            
            INSERT INTO Rutinas (
                planfitness, nombre_rutina, descripcion, dias_semana,
                duracion_rutina_min, nivel_dificultad, tipo_entrenamiento
            ) VALUES (
                v_plan_idx,
                v_nombre,
                v_descripcion,
                v_dias,
                DBMS_RANDOM.VALUE(40, 90),
                CASE MOD(j, 3) WHEN 0 THEN 'Básico' WHEN 1 THEN 'Intermedio' ELSE 'Avanzado' END,
                CASE WHEN MOD(j, 2) = 0 THEN 'Fuerza' ELSE 'Cardio' END
            );
        END LOOP;
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_comidas(self, output):
        """Genera Comidas - Parte de planes de usuarios"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: COMIDAS (Parte de planes de usuarios)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_planes id_array;
    v_plan_idx NUMBER;
    v_count NUMBER := 0;
    v_nombre VARCHAR2(100);
    v_calorias NUMBER(5);
    v_carbohidratos NUMBER(5,2);
    v_grasas NUMBER(5,2);
    v_proteinas NUMBER(5,2);
BEGIN
    SELECT id_plan BULK COLLECT INTO v_planes FROM PlanesFitness;
    
    -- 5-8 comidas por plan
    FOR i IN 1..v_planes.COUNT LOOP
        v_plan_idx := v_planes(i);
        
        FOR j IN 1..DBMS_RANDOM.VALUE(5, 8) LOOP
            SELECT COUNT(*) INTO v_count FROM Comidas WHERE planfitness = v_plan_idx;
            
            -- Nombres y macros según tipo de comida
            CASE MOD(j, 6)
                WHEN 0 THEN  -- Desayuno
                    v_nombre := 'Desayuno';
                    v_calorias := DBMS_RANDOM.VALUE(450, 520);
                    v_carbohidratos := ROUND(DBMS_RANDOM.VALUE(35, 55), 2);
                    v_grasas := ROUND(DBMS_RANDOM.VALUE(15, 25), 2);
                    v_proteinas := ROUND(DBMS_RANDOM.VALUE(30, 45), 2);
                WHEN 1 THEN  -- Almuerzo
                    v_nombre := 'Almuerzo';
                    v_calorias := DBMS_RANDOM.VALUE(550, 700);
                    v_carbohidratos := ROUND(DBMS_RANDOM.VALUE(50, 80), 2);
                    v_grasas := ROUND(DBMS_RANDOM.VALUE(18, 28), 2);
                    v_proteinas := ROUND(DBMS_RANDOM.VALUE(40, 55), 2);
                WHEN 2 THEN  -- Cena
                    v_nombre := 'Cena';
                    v_calorias := DBMS_RANDOM.VALUE(400, 500);
                    v_carbohidratos := ROUND(DBMS_RANDOM.VALUE(30, 50), 2);
                    v_grasas := ROUND(DBMS_RANDOM.VALUE(12, 20), 2);
                    v_proteinas := ROUND(DBMS_RANDOM.VALUE(35, 48), 2);
                WHEN 3 THEN  -- Snack Pre-Entreno
                    v_nombre := 'Snack Pre-Entreno';
                    v_calorias := DBMS_RANDOM.VALUE(200, 300);
                    v_carbohidratos := ROUND(DBMS_RANDOM.VALUE(35, 50), 2);
                    v_grasas := ROUND(DBMS_RANDOM.VALUE(5, 10), 2);
                    v_proteinas := ROUND(DBMS_RANDOM.VALUE(10, 18), 2);
                WHEN 4 THEN  -- Post-Entreno
                    v_nombre := 'Batido Post-Entreno';
                    v_calorias := DBMS_RANDOM.VALUE(300, 400);
                    v_carbohidratos := ROUND(DBMS_RANDOM.VALUE(40, 60), 2);
                    v_grasas := ROUND(DBMS_RANDOM.VALUE(8, 15), 2);
                    v_proteinas := ROUND(DBMS_RANDOM.VALUE(25, 35), 2);
                ELSE  -- Merienda
                    v_nombre := 'Merienda';
                    v_calorias := DBMS_RANDOM.VALUE(150, 250);
                    v_carbohidratos := ROUND(DBMS_RANDOM.VALUE(20, 35), 2);
                    v_grasas := ROUND(DBMS_RANDOM.VALUE(5, 12), 2);
                    v_proteinas := ROUND(DBMS_RANDOM.VALUE(8, 15), 2);
            END CASE;
            
            INSERT INTO Comidas (planfitness, nombre_comida, calorias, carbohidratos, grasas, proteinas)
            VALUES (v_plan_idx, v_nombre, v_calorias, v_carbohidratos, v_grasas, v_proteinas);
        END LOOP;
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_habitos(self, output):
        """Genera Hábitos - Parte de planes de usuarios"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: HABITOS (Parte de planes de usuarios)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_planes id_array;
    v_plan_idx NUMBER;
    v_count NUMBER := 0;
    v_nombre VARCHAR2(100);
    v_descripcion VARCHAR2(500);
    v_frecuencia VARCHAR2(200);
BEGIN
    SELECT id_plan BULK COLLECT INTO v_planes FROM PlanesFitness;
    
    -- 3-5 hábitos por plan
    FOR i IN 1..v_planes.COUNT LOOP
        v_plan_idx := v_planes(i);
        
        FOR j IN 1..DBMS_RANDOM.VALUE(3, 5) LOOP
            SELECT COUNT(*) INTO v_count FROM Habitos WHERE planfitness = v_plan_idx;
            
            CASE MOD(j, 8)
                WHEN 0 THEN
                    v_nombre := 'Hidratación Diaria';
                    v_descripcion := 'Consumir 2-3 litros de agua al día para hidratación óptima';
                    v_frecuencia := 'Diario';
                WHEN 1 THEN
                    v_nombre := 'Estiramientos';
                    v_descripcion := '10 minutos de movilidad articular';
                    v_frecuencia := 'Diario';
                WHEN 2 THEN
                    v_nombre := 'Descanso';
                    v_descripcion := 'Dormir 7-9 horas para óptima recuperación muscular';
                    v_frecuencia := 'Diario';
                WHEN 3 THEN
                    v_nombre := 'Meditación';
                    v_descripcion := '15 minutos de práctica de mindfulness';
                    v_frecuencia := '5 veces por semana';
                WHEN 4 THEN
                    v_nombre := 'Meal Prep';
                    v_descripcion := 'Preparación de comidas saludables para la semana';
                    v_frecuencia := 'Semanal';
                WHEN 5 THEN
                    v_nombre := 'Suplementación';
                    v_descripcion := 'Vitaminas, omega-3 y proteína según requerimientos';
                    v_frecuencia := 'Diario';
                WHEN 6 THEN
                    v_nombre := 'Registro de Progresos';
                    v_descripcion := 'Medición de peso, medidas y fotos de progreso';
                    v_frecuencia := 'Semanal';
                ELSE
                    v_nombre := 'Caminata Activa';
                    v_descripcion := 'Objetivo de 10,000 pasos diarios';
                    v_frecuencia := 'Diario';
            END CASE;
            
            INSERT INTO Habitos (planfitness, nombre_habito, descripcion, frecuencia)
            VALUES (v_plan_idx, v_nombre, v_descripcion, v_frecuencia);
        END LOOP;
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_ejercicios(self, output):
        """Genera Ejercicios - Parte de rutinas de usuarios"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: EJERCICIOS (Parte de rutinas de usuarios)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_rutinas id_array;
    v_tipo VARCHAR2(50);
    v_nombre VARCHAR2(100);
    v_descripcion VARCHAR2(500);
BEGIN
    SELECT id_rutina BULK COLLECT INTO v_rutinas FROM Rutinas;
    
    FOR i IN 1..v_rutinas.COUNT LOOP
        SELECT tipo_entrenamiento INTO v_tipo FROM Rutinas WHERE id_rutina = v_rutinas(i);
        
        -- 5-8 ejercicios por rutina
        FOR j IN 1..DBMS_RANDOM.VALUE(5, 8) LOOP
            IF v_tipo = 'Fuerza' THEN
                -- Ejercicios de fuerza variados
                CASE MOD(j + i, 15)
                    WHEN 0 THEN
                        v_nombre := 'Sentadillas';
                        v_descripcion := 'Ejercicio fundamental para tren inferior';
                    WHEN 1 THEN
                        v_nombre := 'Press de Banca';
                        v_descripcion := 'Desarrollo de pecho, hombros y tríceps';
                    WHEN 2 THEN
                        v_nombre := 'Peso Muerto';
                        v_descripcion := 'Ejercicio completo para cadena posterior';
                    WHEN 3 THEN
                        v_nombre := 'Dominadas';
                        v_descripcion := 'Excelente para desarrollar espalda';
                    WHEN 4 THEN
                        v_nombre := 'Press Militar';
                        v_descripcion := 'Desarrollo de hombros y core';
                    WHEN 5 THEN
                        v_nombre := 'Remo con Barra';
                        v_descripcion := 'Fortalece toda la espalda';
                    WHEN 6 THEN
                        v_nombre := 'Fondos en Paralelas';
                        v_descripcion := 'Tríceps y pecho inferior';
                    WHEN 7 THEN
                        v_nombre := 'Curl de Bíceps';
                        v_descripcion := 'Aislamiento de bíceps';
                    WHEN 8 THEN
                        v_nombre := 'Extensiones de Tríceps';
                        v_descripcion := 'Desarrollo de tríceps';
                    WHEN 9 THEN
                        v_nombre := 'Zancadas';
                        v_descripcion := 'Piernas y glúteos';
                    WHEN 10 THEN
                        v_nombre := 'Hip Thrust';
                        v_descripcion := 'Glúteos e isquiotibiales';
                    WHEN 11 THEN
                        v_nombre := 'Press Inclinado';
                        v_descripcion := 'Pecho superior';
                    WHEN 12 THEN
                        v_nombre := 'Remo en T';
                        v_descripcion := 'Espalda media y grosor';
                    WHEN 13 THEN
                        v_nombre := 'Face Pulls';
                        v_descripcion := 'Hombro posterior';
                    ELSE
                        v_nombre := 'Plancha';
                        v_descripcion := 'Core y estabilidad';
                END CASE;
                
                INSERT INTO Ejercicios (id_rutina, nombre_ejercicio, series, repeticiones, descripcion, duracion_min)
                VALUES (
                    v_rutinas(i),
                    v_nombre,
                    DBMS_RANDOM.VALUE(3, 4),
                    CASE 
                        WHEN v_nombre IN ('Sentadillas', 'Peso Muerto') THEN DBMS_RANDOM.VALUE(6, 10)
                        WHEN v_nombre IN ('Press de Banca', 'Press Militar') THEN DBMS_RANDOM.VALUE(8, 12)
                        ELSE DBMS_RANDOM.VALUE(10, 15)
                    END,
                    v_descripcion,
                    NULL
                );
            ELSE
                -- Ejercicios de cardio variados
                CASE MOD(j + i, 10)
                    WHEN 0 THEN
                        v_nombre := 'Burpees';
                        v_descripcion := 'Ejercicio explosivo de cuerpo completo';
                    WHEN 1 THEN
                        v_nombre := 'Mountain Climbers';
                        v_descripcion := 'Cardio intenso con trabajo de core';
                    WHEN 2 THEN
                        v_nombre := 'Running';
                        v_descripcion := 'Carrera continua a ritmo moderado';
                    WHEN 3 THEN
                        v_nombre := 'Jumping Jacks';
                        v_descripcion := 'Calentamiento y activación';
                    WHEN 4 THEN
                        v_nombre := 'Box Jumps';
                        v_descripcion := 'Pliometría para potencia';
                    WHEN 5 THEN
                        v_nombre := 'Battle Ropes';
                        v_descripcion := 'Acondicionamiento tren superior';
                    WHEN 6 THEN
                        v_nombre := 'Bicicleta Estática';
                        v_descripcion := 'Cardio de bajo impacto';
                    WHEN 7 THEN
                        v_nombre := 'Remo Indoor';
                        v_descripcion := 'Cardio completo bajo impacto';
                    WHEN 8 THEN
                        v_nombre := 'Saltos de Cuerda';
                        v_descripcion := 'Cardio intenso y coordinación';
                    ELSE
                        v_nombre := 'Sprint Intervals';
                        v_descripcion := 'Intervalos de alta intensidad';
                END CASE;
                
                INSERT INTO Ejercicios (id_rutina, nombre_ejercicio, series, repeticiones, descripcion, duracion_min)
                VALUES (
                    v_rutinas(i),
                    v_nombre,
                    NULL,
                    NULL,
                    v_descripcion,
                    CASE 
                        WHEN v_nombre IN ('Running', 'Bicicleta Estática', 'Remo Indoor') THEN DBMS_RANDOM.VALUE(20, 40)
                        WHEN v_nombre IN ('Burpees', 'Mountain Climbers', 'Jumping Jacks') THEN DBMS_RANDOM.VALUE(3, 7)
                        ELSE DBMS_RANDOM.VALUE(5, 15)
                    END
                );
            END IF;
        END LOOP;
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_rutinas_ejemplo(self, output):
        """Genera RutinasDeEjemplo - Creadas por especialistas"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: RUTINASDEEJEMPLO (10,000 - Creadas por especialistas)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_especialistas id_array;
    v_esp_idx NUMBER;
    v_count NUMBER := 0;
    v_nombre VARCHAR2(100);
    v_descripcion VARCHAR2(1000);
    v_dias VARCHAR2(50);
BEGIN
    SELECT id_persona BULK COLLECT INTO v_especialistas FROM EspecialistasFitness;
    
    FOR i IN 1..10000 LOOP
        v_esp_idx := MOD(i, v_especialistas.COUNT) + 1;
        
        SELECT COUNT(*) INTO v_count 
        FROM RutinasDeEjemplo WHERE especialista_fitness = v_especialistas(v_esp_idx);
        
        -- Nombres muy variados
        v_nombre := CASE MOD(i, 20)
            WHEN 0 THEN 'Hipertrofia Tren Superior ' || (v_count + 1)
            WHEN 1 THEN 'HIIT Quema Grasa ' || (v_count + 1)
            WHEN 2 THEN 'Fuerza Powerlifting 5x5 ' || (v_count + 1)
            WHEN 3 THEN 'Full Body Funcional ' || (v_count + 1)
            WHEN 4 THEN 'Cardio LISS Resistencia ' || (v_count + 1)
            WHEN 5 THEN 'Push Pull Legs ' || (v_count + 1)
            WHEN 6 THEN 'CrossFit WOD ' || (v_count + 1)
            WHEN 7 THEN 'Tonificación ' || (v_count + 1)
            WHEN 8 THEN 'Ganancia Masa Muscular ' || (v_count + 1)
            WHEN 9 THEN 'Definición Pre-Verano ' || (v_count + 1)
            WHEN 10 THEN 'Resistencia Corredor ' || (v_count + 1)
            WHEN 11 THEN 'Fuerza Atlética ' || (v_count + 1)
            WHEN 12 THEN 'Circuito Metabólico ' || (v_count + 1)
            WHEN 13 THEN 'Upper Lower Split ' || (v_count + 1)
            WHEN 14 THEN 'Cardio Intervalado ' || (v_count + 1)
            WHEN 15 THEN 'Calistenia Avanzada ' || (v_count + 1)
            WHEN 16 THEN 'Glúteos Intensivo ' || (v_count + 1)
            WHEN 17 THEN 'Core y Abdomen ' || (v_count + 1)
            WHEN 18 THEN 'Movilidad y Flexibilidad ' || (v_count + 1)
            ELSE 'Iniciación Fitness ' || (v_count + 1)
        END;
        
        -- Descripciones variadas
        v_descripcion := CASE MOD(i, 12)
            WHEN 0 THEN 'Rutina diseñada para máximo desarrollo muscular con volumen alto'
            WHEN 1 THEN 'Intervalos de alta intensidad para quemar grasa rápidamente'
            WHEN 2 THEN 'Programa de fuerza basado en levantamientos básicos pesados'
            WHEN 3 THEN 'Entrenamiento completo con ejercicios funcionales multiarticulares'
            WHEN 4 THEN 'Cardio de baja intensidad para mejorar resistencia aeróbica'
            WHEN 5 THEN 'Split clásico para desarrollo equilibrado de todo el cuerpo'
            WHEN 6 THEN 'WOD estilo CrossFit para condicionamiento total'
            WHEN 7 THEN 'Programa específico para tonificar y definir'
            WHEN 8 THEN 'Plan de hipertrofia con énfasis en volumen progresivo'
            WHEN 9 THEN 'Rutina para reducir grasa manteniendo músculo'
            WHEN 10 THEN 'Entrenamiento específico para corredores'
            ELSE 'Desarrollo de fuerza aplicable a rendimiento deportivo'
        END;
        
        -- Días variados
        v_dias := CASE MOD(i, 6)
            WHEN 0 THEN 'Lunes, Miércoles, Viernes'
            WHEN 1 THEN 'Martes, Jueves, Sábado'
            WHEN 2 THEN 'Lunes, Martes, Jueves, Viernes'
            WHEN 3 THEN 'Lunes, Miércoles, Viernes, Sábado'
            WHEN 4 THEN 'Lunes a Viernes'
            ELSE 'Lunes, Miércoles, Viernes, Domingo'
        END;
        
        INSERT INTO RutinasDeEjemplo (
            especialista_fitness, nombre_rutina, descripcion, dias_semana,
            duracion_rutina, nivel_dificultad, tipo_entrenamiento
        ) VALUES (
            v_especialistas(v_esp_idx),
            v_nombre,
            v_descripcion,
            v_dias,
            DBMS_RANDOM.VALUE(40, 90),
            CASE MOD(i, 3) WHEN 0 THEN 'Básico' WHEN 1 THEN 'Intermedio' ELSE 'Avanzado' END,
            CASE WHEN MOD(i, 2) = 0 THEN 'Fuerza' ELSE 'Cardio' END
        );
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_ejercicios_ejemplo(self, output):
        """Genera EjerciciosDeRutinasDeEjemplo"""
        output.write("\n-- =================================================\n")
        output.write("-- TABLA: EJERCICIOSDERUTINASDEEJEMPLO (Ejercicios de calidad)\n")
        output.write("-- =================================================\n\n")
        
        output.write("""DECLARE
    TYPE id_array IS TABLE OF NUMBER(10);
    v_rutinas id_array;
    v_tipo VARCHAR2(50);
    v_nombre VARCHAR2(100);
    v_descripcion VARCHAR2(500);
    v_series NUMBER(3);
    v_repeticiones NUMBER(3);
    v_duracion NUMBER(3);
BEGIN
    SELECT id_rutina_ejemplo BULK COLLECT INTO v_rutinas FROM RutinasDeEjemplo;
    
    FOR i IN 1..v_rutinas.COUNT LOOP
        SELECT tipo_entrenamiento INTO v_tipo 
        FROM RutinasDeEjemplo WHERE id_rutina_ejemplo = v_rutinas(i);
        
        IF v_tipo = 'Fuerza' THEN
            -- 4-6 ejercicios de fuerza por rutina
            FOR j IN 1..DBMS_RANDOM.VALUE(4, 6) LOOP
                CASE MOD(j + i, 15)
                    WHEN 0 THEN
                        v_nombre := 'Sentadillas Profundas';
                        v_descripcion := 'Ejercicio fundamental para cuádriceps y glúteos';
                        v_series := 4; v_repeticiones := 12;
                    WHEN 1 THEN
                        v_nombre := 'Press Banca Plano';
                        v_descripcion := 'Desarrollo completo de pecho';
                        v_series := 4; v_repeticiones := 10;
                    WHEN 2 THEN
                        v_nombre := 'Peso Muerto Rumano';
                        v_descripcion := 'Isquiotibiales y espalda baja';
                        v_series := 3; v_repeticiones := 8;
                    WHEN 3 THEN
                        v_nombre := 'Dominadas Pronadas';
                        v_descripcion := 'Espalda dorsal ancho';
                        v_series := 4; v_repeticiones := 10;
                    WHEN 4 THEN
                        v_nombre := 'Press Militar Parado';
                        v_descripcion := 'Hombros y core estabilizador';
                        v_series := 3; v_repeticiones := 12;
                    WHEN 5 THEN
                        v_nombre := 'Remo con Barra';
                        v_descripcion := 'Grosor de espalda media';
                        v_series := 4; v_repeticiones := 10;
                    WHEN 6 THEN
                        v_nombre := 'Fondos en Paralelas';
                        v_descripcion := 'Tríceps y pecho inferior';
                        v_series := 3; v_repeticiones := 12;
                    WHEN 7 THEN
                        v_nombre := 'Curl Barra Z';
                        v_descripcion := 'Masa de bíceps';
                        v_series := 3; v_repeticiones := 12;
                    WHEN 8 THEN
                        v_nombre := 'Extensión Tríceps';
                        v_descripcion := 'Definición de tríceps';
                        v_series := 3; v_repeticiones := 15;
                    WHEN 9 THEN
                        v_nombre := 'Zancadas';
                        v_descripcion := 'Piernas unilateral';
                        v_series := 3; v_repeticiones := 12;
                    WHEN 10 THEN
                        v_nombre := 'Hip Thrust';
                        v_descripcion := 'Glúteo máximo';
                        v_series := 4; v_repeticiones := 12;
                    WHEN 11 THEN
                        v_nombre := 'Press Inclinado';
                        v_descripcion := 'Pecho superior';
                        v_series := 3; v_repeticiones := 10;
                    WHEN 12 THEN
                        v_nombre := 'Remo en T';
                        v_descripcion := 'Espalda media';
                        v_series := 4; v_repeticiones := 10;
                    WHEN 13 THEN
                        v_nombre := 'Face Pulls';
                        v_descripcion := 'Deltoides posterior';
                        v_series := 3; v_repeticiones := 15;
                    ELSE
                        v_nombre := 'Plancha';
                        v_descripcion := 'Core isométrico';
                        v_series := 3; v_repeticiones := 1;
                END CASE;
                
                INSERT INTO EjerciciosDeRutinasDeEjemplo 
                    (id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, descripcion, duracion_min)
                VALUES (v_rutinas(i), v_nombre, v_series, v_repeticiones, v_descripcion, 
                    CASE WHEN v_nombre = 'Plancha' THEN 1 ELSE 5 END);
            END LOOP;
        ELSE
            -- 3-5 ejercicios de cardio
            FOR j IN 1..DBMS_RANDOM.VALUE(3, 5) LOOP
                CASE MOD(j + i, 10)
                    WHEN 0 THEN
                        v_nombre := 'Burpees';
                        v_descripcion := 'Explosivo total body';
                        v_duracion := 5;
                    WHEN 1 THEN
                        v_nombre := 'Mountain Climbers';
                        v_descripcion := 'Cardio con core';
                        v_duracion := 4;
                    WHEN 2 THEN
                        v_nombre := 'Running';
                        v_descripcion := 'Trote continuo';
                        v_duracion := 25;
                    WHEN 3 THEN
                        v_nombre := 'Jumping Jacks';
                        v_descripcion := 'Activación cardiovascular';
                        v_duracion := 3;
                    WHEN 4 THEN
                        v_nombre := 'Box Jumps';
                        v_descripcion := 'Potencia piernas';
                        v_duracion := 6;
                    WHEN 5 THEN
                        v_nombre := 'Battle Ropes';
                        v_descripcion := 'Tren superior cardio';
                        v_duracion := 5;
                    WHEN 6 THEN
                        v_nombre := 'Bicicleta HIIT';
                        v_descripcion := 'Intervalos alta intensidad';
                        v_duracion := 20;
                    WHEN 7 THEN
                        v_nombre := 'Remo Indoor';
                        v_descripcion := 'Cardio bajo impacto';
                        v_duracion := 20;
                    WHEN 8 THEN
                        v_nombre := 'Saltos de Cuerda';
                        v_descripcion := 'Coordinación y cardio';
                        v_duracion := 8;
                    ELSE
                        v_nombre := 'Sprint 30/30';
                        v_descripcion := 'Intervalos máxima intensidad';
                        v_duracion := 15;
                END CASE;
                
                INSERT INTO EjerciciosDeRutinasDeEjemplo 
                    (id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, descripcion, duracion_min)
                VALUES (v_rutinas(i), v_nombre, 1, 1, v_descripcion, v_duracion);
            END LOOP;
        END IF;
        
        IF MOD(i, 100) = 0 THEN
            COMMIT;
        END IF;
    END LOOP;
    COMMIT;
END;
/

""")
    
    def generar_verificacion(self, output):
        """Genera queries de verificación"""
        output.write("\n-- =================================================\n")
        output.write("-- VERIFICACIÓN DE DATOS\n")
        output.write("-- =================================================\n\n")
        
        output.write("""-- Conteo por tabla
SELECT 'Personas' tabla, COUNT(*) registros FROM Personas
UNION ALL SELECT 'EspecialistasFitness', COUNT(*) FROM EspecialistasFitness
UNION ALL SELECT 'Usuarios', COUNT(*) FROM Usuarios
UNION ALL SELECT 'Feedbacks', COUNT(*) FROM Feedbacks
UNION ALL SELECT 'Objetivos', COUNT(*) FROM Objetivos
UNION ALL SELECT 'Recomendaciones', COUNT(*) FROM Recomendaciones
UNION ALL SELECT 'ObjetivosRecomendaciones', COUNT(*) FROM ObjetivosRecomendaciones
UNION ALL SELECT 'Progresos', COUNT(*) FROM Progresos
UNION ALL SELECT 'PlanesFitness', COUNT(*) FROM PlanesFitness
UNION ALL SELECT 'PlanesFitnessDeUsuarios', COUNT(*) FROM PlanesFitnessDeUsuarios
UNION ALL SELECT 'Rutinas', COUNT(*) FROM Rutinas
UNION ALL SELECT 'Comidas', COUNT(*) FROM Comidas
UNION ALL SELECT 'Habitos', COUNT(*) FROM Habitos
UNION ALL SELECT 'Ejercicios', COUNT(*) FROM Ejercicios
UNION ALL SELECT 'RutinasDeEjemplo', COUNT(*) FROM RutinasDeEjemplo
UNION ALL SELECT 'EjerciciosDeRutinasDeEjemplo', COUNT(*) FROM EjerciciosDeRutinasDeEjemplo
ORDER BY tabla;

-- Usuarios con membresía
SELECT membresia_activa, COUNT(*) cantidad FROM Usuarios GROUP BY membresia_activa;

-- Distribución de calificaciones en Feedbacks
SELECT calificacion, COUNT(*) cantidad FROM Feedbacks GROUP BY calificacion ORDER BY calificacion;

-- Distribución de feedback por tipo
SELECT tipo_feedback, COUNT(*) cantidad FROM Feedbacks GROUP BY tipo_feedback ORDER BY tipo_feedback;

-- Ejercicios más comunes
SELECT nombre_ejercicio, COUNT(*) cantidad 
FROM Ejercicios 
GROUP BY nombre_ejercicio 
ORDER BY cantidad DESC 
FETCH FIRST 10 ROWS ONLY;

""")
    
    def generar_archivo_completo(self, nombre_archivo: str = "09_PoblarOK.sql"):
        """Genera el archivo SQL mejorado y corregido"""
        print("=" * 70)
        print("GENERADOR FITQUAL - DATOS REALISTAS CORREGIDOS")
        print("=" * 70)
        print(f"\nGenerando: {nombre_archivo}\n")
        
        with open(nombre_archivo, 'w', encoding='utf-8') as f:
            f.write("-- =================================================\n")
            f.write("-- FITQUAL - POBLACIÓN DE BASE DE DATOS MEJORADA\n")
            f.write(f"-- Generado: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("-- LÓGICA CORREGIDA: Usuarios crean planes privados\n")
            f.write("-- =================================================\n\n")
            f.write("SET DEFINE OFF;\n")
            f.write("SET SERVEROUTPUT ON SIZE UNLIMITED;\n")
            f.write("SET TIMING ON;\n\n")
            
            print("✓ Personas...")
            self.generar_personas(f)
            
            print("✓ EspecialistasFitness...")
            self.generar_especialistas(f)
            
            print("✓ Usuarios...")
            self.generar_usuarios(f)
            
            print("✓ Feedbacks (CORREGIDOS por tipo)...")
            self.generar_feedbacks(f)
            
            print("✓ Objetivos...")
            self.generar_objetivos(f)
            
            print("✓ Recomendaciones (de especialistas)...")
            self.generar_recomendaciones(f)
            
            print("✓ ObjetivosRecomendaciones...")
            self.generar_objetivos_recomendaciones(f)
            
            print("✓ Progresos...")
            self.generar_progresos(f)
            
            print("✓ PlanesFitness (CORREGIDOS - planes privados de usuarios)...")
            self.generar_planes_fitness(f)
            
            print("✓ PlanesFitnessDeUsuarios...")
            self.generar_planes_usuarios(f)
            
            print("✓ Rutinas (de planes de usuarios)...")
            self.generar_rutinas(f)
            
            print("✓ Comidas (de planes de usuarios)...")
            self.generar_comidas(f)
            
            print("✓ Hábitos (de planes de usuarios)...")
            self.generar_habitos(f)
            
            print("✓ Ejercicios (de rutinas de usuarios)...")
            self.generar_ejercicios(f)
            
            print("✓ RutinasDeEjemplo (creadas por especialistas)...")
            self.generar_rutinas_ejemplo(f)
            
            print("✓ EjerciciosDeRutinasDeEjemplo...")
            self.generar_ejercicios_ejemplo(f)
            
            print("✓ Verificación...")
            self.generar_verificacion(f)
            
            f.write("\nSET DEFINE ON;\n")
            f.write("-- FIN\n")
        
        print("\n" + "=" * 70)
        print(f"✓ COMPLETADO: {nombre_archivo}")
        print("=" * 70)
        print("\n🎯 LÓGICA CORREGIDA:")
        print("   ✓ PlanesFitness: Planes privados de usuarios con membresía")
        print("   ✓ Rutinas/Comidas/Hábitos/Ejercicios: Parte de planes de usuarios")
        print("   ✓ RutinasDeEjemplo: Creadas por especialistas (público)")
        print("   ✓ Feedbacks: Correctos según tipo_feedback")
        print("   ✓ Recomendaciones: De especialistas para usuarios")
        print("\n💪 ¡Base de datos con lógica correcta de la app!")      


def main():
    try:
        print("\n" + "=" * 70)
        print("GENERADOR FITQUAL DATABASE - VERSIÓN CORREGIDA")
        print("=" * 70 + "\n")
        
        num = input("Personas [10000]: ").strip()
        num = int(num) if num else 10000
        
        archivo = input("Archivo [09_PoblarOK.sql]: ").strip()
        archivo = archivo if archivo else "09_PoblarOK.sql"
        if not archivo.endswith('.sql'):
            archivo += '.sql'
        
        print()
        
        gen = FitQualCompletoDatabaseGenerator(num)
        gen.generar_archivo_completo(archivo)
        
    except KeyboardInterrupt:
        print("\n\n✗ Cancelado")
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()