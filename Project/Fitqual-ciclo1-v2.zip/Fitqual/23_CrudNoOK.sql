-- -------------------
-- CRUDNoOK.sql
-- Intento de ingreso de datos erroneos protegidos por los procedimientos 
-- ------------------

SET SERVEROUTPUT ON;

BEGIN
    DBMS_OUTPUT.PUT_LINE('===============================================');
    DBMS_OUTPUT.PUT_LINE('    PRUEBAS CRUD - DATOS INCORRECTOS');
    DBMS_OUTPUT.PUT_LINE('===============================================');
END;
/

-- =====================================================
-- PAQUETE: PK_PERSONAS - ERRORES
-- =====================================================

-- ERROR: Correo inválido (sin @)
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Correo sin @ <<<');
    PK_PERSONAS.AD_PERSONAS('Juan Error', 'correosinArroba.com', 'Pass123', 'Usuario');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Correo muy corto
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Correo muy corto <<<');
    PK_PERSONAS.AD_PERSONAS('Maria Error', 'a@b.', 'Pass123', 'Usuario');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Rol inválido
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Rol inválido <<<');
    PK_PERSONAS.AD_PERSONAS('Carlos Error', 'carlos@gmail.com', 'Pass123', 'Administrador');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Correo duplicado
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Correo duplicado <<<');
    -- Primero insertar un correo
    PK_PERSONAS.AD_PERSONAS('Test Duplicado 1', 'correo.duplicado@test.com', 'Pass123', 'Usuario');
    -- Intentar duplicarlo
    PK_PERSONAS.AD_PERSONAS('Test Duplicado 2', 'correo.duplicado@test.com', 'Pass456', 'Usuario');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Modificar persona inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Modificar ID inexistente <<<');
    PK_PERSONAS.MO_PERSONAS(999999, 'Nombre', 'correo@test.com', 'Pass', 'Usuario');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Eliminar persona inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Eliminar ID inexistente <<<');
    PK_PERSONAS.DEL_PERSONAS(999999);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- =====================================================
-- ERRORES EN TABLAS RELACIONADAS
-- =====================================================

-- ERROR: Usuario con edad inválida (muy joven)
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Edad menor a 10 años <<<');
    INSERT INTO Personas VALUES (99991, 'Niño Test', 'nino@test.com', 'Pass123', 'Usuario');
    INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, membresia_activa)
    VALUES (99991, 'Meta', 'Básico', 3, 5, 'M', 70.0, 1.70, '0');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Usuario con peso inválido
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Peso menor a 30 kg <<<');
    INSERT INTO Personas VALUES (99992, 'Peso Error', 'peso@test.com', 'Pass123', 'Usuario');
    INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, membresia_activa)
    VALUES (99992, 'Meta', 'Básico', 3, 25, 'M', 20.0, 1.70, '0');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Usuario con altura inválida
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Altura menor a 1.10 m <<<');
    INSERT INTO Personas VALUES (99993, 'Altura Error', 'altura@test.com', 'Pass123', 'Usuario');
    INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, membresia_activa)
    VALUES (99993, 'Meta', 'Básico', 3, 25, 'M', 70.0, 0.90, '0');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Usuario con nivel inválido
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Nivel inválido <<<');
    INSERT INTO Personas VALUES (99994, 'Nivel Error', 'nivel@test.com', 'Pass123', 'Usuario');
    INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, membresia_activa)
    VALUES (99994, 'Meta', 'Experto', 3, 25, 'M', 70.0, 1.70, '0');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Usuario con sexo inválido
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Sexo inválido <<<');
    INSERT INTO Personas VALUES (99995, 'Sexo Error', 'sexo@test.com', 'Pass123', 'Usuario');
    INSERT INTO Usuarios (id_persona, meta, nivel, frecuencia_entreno_semanal, edad, sexo, peso, altura, membresia_activa)
    VALUES (99995, 'Meta', 'Básico', 3, 25, 'X', 70.0, 1.70, '0');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Feedback con calificación inválida
DECLARE
    v_usuario NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Calificación fuera de rango (1-5) <<<');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
    VALUES (v_usuario, 'Test', SYSDATE, 10, 'Sistema', 'Público');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Feedback con tipo inválido
DECLARE
    v_usuario NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Tipo de feedback inválido <<<');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
    VALUES (v_usuario, 'Test', SYSDATE, 5, 'TipoInvalido', 'Público');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Feedback con fecha futura
DECLARE
    v_usuario NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Fecha de feedback futura <<<');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
    VALUES (v_usuario, 'Test', SYSDATE + 10, 5, 'Sistema', 'Público');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- =====================================================
-- PAQUETE: PK_OBJETIVOS - ERRORES
-- =====================================================

-- ERROR: Objetivo con fecha futura
DECLARE
    v_usuario NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Objetivo con fecha futura <<<');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    PK_OBJETIVOS.AD_OBJETIVOS(v_usuario, 'Objetivo', 'Contenido', SYSDATE + 100);
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Recomendación con tipo de enfoque inválido
DECLARE
    v_esp NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Tipo de enfoque inválido <<<');
    SELECT MIN(id_persona) INTO v_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
    PK_OBJETIVOS.AD_RECOMENDACIONES(v_esp, 'Contenido', SYSDATE, 'TipoInvalido');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Modificar objetivo inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Modificar objetivo inexistente <<<');
    PK_OBJETIVOS.MO_OBJETIVOS(999999, 'Nombre', 'Contenido');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Eliminar recomendación inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Eliminar recomendación inexistente <<<');
    PK_OBJETIVOS.DEL_RECOMENDACIONES(999999);
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- =====================================================
-- PAQUETE: PK_PLANFITNESS - ERRORES
-- =====================================================

-- ERROR: Plan con nombre duplicado
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Nombre de plan duplicado <<<');
    PK_PLANFITNESS.AD_PLANFITNESS('Plan Test Pérdida Peso (Actualizado)', '12 semanas', 'Desc');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Duración con formato inválido
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Duración con formato inválido <<<');
    PK_PLANFITNESS.AD_PLANFITNESS('Plan Error Duracion', '12 años', 'Descripción');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Modificar plan inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Modificar plan inexistente <<<');
    PK_PLANFITNESS.MO_PLANFITNESS(999999, 'Nombre', '8 semanas', 'Desc');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Rutina con nivel inválido
DECLARE
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Rutina con nivel inválido <<<');
    SELECT MIN(id_plan) INTO v_plan FROM PlanesFitness WHERE ROWNUM = 1;
    INSERT INTO Rutinas (planfitness, nombre_rutina, descripcion, dias_semana, duracion_rutina_min, nivel_dificultad, tipo_entrenamiento)
    VALUES (v_plan, 'Rutina Error', 'Desc', 'Lunes', 45, 'Profesional', 'Fuerza');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Rutina con tipo de entrenamiento inválido
DECLARE
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Tipo de entrenamiento inválido <<<');
    SELECT MIN(id_plan) INTO v_plan FROM PlanesFitness WHERE ROWNUM = 1;
    INSERT INTO Rutinas (planfitness, nombre_rutina, descripcion, dias_semana, duracion_rutina_min, nivel_dificultad, tipo_entrenamiento)
    VALUES (v_plan, 'Rutina Error 2', 'Desc', 'Lunes', 45, 'Básico', 'Yoga');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Comida con calorías negativas
DECLARE
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Calorías negativas <<<');
    SELECT MIN(id_plan) INTO v_plan FROM PlanesFitness WHERE ROWNUM = 1;
    INSERT INTO Comidas (planfitness, nombre_comida, calorias, carbohidratos, grasas, proteinas)
    VALUES (v_plan, 'Comida Error', -100, 50.0, 10.0, 20.0);
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- =====================================================
-- PAQUETE: PK_ESPECIALISTA_FITNESS - ERRORES
-- =====================================================

-- ERROR: Rutina de ejemplo con nivel inválido
DECLARE
    v_esp NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Nivel de dificultad inválido <<<');
    SELECT MIN(id_persona) INTO v_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
    PK_ESPECIALISTA_FITNESS.AD_RUTINAS_EJEMPLO(v_esp, 'Rutina Error', 'Desc', 'Lunes', 45, 'Maestro', 'Fuerza');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Rutina de ejemplo con tipo inválido
DECLARE
    v_esp NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Tipo de entrenamiento inválido en ejemplo <<<');
    SELECT MIN(id_persona) INTO v_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
    PK_ESPECIALISTA_FITNESS.AD_RUTINAS_EJEMPLO(v_esp, 'Rutina Error 2', 'Desc', 'Lunes', 45, 'Básico', 'Pilates');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Modificar rutina de ejemplo inexistente
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Modificar rutina de ejemplo inexistente <<<');
    PK_ESPECIALISTA_FITNESS.MO_RUTINAS_EJEMPLO(999999, 'Nombre', 'Desc', 'Lunes', 45, 'Básico', 'Fuerza');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/

-- ERROR: Ejercicio de ejemplo con series negativas
DECLARE
    v_rutina NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> ERROR: Series con valor negativo <<<');
    SELECT MIN(id_rutina_ejemplo) INTO v_rutina FROM RutinasDeEjemplo WHERE ROWNUM = 1;
    INSERT INTO EjerciciosDeRutinasDeEjemplo (id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, descripcion, duracion_min)
    VALUES (v_rutina, 'Ejercicio Error', -5, 10, 'Desc', 5);
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('✓ Error capturado: ' || SUBSTR(SQLERRM, 1, 80));
END;
/
