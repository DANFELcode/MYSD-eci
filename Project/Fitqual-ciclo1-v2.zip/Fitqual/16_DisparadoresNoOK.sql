------------------
-- DisparadoresNoOK.sql
-- Intento de ingreso de datos erróneos protegidos por triggers
------------------

SET SERVEROUTPUT ON;

PROMPT '=== Violaciones de Triggers ===';

-- Preparar datos base
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('Preparando datos base...');
    
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_id FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
    VALUES (v_id, 'Usuario Triggers', 'triggers@test.com', 'pass123', 'Usuario');
    
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa) 
    VALUES (v_id, 'Básico', 22, 'F', 55.0, 1.60, '0');
    
    -- Feedback antiguo (más de 24 horas) para pruebas
    INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
    VALUES (v_id, 'Feedback antiguo', SYSDATE - 5, 3, 'Sistema', 'Público');
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('✓ Datos base creados');
    DBMS_OUTPUT.PUT_LINE('');
END;
/

------------------
-- 1. Violación: Modificar feedback >24 horas
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('1. Violación TR_BLOQUEAR_MODIFICACION_FEEDBACK');
    
    UPDATE Feedbacks 
    SET contenido = 'Intento modificar antiguo' 
    WHERE fecha < SYSDATE - 1;
    
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió bloquear modificación >24h');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 2. Violación: Fecha futura en Feedback
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('2. Violación TR_VALIDAR_FECHA_FEEDBACK');
    
    DECLARE
        v_usuario NUMBER;
    BEGIN
        SELECT u.id_persona INTO v_usuario 
        FROM Usuarios u
        JOIN Personas p ON u.id_persona = p.id_persona
        WHERE p.correo = 'triggers@test.com';
        
        INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
        VALUES (v_usuario, 'Feedback futuro', SYSDATE + 10, 5, 'Sistema', 'Público');
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar fecha futura');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 3. Violación: Fecha futura en Objetivo
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('3. Violación TR_VALIDAR_FECHA_OBJETIVO');
    
    DECLARE
        v_usuario NUMBER;
    BEGIN
        SELECT u.id_persona INTO v_usuario 
        FROM Usuarios u
        JOIN Personas p ON u.id_persona = p.id_persona
        WHERE p.correo = 'triggers@test.com';
        
        INSERT INTO Objetivos (usuario, nombre, contenido, fecha_creacion)
        VALUES (v_usuario, 'Objetivo futuro', 'Contenido', SYSDATE + 100);
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar fecha futura');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 4. Violación: Fecha futura en Progreso
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('4. Violación TR_VALIDAR_FECHA_PROGRESO');
    
    DECLARE
        v_usuario NUMBER;
    BEGIN
        SELECT u.id_persona INTO v_usuario 
        FROM Usuarios u
        JOIN Personas p ON u.id_persona = p.id_persona
        WHERE p.correo = 'triggers@test.com';
        
        INSERT INTO Progresos (usuario, peso_actual, fecha_registro)
        VALUES (v_usuario, 70.0, SYSDATE + 50);
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar fecha futura');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 5. Violación: Modificar usuario de un objetivo (inmutabilidad)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('5. Violación trg_objetivos_no_modificar (cambio usuario)');
    
    DECLARE
        v_usuario NUMBER;
        v_otro_usuario NUMBER;
        v_obj_id NUMBER;
    BEGIN
        SELECT u.id_persona INTO v_usuario 
        FROM Usuarios u
        JOIN Personas p ON u.id_persona = p.id_persona
        WHERE p.correo = 'triggers@test.com';
        
        INSERT INTO Objetivos (usuario, nombre, contenido, fecha_creacion)
        VALUES (v_usuario, 'Objetivo inmutable', 'Contenido', SYSDATE);
        
        SELECT MAX(id_objetivo) INTO v_obj_id FROM Objetivos WHERE usuario = v_usuario;
        
        SELECT MIN(id_persona) INTO v_otro_usuario 
        FROM Usuarios 
        WHERE id_persona != v_usuario;
        
        COMMIT;
        
        UPDATE Objetivos 
        SET usuario = v_otro_usuario
        WHERE id_objetivo = v_obj_id;
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar cambio de usuario');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 6. Violación: Modificar id_persona (inmutabilidad)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('6. Violación trg_personas_no_modificar');
    
    UPDATE Personas 
    SET id_persona = 999999
    WHERE correo = 'triggers@test.com';
    
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar cambio de ID');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 7. Violación: Modificar fecha_creacion de objetivo (inmutabilidad)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('7. Violación trg_objetivos_no_modificar (cambio fecha)');
    
    DECLARE
        v_obj_id NUMBER;
    BEGIN
        SELECT MIN(id_objetivo) INTO v_obj_id FROM Objetivos WHERE ROWNUM = 1;
        
        UPDATE Objetivos 
        SET fecha_creacion = SYSDATE - 100
        WHERE id_objetivo = v_obj_id;
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar cambio de fecha_creacion');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 8. Violación: Modificar especialista de recomendación (inmutabilidad)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('8. Violación trg_recomendaciones_no_modificar');
    
    DECLARE
        v_rec_id NUMBER;
        v_otro_esp NUMBER;
    BEGIN
        SELECT MIN(id_recomendacion) INTO v_rec_id FROM Recomendaciones WHERE ROWNUM = 1;
        SELECT MIN(id_persona) INTO v_otro_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
        
        UPDATE Recomendaciones 
        SET especialista_fitness = v_otro_esp
        WHERE id_recomendacion = v_rec_id;
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar cambio de especialista');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 9. Violación: Modificar especialista de rutina ejemplo (inmutabilidad)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('9. Violación trg_rutinasejemplo_no_modificar');
    
    DECLARE
        v_rutina_id NUMBER;
        v_otro_esp NUMBER;
    BEGIN
        SELECT MIN(id_rutina_ejemplo) INTO v_rutina_id FROM RutinasDeEjemplo WHERE ROWNUM = 1;
        SELECT MIN(id_persona) INTO v_otro_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
        
        UPDATE RutinasDeEjemplo 
        SET especialista_fitness = v_otro_esp
        WHERE id_rutina_ejemplo = v_rutina_id;
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar cambio de especialista');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

------------------
-- 10. Violación: Modificar id_objetivo (inmutabilidad)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('10. Violación trg_objetivos_no_modificar (cambio id_objetivo)');
    
    DECLARE
        v_obj_id NUMBER;
    BEGIN
        SELECT MIN(id_objetivo) INTO v_obj_id FROM Objetivos WHERE ROWNUM = 1;
        
        UPDATE Objetivos 
        SET id_objetivo = 999999
        WHERE id_objetivo = v_obj_id;
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar cambio de id_objetivo');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SUBSTR(SQLERRM, 1, 70));
        ROLLBACK;
END;
/

PROMPT '';
PROMPT '========================================';
PROMPT 'DisparadoresNoOK: 10 violaciones probadas';
PROMPT '========================================';