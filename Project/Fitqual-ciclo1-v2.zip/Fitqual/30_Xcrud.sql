-- --------------
--XCRUD
--Eliminación de los paquetes
-- -------------

-- Paquetes de Componentes 
DROP PACKAGE PK_PERSONAS;
DROP PACKAGE PK_PLANFITNESS;
DROP PACKAGE PK_ESPECIALISTA_FITNESS;
DROP PACKAGE PK_OBJETIVOS;


commit;