--==========================================
-- TuplasNoOK.sql
-- Ingreso de datos INCORRECTOS respecto a restricciones de tuplas
--==========================================

SET SERVEROUTPUT ON;

PROMPT '=== TuplasNoOK: Violaciones de restricciones de tuplas ===';

------------------
-- 1. USUARIOS: ck_usuario_membresia
-- Violación: membresia_activa='1' con fecha_fin <= fecha_inicio
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('1. Violación ck_usuario_membresia: fecha_fin <= fecha_inicio');
    
    DECLARE
        v_max NUMBER;
    BEGIN
        SELECT NVL(MAX(id_persona), 0) + 1 INTO v_max FROM Personas;
        
        INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
        VALUES (v_max, 'Usuario Mem Inválida', 'badmem@test.com', 'pass123', 'Usuario');
        
        -- Membresía ACTIVA con fechas FUTURAS pero fecha_fin < fecha_inicio
        INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura,
                             membresia_activa, fecha_inicio_membresia, fecha_fin_membresia)
        VALUES (v_max, 'Básico', 30, 'M', 70, 1.75,
                '1', SYSDATE + 100, SYSDATE + 50); -- fecha_fin < fecha_inicio (ambas futuras)
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar fechas incoherentes');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

------------------
-- 2. USUARIOS: ck_usuario_membresia
-- Violación: membresia_activa='1' sin fechas
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('2. Violación ck_usuario_membresia: activa sin fechas');
    
    DECLARE
        v_max NUMBER;
    BEGIN
        SELECT NVL(MAX(id_persona), 0) + 1 INTO v_max FROM Personas;
        
        INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
        VALUES (v_max, 'Usuario Sin Fechas', 'sinfechas@test.com', 'pass123', 'Usuario');
        
        -- Membresía ACTIVA pero sin ninguna fecha (ambas NULL)
        INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura,
                             membresia_activa, fecha_inicio_membresia, fecha_fin_membresia)
        VALUES (v_max, 'Básico', 30, 'M', 70, 1.75,
                '1', NULL, NULL);
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar membresía activa sin fechas');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

------------------
-- 3. RUTINAS: ck_rutina_nivel_dias
-- Violación: nivel_dificultad definido PERO dias_semana = NULL
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('3. Violación ck_rutina_nivel_dias: nivel sin días');
    
    DECLARE
        v_plan NUMBER;
    BEGIN
        SELECT MIN(id_plan) INTO v_plan FROM PlanesFitness WHERE ROWNUM = 1;
        
        INSERT INTO Rutinas (planfitness, nombre_rutina, descripcion,
                            dias_semana, nivel_dificultad)
        VALUES (v_plan, 'Rutina Inválida Test', 'Nivel sin días',
                NULL, 'Intermedio'); -- nivel definido pero días NULL
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar nivel sin días');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

------------------
-- 4. EJERCICIOS: ck_ejercicio_series_rep_duracion
-- Violación: solo series (sin repeticiones ni duración)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('4. Violación ck_ejercicio: solo series (combinación inválida)');
    
    DECLARE
        v_rutina NUMBER;
    BEGIN
        SELECT MIN(id_rutina) INTO v_rutina FROM Rutinas WHERE ROWNUM = 1;
        
        INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, 
                               series, repeticiones, duracion_min)
        VALUES (9999, v_rutina, 'Ejercicio Inválido A',
                3, NULL, NULL); -- Solo series, falta repeticiones o duración
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar combinación inválida');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

------------------
-- 5. EJERCICIOS: ck_ejercicio_series_rep_duracion
-- Violación: solo repeticiones (sin series ni duración)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('5. Violación ck_ejercicio: solo repeticiones (combinación inválida)');
    
    DECLARE
        v_rutina NUMBER;
    BEGIN
        SELECT MIN(id_rutina) INTO v_rutina FROM Rutinas WHERE ROWNUM = 1;
        
        INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio,
                               series, repeticiones, duracion_min)
        VALUES (9999, v_rutina, 'Ejercicio Inválido B',
                NULL, 10, NULL); -- Solo repeticiones, falta series
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar combinación inválida');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

------------------
-- 6. EJERCICIOS: ck_ejercicio_series_rep_duracion
-- Violación: todos NULL (ningún parámetro de entrenamiento)
------------------
BEGIN
    DBMS_OUTPUT.PUT_LINE('6. Violación ck_ejercicio: todos NULL (sin parámetros)');
    
    DECLARE
        v_rutina NUMBER;
    BEGIN
        SELECT MIN(id_rutina) INTO v_rutina FROM Rutinas WHERE ROWNUM = 1;
        
        INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio,
                               series, repeticiones, duracion_min)
        VALUES (9999, v_rutina, 'Ejercicio Inválido C',
                NULL, NULL, NULL); -- Todos NULL
        
        DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar ejercicio sin parámetros');
        ROLLBACK;
    END;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

