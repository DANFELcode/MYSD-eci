-------------------
--XPoblar
--Eliminación de datos
-------------------


DELETE FROM EjerciciosDeRutinasDeEjemplo;
DELETE FROM ObjetivosRecomendaciones;
DELETE FROM PlanesFitnessDeUsuarios;
DELETE FROM Ejercicios;
DELETE FROM Comidas;
DELETE FROM Habitos;
DELETE FROM Rutinas;
DELETE FROM RutinasDeEjemplo;
DELETE FROM Recomendaciones;
DELETE FROM Feedbacks;
DELETE FROM Progresos;
DELETE FROM Objetivos;
DELETE FROM PlanesFitness;
DELETE FROM Usuarios;
DELETE FROM EspecialistasFitness;
DELETE FROM Personas;

COMMIT;