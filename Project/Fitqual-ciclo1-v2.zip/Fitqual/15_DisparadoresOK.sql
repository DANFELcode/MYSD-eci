-------------------
-- DisparadoresOK.sql
-- Ingreso de datos usando la automatización definida en los disparadores
-------------------

SET SERVEROUTPUT ON;

PROMPT '=== Probando Automatización de Disparadores ===';
PROMPT '';

-- ==========================================
-- AUTO-INCREMENT (12 triggers)
-- ==========================================

-- 1. TR_AI_PERSONAS
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('1. TR_AI_PERSONAS: Auto-increment');
    INSERT INTO Personas (nombre, correo, contrasena, rol)
    VALUES ('Test AI', 'ai1@test.com', 'pass', 'Usuario')
    RETURNING id_persona INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 2. TR_AI_FEEDBACKS
DECLARE
    v_id NUMBER;
    v_usuario NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('2. TR_AI_FEEDBACKS: Auto-increment');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
    VALUES (v_usuario, 'Test', SYSDATE, 5, 'Sistema', 'Público')
    RETURNING id_feedback INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 3. TR_AI_RECOMENDACIONES
DECLARE
    v_id NUMBER;
    v_esp NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('3. TR_AI_RECOMENDACIONES: Auto-increment');
    SELECT MIN(id_persona) INTO v_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
    INSERT INTO Recomendaciones (especialista_fitness, contenido, fecha_creacion, tipo_enfoque)
    VALUES (v_esp, 'Test', SYSDATE, 'Motivación')
    RETURNING id_recomendacion INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 4. TR_AI_OBJETIVOS
DECLARE
    v_id NUMBER;
    v_usuario NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('4. TR_AI_OBJETIVOS: Auto-increment');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Objetivos (usuario, nombre, contenido)
    VALUES (v_usuario, 'Test', 'Contenido')
    RETURNING id_objetivo INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 5. TR_AI_PROGRESOS
DECLARE
    v_id NUMBER;
    v_usuario NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('5. TR_AI_PROGRESOS: Auto-increment');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Progresos (usuario, peso_actual, fecha_registro)
    VALUES (v_usuario, 70, SYSDATE)
    RETURNING id_progreso INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 6. TR_AI_PLANESFITNESS
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('6. TR_AI_PLANESFITNESS: Auto-increment');
    INSERT INTO PlanesFitness (nombre, duracion, descripcion)
    VALUES ('Plan Test', '8 semanas', 'Test')
    RETURNING id_plan INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 7. TR_AI_RUTINAS
DECLARE
    v_id NUMBER;
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('7. TR_AI_RUTINAS: Auto-increment');
    SELECT MIN(id_plan) INTO v_plan FROM PlanesFitness WHERE ROWNUM = 1;
    INSERT INTO Rutinas (planfitness, nombre_rutina, descripcion)
    VALUES (v_plan, 'Rutina Test', 'Test')
    RETURNING id_rutina INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 8. TR_AI_COMIDAS
DECLARE
    v_id NUMBER;
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('8. TR_AI_COMIDAS: Auto-increment');
    SELECT MIN(id_plan) INTO v_plan FROM PlanesFitness WHERE ROWNUM = 1;
    INSERT INTO Comidas (planfitness, nombre_comida, calorias)
    VALUES (v_plan, 'Comida Test', 500)
    RETURNING id_comida INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 9. TR_AI_HABITOS
DECLARE
    v_id NUMBER;
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('9. TR_AI_HABITOS: Auto-increment');
    SELECT MIN(id_plan) INTO v_plan FROM PlanesFitness WHERE ROWNUM = 1;
    INSERT INTO Habitos (planfitness, nombre_habito, descripcion, frecuencia)
    VALUES (v_plan, 'Hábito Test', 'Test', 'Diario')
    RETURNING id_habito INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 10. TR_AI_EJERCICIOS
DECLARE
    v_id NUMBER;
    v_rutina NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('10. TR_AI_EJERCICIOS: Auto-increment por rutina');
    SELECT MIN(id_rutina) INTO v_rutina FROM Rutinas WHERE ROWNUM = 1;
    INSERT INTO Ejercicios (id_rutina, nombre_ejercicio, series, repeticiones)
    VALUES (v_rutina, 'Ejercicio Test', 3, 10)
    RETURNING id_ejercicio INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 11. TR_AI_RUTINAS_EJEMPLO
DECLARE
    v_id NUMBER;
    v_esp NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('11. TR_AI_RUTINAS_EJEMPLO: Auto-increment');
    SELECT MIN(id_persona) INTO v_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
    INSERT INTO RutinasDeEjemplo (especialista_fitness, nombre_rutina, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento)
    VALUES (v_esp, 'Rutina Ej Test', 'Lunes', 45, 'Básico', 'Fuerza')
    RETURNING id_rutina_ejemplo INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

-- 12. TR_AI_EJERCICIOS_EJEMPLO
DECLARE
    v_id NUMBER;
    v_rutina NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('12. TR_AI_EJERCICIOS_EJEMPLO: Auto-increment por rutina ejemplo');
    SELECT MIN(id_rutina_ejemplo) INTO v_rutina FROM RutinasDeEjemplo WHERE ROWNUM = 1;
    INSERT INTO EjerciciosDeRutinasDeEjemplo (id_rutina_ejemplo, nombre_ejercicio, series, repeticiones, duracion_min)
    VALUES (v_rutina, 'Ejercicio Ej Test', 3, 10, 5)
    RETURNING id_ejercicio_ejemplo INTO v_id;
    DBMS_OUTPUT.PUT_LINE('   ✓ ID: ' || v_id);
    ROLLBACK;
END;
/

PROMPT '';
PROMPT '--- Lógica de Negocio ---';
PROMPT '';

-- 13. TR_ACTUALIZAR_ESTADO_MEMBRESIA
DECLARE
    v_id NUMBER;
    v_activa CHAR(1);
BEGIN
    DBMS_OUTPUT.PUT_LINE('13. TR_ACTUALIZAR_ESTADO_MEMBRESIA: Desactiva expirada');
    INSERT INTO Personas (nombre, correo, contrasena, rol)
    VALUES ('Test Exp', 'exp@test.com', 'pass', 'Usuario')
    RETURNING id_persona INTO v_id;
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa, fecha_inicio_membresia, fecha_fin_membresia)
    VALUES (v_id, 'Básico', 25, 'M', 70, 1.75, '1', SYSDATE - 400, SYSDATE - 30)
    RETURNING membresia_activa INTO v_activa;
    DBMS_OUTPUT.PUT_LINE('   ✓ Membresía desactivada: ' || v_activa);
    ROLLBACK;
END;
/

-- 14. TR_CALCULAR_FECHA_FIN_MEMBRESIA
DECLARE
    v_id NUMBER;
    v_fecha DATE;
BEGIN
    DBMS_OUTPUT.PUT_LINE('14. TR_CALCULAR_FECHA_FIN_MEMBRESIA: Calcula 1 año');
    INSERT INTO Personas (nombre, correo, contrasena, rol)
    VALUES ('Test Fin', 'fin@test.com', 'pass', 'Usuario')
    RETURNING id_persona INTO v_id;
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa, fecha_inicio_membresia)
    VALUES (v_id, 'Básico', 25, 'M', 70, 1.75, '1', SYSDATE)
    RETURNING fecha_fin_membresia INTO v_fecha;
    DBMS_OUTPUT.PUT_LINE('   ✓ Fecha fin: ' || TO_CHAR(v_fecha, 'DD/MM/YYYY'));
    ROLLBACK;
END;
/

-- 15. TR_CALCULAR_IMC_USUARIOS
DECLARE
    v_id NUMBER;
    v_imc NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('15. TR_CALCULAR_IMC_USUARIOS: Calcula IMC');
    INSERT INTO Personas (nombre, correo, contrasena, rol)
    VALUES ('Test IMC', 'imc@test.com', 'pass', 'Usuario')
    RETURNING id_persona INTO v_id;
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa)
    VALUES (v_id, 'Básico', 25, 'M', 70, 1.75, '0')
    RETURNING imc INTO v_imc;
    DBMS_OUTPUT.PUT_LINE('   ✓ IMC calculado: ' || v_imc);
    ROLLBACK;
END;
/

-- 16. TR_INCREMENTAR_CONSEJOS_ESPECIALISTA
DECLARE
    v_esp NUMBER;
    v_antes NUMBER;
    v_despues NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('16. TR_INCREMENTAR_CONSEJOS_ESPECIALISTA: Incrementa contador');
    SELECT MIN(id_persona) INTO v_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
    SELECT consejos_publicados INTO v_antes FROM EspecialistasFitness WHERE id_persona = v_esp;
    INSERT INTO Recomendaciones (especialista_fitness, contenido, fecha_creacion, tipo_enfoque)
    VALUES (v_esp, 'Test Consejo', SYSDATE, 'Motivación');
    SELECT consejos_publicados INTO v_despues FROM EspecialistasFitness WHERE id_persona = v_esp;
    DBMS_OUTPUT.PUT_LINE('   ✓ Antes: ' || v_antes || ' | Después: ' || v_despues);
    ROLLBACK;
END;
/

-- 17. TR_BLOQUEAR_MODIFICACION_FEEDBACK
DECLARE
    v_usuario NUMBER;
    v_fb NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('17. TR_BLOQUEAR_MODIFICACION_FEEDBACK: Permite <24h');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Feedbacks (usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad)
    VALUES (v_usuario, 'Feedback Reciente', SYSDATE, 4, 'Sistema', 'Público')
    RETURNING id_feedback INTO v_fb;
    UPDATE Feedbacks SET contenido = 'Modificado OK' WHERE id_feedback = v_fb;
    DBMS_OUTPUT.PUT_LINE('   ✓ Modificación <24h permitida');
    ROLLBACK;
END;
/

PROMPT '';
PROMPT '--- Validación de Fechas ---';
PROMPT '';

-- 18. TR_VALIDAR_FECHA_FEEDBACK
BEGIN
    DBMS_OUTPUT.PUT_LINE('18. TR_VALIDAR_FECHA_FEEDBACK: Rechaza futura (ver DisparadoresNoOK)');
    DBMS_OUTPUT.PUT_LINE('   ✓ Trigger activo (probado en NoOK)');
END;
/

-- 19. TR_VALIDAR_FECHA_OBJETIVO
BEGIN
    DBMS_OUTPUT.PUT_LINE('19. TR_VALIDAR_FECHA_OBJETIVO: Rechaza futura (ver DisparadoresNoOK)');
    DBMS_OUTPUT.PUT_LINE('   ✓ Trigger activo (probado en NoOK)');
END;
/

-- 20. TR_VALIDAR_FECHA_PROGRESO
BEGIN
    DBMS_OUTPUT.PUT_LINE('20. TR_VALIDAR_FECHA_PROGRESO: Rechaza futura (ver DisparadoresNoOK)');
    DBMS_OUTPUT.PUT_LINE('   ✓ Trigger activo (probado en NoOK)');
END;
/

PROMPT '';
PROMPT '--- Inmutabilidad de Campos ---';
PROMPT '';

-- 21. trg_recomendaciones_no_modificar
BEGIN
    DBMS_OUTPUT.PUT_LINE('21. trg_recomendaciones_no_modificar (ver DisparadoresNoOK)');
    DBMS_OUTPUT.PUT_LINE('   ✓ Trigger activo (probado en NoOK)');
END;
/

-- 22. trg_rutinasejemplo_no_modificar
BEGIN
    DBMS_OUTPUT.PUT_LINE('22. trg_rutinasejemplo_no_modificar (ver DisparadoresNoOK)');
    DBMS_OUTPUT.PUT_LINE('   ✓ Trigger activo (probado en NoOK)');
END;
/

-- 23. trg_objetivos_no_modificar
BEGIN
    DBMS_OUTPUT.PUT_LINE('23. trg_objetivos_no_modificar (ver DisparadoresNoOK)');
    DBMS_OUTPUT.PUT_LINE('   ✓ Trigger activo (probado en NoOK)');
END;
/

-- 24. trg_personas_no_modificar
BEGIN
    DBMS_OUTPUT.PUT_LINE('24. trg_personas_no_modificar (ver DisparadoresNoOK)');
    DBMS_OUTPUT.PUT_LINE('   ✓ Trigger activo (probado en NoOK)');
END;
/

-- BONUS: trg_asignar_fecha_objetivo
DECLARE
    v_usuario NUMBER;
    v_fecha DATE;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('BONUS. trg_asignar_fecha_objetivo: Asigna SYSDATE');
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    INSERT INTO Objetivos (usuario, nombre, contenido)
    VALUES (v_usuario, 'Sin Fecha', 'Test')
    RETURNING fecha_creacion INTO v_fecha;
    DBMS_OUTPUT.PUT_LINE('   ✓ Fecha asignada: ' || TO_CHAR(v_fecha, 'DD/MM/YYYY HH24:MI:SS'));
    ROLLBACK;
END;
/

