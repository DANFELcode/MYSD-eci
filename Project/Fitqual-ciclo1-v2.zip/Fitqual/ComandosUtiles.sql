--Saber todas las claves primarias que hay junto con su columna

SELECT 
    ut.table_name,
    uc.constraint_name AS primary_key_name,
    ucc.column_name AS primary_key_column,
    ut.num_rows,
    ut.last_analyzed
FROM user_tables ut
LEFT JOIN user_constraints uc ON ut.table_name = uc.table_name AND uc.constraint_type = 'P'
LEFT JOIN user_cons_columns ucc ON uc.constraint_name = ucc.constraint_name
ORDER BY ut.table_name;

-- Ver todas las tablas de tu usuario actual
SELECT table_name 
FROM user_tables 
ORDER BY table_name;

-- ============================================
-- SCRIPT COMPLETO DE LIMPIEZA PARA ORACLE
-- Elimina TODOS los objetos de tu esquema/usuario
-- ============================================

SET SERVEROUTPUT ON;
ALTER SESSION SET NLS_LANGUAGE='SPANISH';

BEGIN
  DBMS_OUTPUT.PUT_LINE('========================================');
  DBMS_OUTPUT.PUT_LINE('LIMPIANDO ESQUEMA ORACLE COMPLETAMENTE');
  DBMS_OUTPUT.PUT_LINE('Usuario: ' || USER);
  DBMS_OUTPUT.PUT_LINE('========================================');
END;
/

-- ============================================
-- 1. DESACTIVAR CONSTRAINTS DE REFERENCIA PRIMERO
-- ============================================
BEGIN
  FOR c IN (SELECT table_name, constraint_name 
            FROM user_constraints 
            WHERE constraint_type = 'R') LOOP
    BEGIN
      EXECUTE IMMEDIATE 'ALTER TABLE ' || c.table_name || 
                       ' DISABLE CONSTRAINT ' || c.constraint_name;
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
  END LOOP;
END;
/

-- ============================================
-- 2. ELIMINAR EN ORDEN DE DEPENDENCIAS
-- ============================================
DECLARE
  TYPE obj_type IS RECORD (
    nombre VARCHAR2(128),
    tipo VARCHAR2(30)
  );
  
  TYPE obj_list IS TABLE OF obj_type;
  
  objetos obj_list := obj_list();
  
  v_counter NUMBER := 0;
BEGIN
  -- 2.1 Recopilar TODOS los objetos en orden correcto
  SELECT object_name, object_type
  BULK COLLECT INTO objetos
  FROM user_objects
  WHERE object_type NOT IN ('INDEX', 'LOB', 'TABLE PARTITION', 'INDEX PARTITION')
  AND object_name NOT LIKE 'BIN$%'  -- Excluir objetos en papelera
  AND object_name NOT LIKE 'SYS_%'  -- Excluir objetos del sistema
  ORDER BY CASE object_type
    -- Orden de eliminación: primero dependientes, luego independientes
    WHEN 'MATERIALIZED VIEW' THEN 1
    WHEN 'MATERIALIZED VIEW LOG' THEN 2
    WHEN 'JOB' THEN 3
    WHEN 'TRIGGER' THEN 4
    WHEN 'PROCEDURE' THEN 5
    WHEN 'FUNCTION' THEN 6
    WHEN 'PACKAGE BODY' THEN 7
    WHEN 'PACKAGE' THEN 8
    WHEN 'VIEW' THEN 9
    WHEN 'SEQUENCE' THEN 10
    WHEN 'SYNONYM' THEN 11
    WHEN 'TABLE' THEN 12  -- Las tablas al final
    ELSE 99
  END;
  
  -- 2.2 Eliminar objetos
  FOR i IN 1..objetos.COUNT LOOP
    BEGIN
      v_counter := v_counter + 1;
      
      -- Construir comando DROP según el tipo
      IF objetos(i).tipo = 'TABLE' THEN
        EXECUTE IMMEDIATE 'DROP TABLE "' || objetos(i).nombre || '" CASCADE CONSTRAINTS PURGE';
      ELSIF objetos(i).tipo IN ('VIEW', 'SEQUENCE', 'SYNONYM') THEN
        EXECUTE IMMEDIATE 'DROP ' || objetos(i).tipo || ' "' || objetos(i).nombre || '"';
      ELSE
        EXECUTE IMMEDIATE 'DROP ' || objetos(i).tipo || ' "' || objetos(i).nombre || '"';
      END IF;
      
      DBMS_OUTPUT.PUT_LINE('[' || v_counter || '] ✅ Eliminado ' || 
                          RPAD(objetos(i).tipo, 15) || ': ' || objetos(i).nombre);
      
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('[' || v_counter || '] ❌ Error con ' || 
                            objetos(i).tipo || ' ' || objetos(i).nombre || 
                            ': ' || SQLERRM);
    END;
  END LOOP;
  
  -- 2.3 Eliminar índices restantes
  FOR idx IN (SELECT index_name FROM user_indexes 
              WHERE index_type != 'LOB' 
              AND generated = 'N'
              AND index_name NOT LIKE 'SYS_%'
              AND index_name NOT LIKE 'BIN$%') LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP INDEX "' || idx.index_name || '"';
      DBMS_OUTPUT.PUT_LINE('[+] ✅ Índice: ' || idx.index_name);
    EXCEPTION
      WHEN OTHERS THEN NULL;
    END;
  END LOOP;
  
  DBMS_OUTPUT.PUT_LINE(CHR(10) || 'Total objetos procesados: ' || v_counter);
END;
/

-- ============================================
-- 3. VACIAR PAPELERA DE RECICLAJE DE ORACLE
-- ============================================
BEGIN
  -- Esto elimina permanentemente objetos en "RECYCLEBIN"
  EXECUTE IMMEDIATE 'PURGE RECYCLEBIN';
  DBMS_OUTPUT.PUT_LINE('✅ Papelera de reciclaje vaciada');
  
  -- Si tienes permisos DBA, también purgar la DBA_RECYCLEBIN
  BEGIN
    EXECUTE IMMEDIATE 'PURGE DBA_RECYCLEBIN';
    DBMS_OUTPUT.PUT_LINE('✅ Papelera DBA vaciada');
  EXCEPTION
    WHEN OTHERS THEN NULL;
  END;
END;
/

-- ============================================
-- 4. VERIFICACIÓN FINAL
-- ============================================
DECLARE
  v_tablas NUMBER;
  v_indices NUMBER;
  v_objetos_total NUMBER;
  v_espacio_mb NUMBER;
BEGIN
  -- Contar objetos restantes
  SELECT COUNT(*) INTO v_tablas FROM user_tables;
  SELECT COUNT(*) INTO v_indices FROM user_indexes WHERE index_name NOT LIKE 'SYS_%';
  SELECT COUNT(*) INTO v_objetos_total FROM user_objects;
  
  -- Espacio utilizado (opcional, necesita permisos)
  BEGIN
    SELECT SUM(bytes)/1024/1024 INTO v_espacio_mb
    FROM user_segments;
  EXCEPTION
    WHEN OTHERS THEN v_espacio_mb := 0;
  END;
  
  DBMS_OUTPUT.PUT_LINE(CHR(10) || '========================================');
  DBMS_OUTPUT.PUT_LINE('VERIFICACIÓN FINAL - ESQUEMA: ' || USER);
  DBMS_OUTPUT.PUT_LINE('========================================');
  DBMS_OUTPUT.PUT_LINE('Tablas restantes:           ' || v_tablas);
  DBMS_OUTPUT.PUT_LINE('Índices restantes:          ' || v_indices);
  DBMS_OUTPUT.PUT_LINE('Objetos totales restantes:  ' || v_objetos_total);
  DBMS_OUTPUT.PUT_LINE('Espacio utilizado (MB):     ' || ROUND(v_espacio_mb, 2));
  DBMS_OUTPUT.PUT_LINE('========================================');
  
  IF v_tablas = 0 AND v_objetos_total = 0 THEN
    DBMS_OUTPUT.PUT_LINE('✅ ESQUEMA COMPLETAMENTE VACÍO');
  ELSE
    DBMS_OUTPUT.PUT_LINE('⚠️  Objetos restantes encontrados');
    
    -- Mostrar objetos restantes
    FOR r IN (SELECT object_type, COUNT(*) as cnt, 
                     LISTAGG(object_name, ', ') WITHIN GROUP (ORDER BY object_name) as nombres
              FROM user_objects 
              GROUP BY object_type
              ORDER BY object_type) LOOP
      DBMS_OUTPUT.PUT_LINE('   ' || RPAD(r.object_type, 20) || ': ' || r.cnt || 
                          ' - ' || SUBSTR(r.nombres, 1, 100));
    END LOOP;
  END IF;
END;
/

-- ============================================
-- 5. RESET DE SECUENCIAS DEL SISTEMA (OPCIONAL)
-- ============================================
/*
-- Si quieres resetear contadores internos (solo desarrollo)
BEGIN
  -- Cerrar y abrir la base de datos (necesita DBA)
  -- EXECUTE IMMEDIATE 'ALTER SYSTEM CHECKPOINT';
  -- EXECUTE IMMEDIATE 'ALTER SYSTEM FLUSH BUFFER_CACHE';
  -- EXECUTE IMMEDIATE 'ALTER SYSTEM FLUSH SHARED_POOL';
  
  DBMS_OUTPUT.PUT_LINE('Sistema refrescado');
END;
/
*/

-- ============================================
-- SCRIPT DE VERIFICACIÓN RÁPIDA POST-LIMPIEZA
-- ============================================
PROMPT 
PROMPT ========================================
PROMPT VERIFICACIÓN MANUAL RÁPIDA:
PROMPT ========================================

COLUMN "TIPO DE OBJETO" FORMAT A25
COLUMN "CANTIDAD" FORMAT 999
COLUMN "EJEMPLOS" FORMAT A50

SELECT 
  object_type AS "TIPO DE OBJETO",
  COUNT(*) AS "CANTIDAD",
  LISTAGG(object_name, ', ') WITHIN GROUP (ORDER BY object_name) AS "EJEMPLOS"
FROM user_objects
GROUP BY object_type
ORDER BY object_type;

PROMPT 
PROMPT Tablas existentes:
SELECT table_name FROM user_tables ORDER BY table_name;

commit;

--- borrar crudes
-- Script para eliminar datos insertados por CRUDOK.sql
-- Ejecutar en orden inverso al de inserción (dependencias)

SET SERVEROUTPUT ON;

BEGIN
    DBMS_OUTPUT.PUT_LINE('===============================================');
    DBMS_OUTPUT.PUT_LINE('    ELIMINACIÓN DE DATOS DE PRUEBA');
    DBMS_OUTPUT.PUT_LINE('===============================================');
END;
/

-- =====================================================
-- ELIMINACIÓN EN ORDEN (DE DEPENDIENTES A PRINCIPALES)
-- =====================================================

-- 1. ELIMINAR EJERCICIOS DE RUTINAS DE EJEMPLO
BEGIN
    DELETE FROM EjerciciosDeRutinasDeEjemplo 
    WHERE nombre_ejercicio IN ('Sentadilla barra', 'Press banca', 'Burpees');
    DBMS_OUTPUT.PUT_LINE('✓ Ejercicios de rutinas de ejemplo eliminados');
END;
/

-- 2. ELIMINAR RUTINAS DE EJEMPLO
BEGIN
    DELETE FROM RutinasDeEjemplo 
    WHERE nombre_rutina LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Rutinas de ejemplo eliminadas');
END;
/

-- 3. ELIMINAR HÁBITOS
BEGIN
    DELETE FROM Habitos 
    WHERE nombre_habito LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Hábitos eliminados');
END;
/

-- 4. ELIMINAR COMIDAS
BEGIN
    DELETE FROM Comidas 
    WHERE nombre_comida LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Comidas eliminadas');
END;
/

-- 5. ELIMINAR EJERCICIOS
BEGIN
    DELETE FROM Ejercicios 
    WHERE nombre_ejercicio IN ('Caminata rápida', 'Trote suave', 'Sentadillas', 'Flexiones');
    DBMS_OUTPUT.PUT_LINE('✓ Ejercicios eliminados');
END;
/

-- 6. ELIMINAR RUTINAS
BEGIN
    DELETE FROM Rutinas 
    WHERE nombre_rutina LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Rutinas eliminadas');
END;
/

-- 7. ELIMINAR ASIGNACIONES DE PLANES A USUARIOS
BEGIN
    DELETE FROM PlanesFitnessDeUsuarios 
    WHERE comentario_usuario IN ('Comenzando mi plan', 'Plan perfecto para mi');
    DBMS_OUTPUT.PUT_LINE('✓ Asignaciones planes-usuarios eliminadas');
END;
/

-- 8. ELIMINAR RELACIONES OBJETIVOS-RECOMENDACIONES
BEGIN
    DELETE FROM ObjetivosRecomendaciones 
    WHERE id_recomendacion IN (
        SELECT id_recomendacion FROM Recomendaciones WHERE contenido LIKE '%Test%'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Relaciones objetivos-recomendaciones eliminadas');
END;
/

-- 9. ELIMINAR RECOMENDACIONES
BEGIN
    DELETE FROM Recomendaciones 
    WHERE contenido LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Recomendaciones eliminadas');
END;
/

-- 10. ELIMINAR OBJETIVOS
BEGIN
    DELETE FROM Objetivos 
    WHERE nombre LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Objetivos eliminados');
END;
/

-- 11. ELIMINAR PROGRESOS
BEGIN
    DELETE FROM Progresos 
    WHERE medidas LIKE '%Test%' OR medidas LIKE '%Pecho: 95cm%';
    DBMS_OUTPUT.PUT_LINE('✓ Progresos eliminados');
END;
/

-- 12. ELIMINAR FEEDBACKS
BEGIN
    DELETE FROM Feedbacks 
    WHERE contenido LIKE '%Test%' OR contenido LIKE '%Excelente aplicación%';
    DBMS_OUTPUT.PUT_LINE('✓ Feedbacks eliminados');
END;
/

-- 13. ELIMINAR PLANES FITNESS
BEGIN
    DELETE FROM PlanesFitness 
    WHERE nombre LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Planes fitness eliminados');
END;
/

-- 14. ELIMINAR USUARIOS
BEGIN
    DELETE FROM Usuarios 
    WHERE id_persona IN (
        SELECT id_persona FROM Personas WHERE nombre LIKE '%Test%'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Usuarios eliminados');
END;
/

-- 15. ELIMINAR ESPECIALISTAS FITNESS
BEGIN
    DELETE FROM EspecialistasFitness 
    WHERE id_persona IN (
        SELECT id_persona FROM Personas WHERE nombre LIKE '%Test%' AND rol = 'EspecialistaFitness'
    );
    DBMS_OUTPUT.PUT_LINE('✓ Especialistas fitness eliminados');
END;
/

-- 16. ELIMINAR PERSONAS
BEGIN
    DELETE FROM Personas 
    WHERE nombre LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('✓ Personas eliminadas');
END;
/

-- =====================================================
-- CONFIRMAR ELIMINACIÓN (CONSULTAS DE VERIFICACIÓN)
-- =====================================================

DECLARE
    v_count NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('>>> VERIFICANDO ELIMINACIÓN <<<');
    
    -- Verificar Personas
    SELECT COUNT(*) INTO v_count FROM Personas WHERE nombre LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('Personas con Test: ' || v_count);
    
    -- Verificar Usuarios de test
    SELECT COUNT(*) INTO v_count FROM Usuarios WHERE meta LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('Usuarios con Test: ' || v_count);
    
    -- Verificar Objetivos
    SELECT COUNT(*) INTO v_count FROM Objetivos WHERE nombre LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('Objetivos con Test: ' || v_count);
    
    -- Verificar Recomendaciones
    SELECT COUNT(*) INTO v_count FROM Recomendaciones WHERE contenido LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('Recomendaciones con Test: ' || v_count);
    
    -- Verificar Planes Fitness
    SELECT COUNT(*) INTO v_count FROM PlanesFitness WHERE nombre LIKE '%Test%';
    DBMS_OUTPUT.PUT_LINE('Planes con Test: ' || v_count);
    
    DBMS_OUTPUT.PUT_LINE('');
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('✅ TODOS LOS DATOS DE PRUEBA HAN SIDO ELIMINADOS');
    ELSE
        DBMS_OUTPUT.PUT_LINE('⚠️  QUEDAN ALGUNOS DATOS POR ELIMINAR');
    END IF;
END;
/

COMMIT;

BEGIN
    DBMS_OUTPUT.PUT_LINE('');
    DBMS_OUTPUT.PUT_LINE('===============================================');
    DBMS_OUTPUT.PUT_LINE('  ✓ ELIMINACIÓN COMPLETADA');
    DBMS_OUTPUT.PUT_LINE('===============================================');
END;


---borrar posibles datos insertados de CrudNoOK

-- Script de diagnóstico y limpieza para personas restantes
SET SERVEROUTPUT ON;

BEGIN
    DBMS_OUTPUT.PUT_LINE('===============================================');
    DBMS_OUTPUT.PUT_LINE('DIAGNÓSTICO Y LIMPIEZA DE PERSONAS RESTANTES');
    DBMS_OUTPUT.PUT_LINE('===============================================');
END;
/

-- 1. VER QUÉ PERSONAS QUEDAN CON 'TEST' EN EL NOMBRE
DECLARE
    CURSOR c_personas_test IS
        SELECT id_persona, nombre, correo, rol
        FROM Personas
        WHERE UPPER(nombre) LIKE '%TEST%'
           OR UPPER(nombre) LIKE '%ERROR%'
           OR UPPER(correo) LIKE '%TEST%'
        ORDER BY id_persona;
    
    v_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE('=== PERSONAS IDENTIFICADAS COMO DE PRUEBA ===');
    
    FOR rec IN c_personas_test LOOP
        DBMS_OUTPUT.PUT_LINE('ID: ' || rec.id_persona || 
                           ' | Nombre: ' || rec.nombre ||
                           ' | Correo: ' || rec.correo ||
                           ' | Rol: ' || rec.rol);
        v_count := v_count + 1;
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('Total encontradas: ' || v_count);
END;
/

-- 2. VERIFICAR SI HAY USUARIOS ASOCIADOS A ESTAS PERSONAS
DECLARE
    CURSOR c_personas_usadas IS
        SELECT p.id_persona, p.nombre,
               CASE 
                   WHEN u.id_persona IS NOT NULL THEN 'SÍ (Usuario)'
                   WHEN e.id_persona IS NOT NULL THEN 'SÍ (Especialista)'
                   WHEN f.usuario IS NOT NULL THEN 'SÍ (Feedback)'
                   ELSE 'NO'
               END as tiene_dependencias
        FROM Personas p
        LEFT JOIN Usuarios u ON p.id_persona = u.id_persona
        LEFT JOIN EspecialistasFitness e ON p.id_persona = e.id_persona
        LEFT JOIN Feedbacks f ON p.id_persona = f.usuario
        WHERE UPPER(p.nombre) LIKE '%TEST%'
           OR UPPER(p.nombre) LIKE '%ERROR%'
           OR UPPER(p.correo) LIKE '%TEST%';
    
    v_count NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE(chr(10) || '=== VERIFICACIÓN DE DEPENDENCIAS ===');
    
    FOR rec IN c_personas_usadas LOOP
        DBMS_OUTPUT.PUT_LINE('ID: ' || rec.id_persona || 
                           ' | Nombre: ' || rec.nombre ||
                           ' | Dependencias: ' || rec.tiene_dependencias);
        v_count := v_count + 1;
    END LOOP;
    
    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('No se encontraron personas con dependencias');
    END IF;
END;
/

-- 3. ELIMINAR EN ORDEN (PRIMERO DEPENDENCIAS, LUEGO PERSONAS)
DECLARE
    v_deleted NUMBER := 0;
BEGIN
    DBMS_OUTPUT.PUT_LINE(chr(10) || '=== INICIANDO ELIMINACIÓN ===');
    
    -- Primero eliminar dependencias de Feedbacks
    DELETE FROM Feedbacks 
    WHERE usuario IN (
        SELECT id_persona 
        FROM Personas 
        WHERE UPPER(nombre) LIKE '%TEST%'
           OR UPPER(nombre) LIKE '%ERROR%'
           OR UPPER(correo) LIKE '%TEST%'
    );
    v_deleted := SQL%ROWCOUNT;
    IF v_deleted > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Feedbacks eliminados: ' || v_deleted);
    END IF;
    
    -- Eliminar dependencias de ObjetivosRecomendaciones
    DELETE FROM ObjetivosRecomendaciones 
    WHERE id_recomendacion IN (
        SELECT id_recomendacion 
        FROM Recomendaciones 
        WHERE especialista_fitness IN (
            SELECT id_persona 
            FROM Personas 
            WHERE UPPER(nombre) LIKE '%TEST%'
               OR UPPER(nombre) LIKE '%ERROR%'
               OR UPPER(correo) LIKE '%TEST%'
        )
    );
    v_deleted := SQL%ROWCOUNT;
    IF v_deleted > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Relaciones Objetivos-Recomendaciones eliminadas: ' || v_deleted);
    END IF;
    
    -- Eliminar Recomendaciones
    DELETE FROM Recomendaciones 
    WHERE especialista_fitness IN (
        SELECT id_persona 
        FROM Personas 
        WHERE UPPER(nombre) LIKE '%TEST%'
           OR UPPER(nombre) LIKE '%ERROR%'
           OR UPPER(correo) LIKE '%TEST%'
    );
    v_deleted := SQL%ROWCOUNT;
    IF v_deleted > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Recomendaciones eliminadas: ' || v_deleted);
    END IF;
    
    -- Eliminar Objetivos
    DELETE FROM Objetivos 
    WHERE usuario IN (
        SELECT id_persona 
        FROM Personas 
        WHERE UPPER(nombre) LIKE '%TEST%'
           OR UPPER(nombre) LIKE '%ERROR%'
           OR UPPER(correo) LIKE '%TEST%'
    );
    v_deleted := SQL%ROWCOUNT;
    IF v_deleted > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Objetivos eliminados: ' || v_deleted);
    END IF;
    
    -- Eliminar Progresos
    DELETE FROM Progresos 
    WHERE usuario IN (
        SELECT id_persona 
        FROM Personas 
        WHERE UPPER(nombre) LIKE '%TEST%'
           OR UPPER(nombre) LIKE '%ERROR%'
           OR UPPER(correo) LIKE '%TEST%'
    );
    v_deleted := SQL%ROWCOUNT;
    IF v_deleted > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Progresos eliminados: ' || v_deleted);
    END IF;
    
    -- Eliminar Usuarios
    DELETE FROM Usuarios 
    WHERE id_persona IN (
        SELECT id_persona 
        FROM Personas 
        WHERE UPPER(nombre) LIKE '%TEST%'
           OR UPPER(nombre) LIKE '%ERROR%'
           OR UPPER(correo) LIKE '%TEST%'
    );
    v_deleted := SQL%ROWCOUNT;
    IF v_deleted > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Usuarios eliminados: ' || v_deleted);
    END IF;
    
    -- Eliminar EspecialistasFitness
    DELETE FROM EspecialistasFitness 
    WHERE id_persona IN (
        SELECT id_persona 
        FROM Personas 
        WHERE UPPER(nombre) LIKE '%TEST%'
           OR UPPER(nombre) LIKE '%ERROR%'
           OR UPPER(correo) LIKE '%TEST%'
    );
    v_deleted := SQL%ROWCOUNT;
    IF v_deleted > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Especialistas eliminados: ' || v_deleted);
    END IF;
    
    -- FINALMENTE: Eliminar las Personas
    DELETE FROM Personas 
    WHERE UPPER(nombre) LIKE '%TEST%'
       OR UPPER(nombre) LIKE '%ERROR%'
       OR UPPER(correo) LIKE '%TEST%';
    
    v_deleted := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE(chr(10) || 'Personas eliminadas: ' || v_deleted);
    
    COMMIT;
    
    -- Verificar resultado final
    IF v_deleted = 0 THEN
        DBMS_OUTPUT.PUT_LINE(chr(10) || '✅ No se encontraron más personas de prueba');
    ELSE
        DBMS_OUTPUT.PUT_LINE(chr(10) || '✅ Se eliminaron ' || v_deleted || ' personas de prueba');
    END IF;
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('❌ Error durante la eliminación: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 4. VERIFICACIÓN FINAL
DECLARE
    v_remaining NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_remaining
    FROM Personas
    WHERE UPPER(nombre) LIKE '%TEST%'
       OR UPPER(nombre) LIKE '%ERROR%'
       OR UPPER(correo) LIKE '%TEST%';
    
    DBMS_OUTPUT.PUT_LINE(chr(10) || '=== VERIFICACIÓN FINAL ===');
    DBMS_OUTPUT.PUT_LINE('Personas de prueba restantes: ' || v_remaining);
    
    IF v_remaining = 0 THEN
        DBMS_OUTPUT.PUT_LINE('✅ ¡LIMPIEZA COMPLETADA EXITOSAMENTE!');
    ELSE
        DBMS_OUTPUT.PUT_LINE('⚠️  Todavía quedan ' || v_remaining || ' personas de prueba');
        DBMS_OUTPUT.PUT_LINE('   Ejecute este script nuevamente');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.PUT_LINE(chr(10) || '===============================================');
    DBMS_OUTPUT.PUT_LINE('  PROCESO COMPLETADO');
    DBMS_OUTPUT.PUT_LINE('===============================================');
END;
/

-- Script para eliminar datos de DisparadoresOK.sql
-- Elimina en orden inverso al de inserción para respetar restricciones

SET SERVEROUTPUT ON;

BEGIN
    DBMS_OUTPUT.PUT_LINE('===============================================');
    DBMS_OUTPUT.PUT_LINE('ELIMINACIÓN DE DATOS DE DISPARADORESOK.SQL');
    DBMS_OUTPUT.PUT_LINE('===============================================');
END;
/

-- =====================================================
-- ELIMINACIÓN EN ORDEN (DE DEPENDIENTES A PRINCIPALES)
-- =====================================================

DECLARE
    v_deleted_count NUMBER := 0;
BEGIN
    -- 1. ELIMINAR EJERCICIOS DE RUTINAS DE EJEMPLO
    DELETE FROM EjerciciosDeRutinasDeEjemplo 
    WHERE nombre_ejercicio IN ('Press de banca', 'Remo con barra');
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Ejercicios de rutinas de ejemplo eliminados: ' || v_deleted_count);
    
    -- 2. ELIMINAR RUTINAS DE EJEMPLO
    DELETE FROM RutinasDeEjemplo 
    WHERE nombre_rutina = 'Push Pull Legs';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Rutinas de ejemplo eliminadas: ' || v_deleted_count);
    
    -- 3. ELIMINAR HÁBITOS
    DELETE FROM Habitos 
    WHERE nombre_habito = 'Hidratación adecuada';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Hábitos eliminados: ' || v_deleted_count);
    
    -- 4. ELIMINAR COMIDAS
    DELETE FROM Comidas 
    WHERE nombre_comida = 'Desayuno Proteico';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Comidas eliminadas: ' || v_deleted_count);
    
    -- 5. ELIMINAR EJERCICIOS
    DELETE FROM Ejercicios 
    WHERE nombre_ejercicio IN ('Jumping Jacks', 'Trote ligero');
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Ejercicios eliminados: ' || v_deleted_count);
    
    -- 6. ELIMINAR RUTINAS
    DELETE FROM Rutinas 
    WHERE nombre_rutina = 'Cardio Matutino';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Rutinas eliminadas: ' || v_deleted_count);
    
    -- 7. ELIMINAR PLANES FITNESS
    DELETE FROM PlanesFitness 
    WHERE nombre = 'Plan Definición Básica';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Planes fitness eliminados: ' || v_deleted_count);
    
    -- 8. ELIMINAR FEEDBACKS
    DELETE FROM Feedbacks 
    WHERE contenido = 'Los consejos del especialista han sido muy útiles';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Feedbacks eliminados: ' || v_deleted_count);
    
    -- 9. ELIMINAR PROGRESOS (2 registros)
    DELETE FROM Progresos 
    WHERE medidas IN ('Cintura: 78cm, Cadera: 98cm', 'Cintura: 76cm, Cadera: 96cm');
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Progresos eliminados: ' || v_deleted_count);
    
    -- 10. ELIMINAR OBJETIVOS
    DELETE FROM Objetivos 
    WHERE nombre = 'Bajar 8 kilos';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Objetivos eliminados: ' || v_deleted_count);
    
    -- 11. ELIMINAR RECOMENDACIONES (2 registros)
    DELETE FROM Recomendaciones 
    WHERE contenido LIKE '%proteína%' OR contenido LIKE '%Duerme al menos%';
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Recomendaciones eliminadas: ' || v_deleted_count);
    
    -- 12. ELIMINAR USUARIOS (Laura Martinez)
    DELETE FROM Usuarios 
    WHERE id_persona IN (
        SELECT id_persona FROM Personas WHERE correo = 'laura.m@email.com'
    );
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Usuarios eliminados: ' || v_deleted_count);
    
    -- 13. ELIMINAR ESPECIALISTAS FITNESS (Dr. Carlos Nutricion)
    DELETE FROM EspecialistasFitness 
    WHERE id_persona IN (
        SELECT id_persona FROM Personas WHERE correo = 'dr.carlos@fitqual.com'
    );
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Especialistas fitness eliminados: ' || v_deleted_count);
    
    -- 14. FINALMENTE: ELIMINAR PERSONAS
    DELETE FROM Personas 
    WHERE correo IN ('dr.carlos@fitqual.com', 'laura.m@email.com');
    v_deleted_count := SQL%ROWCOUNT;
    DBMS_OUTPUT.PUT_LINE('Personas eliminadas: ' || v_deleted_count);
    
    COMMIT;
    
    DBMS_OUTPUT.PUT_LINE(chr(10) || '✅ TODOS LOS DATOS DE DISPARADORESOK.SQL HAN SIDO ELIMINADOS');
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('❌ Error durante la eliminación: ' || SQLERRM);
        ROLLBACK;
        RAISE;
END;
/

-- =====================================================
-- VERIFICACIÓN DE ELIMINACIÓN
-- =====================================================

DECLARE
    v_personas_restantes NUMBER;
    v_usuarios_restantes NUMBER;
    v_especialistas_restantes NUMBER;
    v_recomendaciones_restantes NUMBER;
    v_planes_restantes NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE(chr(10) || '=== VERIFICANDO ELIMINACIÓN ===');
    
    -- Verificar Personas
    SELECT COUNT(*) INTO v_personas_restantes
    FROM Personas 
    WHERE correo IN ('dr.carlos@fitqual.com', 'laura.m@email.com');
    DBMS_OUTPUT.PUT_LINE('Personas restantes: ' || v_personas_restantes);
    
    -- Verificar Usuarios
    SELECT COUNT(*) INTO v_usuarios_restantes
    FROM Usuarios u
    JOIN Personas p ON u.id_persona = p.id_persona
    WHERE p.correo = 'laura.m@email.com';
    DBMS_OUTPUT.PUT_LINE('Usuarios restantes: ' || v_usuarios_restantes);
    
    -- Verificar Especialistas
    SELECT COUNT(*) INTO v_especialistas_restantes
    FROM EspecialistasFitness e
    JOIN Personas p ON e.id_persona = p.id_persona
    WHERE p.correo = 'dr.carlos@fitqual.com';
    DBMS_OUTPUT.PUT_LINE('Especialistas restantes: ' || v_especialistas_restantes);
    
    -- Verificar Recomendaciones
    SELECT COUNT(*) INTO v_recomendaciones_restantes
    FROM Recomendaciones 
    WHERE contenido LIKE '%proteína%' OR contenido LIKE '%Duerme al menos%';
    DBMS_OUTPUT.PUT_LINE('Recomendaciones restantes: ' || v_recomendaciones_restantes);
    
    -- Verificar Planes Fitness
    SELECT COUNT(*) INTO v_planes_restantes
    FROM PlanesFitness 
    WHERE nombre = 'Plan Definición Básica';
    DBMS_OUTPUT.PUT_LINE('Planes fitness restantes: ' || v_planes_restantes);
    
    IF v_personas_restantes = 0 AND v_usuarios_restantes = 0 AND 
       v_especialistas_restantes = 0 AND v_recomendaciones_restantes = 0 AND
       v_planes_restantes = 0 THEN
        DBMS_OUTPUT.PUT_LINE(chr(10) || '✅ VERIFICACIÓN COMPLETADA - TODOS LOS DATOS FUERON ELIMINADOS');
    ELSE
        DBMS_OUTPUT.PUT_LINE(chr(10) || '⚠️  ALGUNOS DATOS NO FUERON ELIMINADOS COMPLETAMENTE');
    END IF;
END;
/

BEGIN
    DBMS_OUTPUT.PUT_LINE(chr(10) || '===============================================');
    DBMS_OUTPUT.PUT_LINE('  PROCESO DE ELIMINACIÓN FINALIZADO');
    DBMS_OUTPUT.PUT_LINE('===============================================');
END;
/