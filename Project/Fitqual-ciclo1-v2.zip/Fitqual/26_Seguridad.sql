-- SeguridadOK.sql - Pruebas de seguridad y roles
SET SERVEROUTPUT ON;

PROMPT '=== Pruebas de Seguridad ===';

-- PA_GERENTE (rol GerenteFitness)
DECLARE
    v_cursor SYS_REFCURSOR;
BEGIN
    DBMS_OUTPUT.PUT_LINE('1. PA_GERENTE - Consultas de gerente');
    v_cursor := PA_GERENTE.CO_USUARIOS_ACTIVOS_MES();
    CLOSE v_cursor;
    DBMS_OUTPUT.PUT_LINE('   ✓ Usuarios activos consultado');
    
    v_cursor := PA_GERENTE.CO_SATISFACCION_GLOBAL_APLICACION();
    CLOSE v_cursor;
    DBMS_OUTPUT.PUT_LINE('   ✓ Satisfacción global consultada');
END;
/

-- PA_USUARIO (rol UsuarioApp)
DECLARE
    v_usuario NUMBER;
    v_obj NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('2. PA_USUARIO - Operaciones de usuario');
    
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    
    PA_USUARIO.AD_OBJETIVOS(v_usuario, 'Objetivo Seguridad', 'Test', SYSDATE);
    SELECT MAX(id_objetivo) INTO v_obj FROM Objetivos WHERE usuario = v_usuario;
    DBMS_OUTPUT.PUT_LINE('   ✓ Objetivo creado: ' || v_obj);
    
    PA_USUARIO.MO_OBJETIVOS(v_obj, 'Objetivo Modificado', 'Test modificado');
    DBMS_OUTPUT.PUT_LINE('   ✓ Objetivo modificado');
    
    PA_USUARIO.DEL_OBJETIVOS(v_obj);
    DBMS_OUTPUT.PUT_LINE('   ✓ Objetivo eliminado');
END;
/

-- PA_ADMINISTRADOR_APP (rol AdministradorAppFitness)
DECLARE
    v_id NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('3. PA_ADMINISTRADOR_APP - Operaciones admin');
    
    PA_ADMINISTRADOR_APP.AD_PERSONAS('Admin Test', 'admin@seg.com', 'pass', 'Usuario');
    SELECT MAX(id_persona) INTO v_id FROM Personas WHERE correo = 'admin@seg.com';
    DBMS_OUTPUT.PUT_LINE('   ✓ Persona creada: ' || v_id);
    
    PA_ADMINISTRADOR_APP.DEL_PERSONAS(v_id);
    DBMS_OUTPUT.PUT_LINE('   ✓ Persona eliminada');
END;
/

-- PA_ESPECIALISTA_FITNESS (rol EspecialistaFitness)
DECLARE
    v_esp NUMBER;
    v_rutina NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('4. PA_ESPECIALISTA_FITNESS - Operaciones especialista');
    
    SELECT MIN(id_persona) INTO v_esp FROM EspecialistasFitness WHERE ROWNUM = 1;
    
    PA_ESPECIALISTA_FITNESS.AD_RECOMENDACIONES(v_esp, 'Rec Seguridad', SYSDATE, 'Nutrición');
    SELECT MAX(id_recomendacion) INTO v_rutina FROM Recomendaciones WHERE especialista_fitness = v_esp;
    DBMS_OUTPUT.PUT_LINE('   ✓ Recomendación creada: ' || v_rutina);
    
    PA_ESPECIALISTA_FITNESS.DEL_RECOMENDACIONES(v_rutina);
    DBMS_OUTPUT.PUT_LINE('   ✓ Recomendación eliminada');
END;
/

-- Prueba con INSERT directo después de EXECUTE
DECLARE
    v_usuario NUMBER;
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('5. Prueba EXECUTE + INSERT');
    
    SELECT MIN(id_persona) INTO v_usuario FROM Usuarios WHERE ROWNUM = 1;
    
    -- EXECUTE del paquete
    PA_USUARIO.AD_PLANFITNESS('Plan Seguridad Test', '8 semanas', 'Descripción');
    
    -- INSERT relacionado
    SELECT MAX(id_plan) INTO v_plan FROM PlanesFitness WHERE nombre = 'Plan Seguridad Test';
    INSERT INTO PlanesFitnessDeUsuarios (usuario, planfitness, comentario_usuario)
    VALUES (v_usuario, v_plan, 'Test de seguridad');
    
    DBMS_OUTPUT.PUT_LINE('   ✓ Plan creado y asignado: ' || v_plan);
    
    -- Limpiar
    DELETE FROM PlanesFitnessDeUsuarios WHERE planfitness = v_plan;
    PA_USUARIO.DEL_PLANFITNESS(v_plan);
    DBMS_OUTPUT.PUT_LINE('   ✓ Limpieza completada');
END;
/

PROMPT '=== Pruebas de Seguridad Completadas ===';