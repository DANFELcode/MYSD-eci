--==========================================
-- TuplasOK.sql
-- Ingreso de datos CORRECTOS respecto a restricciones de tuplas
--==========================================

SET SERVEROUTPUT ON;

PROMPT '=== TuplasOK: Inserciones válidas ===';

-- Preparar datos base
DECLARE
    v_max_persona NUMBER;
    v_max_plan NUMBER;
BEGIN
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_max_persona FROM Personas;
    SELECT NVL(MAX(id_plan), 0) + 1 INTO v_max_plan FROM PlanesFitness;
    
    -- Persona base
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_max_persona, 'Test Tuplas OK', 'tuplas.ok@test.com', 'pass123', 'Usuario');
    
    -- Plan base
    INSERT INTO PlanesFitness (id_plan, nombre, duracion, descripcion)
    VALUES (v_max_plan, 'Plan Tuplas OK', '8 semanas', 'Plan para pruebas');
    
    DBMS_OUTPUT.PUT_LINE('Datos base creados: Persona ' || v_max_persona || ', Plan ' || v_max_plan);
END;
/

------------------
-- 1. USUARIOS: ck_usuario_membresia
------------------

-- ✓ Membresía ACTIVA con fechas correctas (fecha_fin > fecha_inicio)
DECLARE
    v_id NUMBER;
BEGIN
    SELECT NVL(MAX(id_persona), 0) INTO v_id FROM Personas;
    
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, 
                         membresia_activa, fecha_inicio_membresia, fecha_fin_membresia) 
    VALUES (v_id, 'Intermedio', 30, 'M', 75.5, 1.75, 
            '1', DATE '2024-01-01', DATE '2024-12-31');
    
    DBMS_OUTPUT.PUT_LINE('1. ✓ Usuario con membresía activa válida');
END;
/

-- ✓ Membresía INACTIVA (no requiere fechas)
DECLARE
    v_max NUMBER;
BEGIN
    SELECT NVL(MAX(id_persona), 0) + 1 INTO v_max FROM Personas;
    
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol)
    VALUES (v_max, 'Usuario Inactivo', 'inactivo.ok@test.com', 'pass123', 'Usuario');
    
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa) 
    VALUES (v_max, 'Básico', 25, 'F', 60.0, 1.65, '0');
    
    DBMS_OUTPUT.PUT_LINE('2. ✓ Usuario con membresía inactiva');
END;
/

------------------
-- 2. RUTINAS: ck_rutina_nivel_dias
------------------

-- ✓ Rutina con nivel Y días definidos
DECLARE
    v_max_rutina NUMBER;
    v_plan NUMBER;
BEGIN
    SELECT NVL(MAX(id_plan), 0) INTO v_plan FROM PlanesFitness;
    SELECT NVL(MAX(id_rutina), 0) + 1 INTO v_max_rutina FROM Rutinas;
    
    INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion, 
                        dias_semana, nivel_dificultad, tipo_entrenamiento)
    VALUES (v_max_rutina, v_plan, 'Rutina con nivel y días', 'Descripción',
            'Lunes, Miércoles', 'Básico', 'Fuerza');
    
    DBMS_OUTPUT.PUT_LINE('3. ✓ Rutina con nivel Y días definidos');
END;
/

-- ✓ Rutina sin nivel NI días (ambos NULL)
DECLARE
    v_max_rutina NUMBER;
    v_plan NUMBER;
BEGIN
    SELECT NVL(MAX(id_plan), 0) INTO v_plan FROM PlanesFitness;
    SELECT NVL(MAX(id_rutina), 0) + 1 INTO v_max_rutina FROM Rutinas;
    
    INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion)
    VALUES (v_max_rutina, v_plan, 'Rutina flexible', 'Sin días ni nivel fijos');
    
    DBMS_OUTPUT.PUT_LINE('4. ✓ Rutina sin nivel NI días');
END;
/

------------------
-- 3. EJERCICIOS: ck_ejercicio_series_rep_duracion
------------------

-- ✓ Solo series Y repeticiones (sin duración)
DECLARE
    v_rutina NUMBER;
    v_max_ej NUMBER;  
BEGIN
    SELECT id_rutina INTO v_rutina FROM Rutinas WHERE ROWNUM = 1;
    
    SELECT NVL(MAX(id_ejercicio), 0) + 1 INTO v_max_ej 
    FROM Ejercicios WHERE id_rutina = v_rutina;  
    
    
    INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones, descripcion)
    VALUES (v_max_ej, v_rutina, 'Sentadillas', 4, 12, 'Con barra');
    
    DBMS_OUTPUT.PUT_LINE('5. ✓ Ejercicio con series Y repeticiones');
END;
/

-- ✓ Solo duración (sin series ni repeticiones)
DECLARE
    v_rutina NUMBER;
    v_max NUMBER;
BEGIN
    SELECT id_rutina INTO v_rutina FROM Rutinas WHERE ROWNUM = 1;
    SELECT NVL(MAX(id_ejercicio), 0) + 1 INTO v_max FROM Ejercicios WHERE id_rutina = v_rutina;
    
    INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, duracion_min, descripcion)
    VALUES (v_max, v_rutina, 'Cardio continuo', 30, 'Correr en cinta');
    
    DBMS_OUTPUT.PUT_LINE('6. ✓ Ejercicio con solo duración');
END;
/

-- ✓ Series Y duración (sin repeticiones)
DECLARE
    v_rutina NUMBER;
    v_max NUMBER;
BEGIN
    SELECT id_rutina INTO v_rutina FROM Rutinas WHERE ROWNUM = 1;
    SELECT NVL(MAX(id_ejercicio), 0) + 1 INTO v_max FROM Ejercicios WHERE id_rutina = v_rutina;
    
    INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, duracion_min, descripcion)
    VALUES (v_max, v_rutina, 'Plancha', 3, 60, 'Mantener posición');
    
    DBMS_OUTPUT.PUT_LINE('7. ✓ Ejercicio con series Y duración');
END;
/

COMMIT;

PROMPT '';
PROMPT '========================================';
PROMPT 'TuplasOK: 7 casos válidos insertados';
PROMPT '========================================';
PROMPT '';
