----------------
--IndicesVistasOK
--Consultas que requieren los indices y las vistas definidos
----------------

-- 1. USUARIOS POR NIVEL (idx_usuarios_nivel)
-- Consulta fundamental para segmentación de usuarios
PROMPT ======================================
PROMPT CONSULTA 1: Usuarios por Nivel
PROMPT Índice: idx_usuarios_nivel
PROMPT ======================================
SELECT 
    p.nombre,
    u.nivel,
    u.edad,
    u.meta,
    u.frecuencia_entreno_semanal
FROM Usuarios u
JOIN Personas p ON u.id_persona = p.id_persona
WHERE u.nivel = 'Avanzado'
ORDER BY u.edad DESC
FETCH FIRST 10 ROWS ONLY;

-- 2. FEEDBACKS RECIENTES (idx_feedbacks_fecha)
-- Monitoreo de satisfacción del cliente en tiempo real
PROMPT ======================================
PROMPT CONSULTA 2: Feedbacks Recientes
PROMPT Índice: idx_feedbacks_fecha
PROMPT ======================================
SELECT 
    f.id_feedback,
    p.nombre AS usuario,
    f.contenido,
    f.fecha,
    f.calificacion,
    f.tipo_feedback,
    f.visibilidad
FROM Feedbacks f
JOIN Personas p ON f.usuario = p.id_persona
WHERE f.fecha >= SYSDATE - 30
ORDER BY f.fecha DESC
FETCH FIRST 15 ROWS ONLY;

-- 3. ANÁLISIS TEMPORAL DE PROGRESO (idx_progresos_fecha)
-- Tendencias de progreso agregadas por mes
PROMPT ======================================
PROMPT CONSULTA 3: Análisis Temporal de Progreso
PROMPT Índice: idx_progresos_fecha
PROMPT ======================================
SELECT 
    TO_CHAR(pr.fecha_registro, 'YYYY-MM') AS mes,
    COUNT(*) AS registros_progreso,
    ROUND(AVG(pr.peso_actual), 2) AS peso_promedio,
    ROUND(AVG(pr.porcentaje_grasa), 2) AS grasa_promedio,
    ROUND(AVG(pr.imc), 2) AS imc_promedio
FROM Progresos pr
WHERE pr.fecha_registro >= ADD_MONTHS(SYSDATE, -6)
GROUP BY TO_CHAR(pr.fecha_registro, 'YYYY-MM')
ORDER BY mes DESC;


-- 4. ESPECIALISTAS MÁS ACTIVOS (Vista: v_especialistas_con_estadisticas)
-- Ranking de especialistas por actividad y contribución
PROMPT ======================================
PROMPT CONSULTA 6: Especialistas Más Activos
PROMPT Vista: v_especialistas_con_estadisticas
PROMPT ======================================
SELECT 
    nombre,
    especialidad,
    consejos_publicados,
    total_rutinas_ejemplo,
    (consejos_publicados + total_rutinas_ejemplo) AS actividad_total
FROM v_especialistas_con_estadisticas
WHERE consejos_publicados > 0 OR total_rutinas_ejemplo > 0
ORDER BY actividad_total DESC
FETCH FIRST 10 ROWS ONLY;

-- 5. OBJETIVOS CON RECOMENDACIONES (Vista: v_objetivos_con_recomendaciones)
-- Sistema de seguimiento de objetivos con apoyo profesional
PROMPT ======================================
PROMPT CONSULTA 7: Objetivos con Recomendaciones
PROMPT Vista: v_objetivos_con_recomendaciones
PROMPT ======================================
SELECT 
    nombre_usuario,
    nombre_objetivo,
    fecha_creacion,
    contenido_recomendacion,
    tipo_enfoque,
    nombre_especialista
FROM v_objetivos_con_recomendaciones
WHERE id_recomendacion IS NOT NULL
ORDER BY fecha_creacion DESC
FETCH FIRST 20 ROWS ONLY;

-- 6. USUARIOS AVANZADOS CON PLANES (Combinada: Índice + Vista)
-- Perfil completo de usuarios  con sus planes asignados
PROMPT ======================================
PROMPT CONSULTA 8: Usuarios Avanzados con Planes Completos
PROMPT Índice: idx_usuarios_nivel + Vista: v_planes_fitness_detallados
PROMPT ======================================
SELECT 
    p.nombre AS usuario,
    u.nivel,
    u.meta,
    vpfd.nombre_plan,
    vpfd.total_rutinas,
    vpfd.total_comidas,
    vpfd.total_habitos
FROM Usuarios u
JOIN Personas p ON u.id_persona = p.id_persona
JOIN PlanesFitnessDeUsuarios pfu ON u.id_persona = pfu.usuario
JOIN v_planes_fitness_detallados vpfd ON pfu.planfitness = vpfd.id_plan
WHERE u.nivel = 'Avanzado'
  AND vpfd.total_rutinas > 0
ORDER BY vpfd.total_rutinas DESC
FETCH FIRST 15 ROWS ONLY;



-- 7. PROGRESO DE USUARIOS CON OBJETIVOS (Combinada: Múltiples índices + Vista)
-- Seguimiento integral: Objetivos + Progreso + Recomendaciones
PROMPT ======================================
PROMPT CONSULTA 10: Progreso de Usuarios con Objetivos
PROMPT Índice: idx_progresos_fecha + Vista: v_objetivos_con_recomendaciones
PROMPT ======================================
SELECT 
    vor.nombre_usuario,
    vor.nombre_objetivo,
    pr.peso_actual,
    pr.porcentaje_grasa,
    pr.imc,
    pr.fecha_registro,
    COUNT(DISTINCT vor.id_recomendacion) AS recomendaciones_asociadas
FROM v_objetivos_con_recomendaciones vor
JOIN Progresos pr ON vor.usuario = pr.usuario
WHERE pr.fecha_registro >= SYSDATE - 90
GROUP BY vor.nombre_usuario, vor.nombre_objetivo, vor.id_objetivo,
         pr.peso_actual, pr.porcentaje_grasa, pr.imc, pr.fecha_registro
ORDER BY pr.fecha_registro DESC
FETCH FIRST 20 ROWS ONLY;

PROMPT ======================================
PROMPT FIN DE CONSULTAS
PROMPT ======================================

