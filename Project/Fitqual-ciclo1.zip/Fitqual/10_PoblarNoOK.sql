------------------
-- POBLARNOOK.sql
-- Intento de ingreso de datos erróneos protegidos por:
-- - Tipos de datos
-- - Definición de nulidades
-- - Claves primarias, únicas y foráneas
------------------

SET SERVEROUTPUT ON;

----------------------------
-- VIOLACIONES TABLA PERSONAS
----------------------------

-- 1. Violación rol no válido
BEGIN
    DBMS_OUTPUT.PUT_LINE('1. Violación CHECK: rol inválido');
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            'Juan Error', 'juan.error@test.com', 'pass123', 'Administrador');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar rol inválido');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 2. Violación correo duplicado (UK)
BEGIN
    DBMS_OUTPUT.PUT_LINE('2. Violación UNIQUE: correo duplicado');
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            'Ana Duplicado', 
            (SELECT correo FROM Personas WHERE ROWNUM = 1), 
            'pass123', 'Usuario');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar correo duplicado');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 3. Violación formato correo
BEGIN
    DBMS_OUTPUT.PUT_LINE('3. Violación CHECK: formato correo inválido');
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            'Correo Malo', 'correoinvalido', 'pass123', 'Usuario');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar formato de correo');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 4. Violación nombre NULL
BEGIN
    DBMS_OUTPUT.PUT_LINE('4. Violación NOT NULL: nombre nulo');
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            NULL, 'noname@test.com', 'pass123', 'Usuario');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar nombre NULL');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 5. Violación PK duplicada
BEGIN
    DBMS_OUTPUT.PUT_LINE('5. Violación PK: id_persona duplicado');
    INSERT INTO Personas (id_persona, nombre, correo, contrasena, rol) 
    VALUES ((SELECT id_persona FROM Personas WHERE ROWNUM = 1), 
            'PK Duplicada', 'pkdup@test.com', 'pass123', 'Usuario');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar PK duplicada');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA USUARIOS
----------------------------

-- 6. Violación sexo no válido
BEGIN
    DBMS_OUTPUT.PUT_LINE('6. Violación CHECK: sexo inválido');
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            'Intermedio', 25, 'X', 70.5, 1.75, '1');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar sexo inválido');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 7. Violación edad fuera de rango
BEGIN
    DBMS_OUTPUT.PUT_LINE('7. Violación CHECK: edad < 10');
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            'Básico', 5, 'M', 80.0, 1.80, '1');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar edad fuera de rango');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 8. Violación peso fuera de rango
BEGIN
    DBMS_OUTPUT.PUT_LINE('8. Violación CHECK: peso < 30');
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            'Básico', 30, 'F', 10.0, 1.65, '1');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar peso fuera de rango');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 9. Violación nivel NULL
BEGIN
    DBMS_OUTPUT.PUT_LINE('9. Violación NOT NULL: nivel nulo');
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            NULL, 25, 'M', 70.0, 1.75, '1');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar nivel NULL');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 10. Violación FK - usuario que no existe en Personas
BEGIN
    DBMS_OUTPUT.PUT_LINE('10. Violación FK: id_persona no existe en Personas');
    INSERT INTO Usuarios (id_persona, nivel, edad, sexo, peso, altura, membresia_activa) 
    VALUES (999999, 'Básico', 25, 'M', 70.0, 1.75, '1');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar FK inexistente');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA ESPECIALISTASFITNESS
----------------------------

-- 11. Violación consejos_publicados negativo
BEGIN
    DBMS_OUTPUT.PUT_LINE('11. Violación CHECK: consejos_publicados < 0');
    INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados) 
    VALUES ((SELECT NVL(MAX(id_persona), 0) + 1 FROM Personas), 
            'Nutrición', 'Especialista', 'Trayectoria', -5);
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar número negativo');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 12. Violación FK - especialista que no existe
BEGIN
    DBMS_OUTPUT.PUT_LINE('12. Violación FK: id_persona no existe en Personas');
    INSERT INTO EspecialistasFitness (id_persona, especialidad, descripcion_perfil, trayectoria_profesional, consejos_publicados) 
    VALUES (999999, 'Entrenamiento', 'Descripción', 'Trayectoria', 2);
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar FK inexistente');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA FEEDBACKS
----------------------------

-- 13. Violación calificación fuera de rango
BEGIN
    DBMS_OUTPUT.PUT_LINE('13. Violación CHECK: calificacion > 5');
    INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
    VALUES ((SELECT NVL(MAX(id_feedback), 0) + 1 FROM Feedbacks), 
            (SELECT id_persona FROM Usuarios WHERE ROWNUM = 1),
            'Contenido', SYSDATE, 6, 'Sistema', 'Público');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar calificación > 5');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 14. Violación tipo_feedback no válido
BEGIN
    DBMS_OUTPUT.PUT_LINE('14. Violación CHECK: tipo_feedback inválido');
    INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
    VALUES ((SELECT NVL(MAX(id_feedback), 0) + 1 FROM Feedbacks),
            (SELECT id_persona FROM Usuarios WHERE ROWNUM = 1),
            'Contenido', SYSDATE, 4, 'Nutrición', 'Público');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar tipo_feedback inválido');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 15. Violación FK - usuario que no existe
BEGIN
    DBMS_OUTPUT.PUT_LINE('15. Violación FK: usuario no existe en Usuarios');
    INSERT INTO Feedbacks (id_feedback, usuario, contenido, fecha, calificacion, tipo_feedback, visibilidad) 
    VALUES ((SELECT NVL(MAX(id_feedback), 0) + 1 FROM Feedbacks),
            999999, 'Contenido', SYSDATE, 5, 'Sistema', 'Público');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar FK inexistente');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA PLANESFITNESS
----------------------------

-- 16. Violación UK - nombre duplicado
BEGIN
    DBMS_OUTPUT.PUT_LINE('16. Violación UNIQUE: nombre plan duplicado');
    INSERT INTO PlanesFitness (id_plan, nombre, duracion, descripcion) 
    VALUES ((SELECT NVL(MAX(id_plan), 0) + 1 FROM PlanesFitness),
            (SELECT nombre FROM PlanesFitness WHERE ROWNUM = 1),
            '12 semanas', 'Plan duplicado');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar nombre duplicado');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 17. Violación formato duración
BEGIN
    DBMS_OUTPUT.PUT_LINE('17. Violación CHECK: formato duración inválido');
    INSERT INTO PlanesFitness (id_plan, nombre, duracion, descripcion) 
    VALUES ((SELECT NVL(MAX(id_plan), 0) + 1 FROM PlanesFitness),
            'Plan Formato Malo', '3 años', 'Descripción');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar formato duración');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA RUTINAS
----------------------------

-- 18. Violación nivel_dificultad no válido
BEGIN
    DBMS_OUTPUT.PUT_LINE('18. Violación CHECK: nivel_dificultad inválido');
    INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion, nivel_dificultad) 
    VALUES ((SELECT NVL(MAX(id_rutina), 0) + 1 FROM Rutinas),
            (SELECT id_plan FROM PlanesFitness WHERE ROWNUM = 1),
            'Rutina Experimental', 'Descripción', 'Extremo');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar nivel inválido');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 19. Violación UK - nombre duplicado en mismo plan
DECLARE
    v_plan NUMBER;
    v_nombre VARCHAR2(100);
BEGIN
    DBMS_OUTPUT.PUT_LINE('19. Violación UNIQUE: nombre_rutina duplicado en mismo plan');
    
    SELECT planfitness, nombre_rutina INTO v_plan, v_nombre 
    FROM Rutinas WHERE ROWNUM = 1;
    
    INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion) 
    VALUES ((SELECT NVL(MAX(id_rutina), 0) + 1 FROM Rutinas),
            v_plan, v_nombre, 'Otra descripción');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar nombre duplicado');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 20. Violación FK - plan que no existe
BEGIN
    DBMS_OUTPUT.PUT_LINE('20. Violación FK: planfitness no existe');
    INSERT INTO Rutinas (id_rutina, planfitness, nombre_rutina, descripcion) 
    VALUES ((SELECT NVL(MAX(id_rutina), 0) + 1 FROM Rutinas),
            999999, 'Rutina Fantasma', 'Descripción');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar FK inexistente');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA COMIDAS
----------------------------

-- 21. Violación calorías fuera de rango
BEGIN
    DBMS_OUTPUT.PUT_LINE('21. Violación CHECK: calorias > 3000');
    INSERT INTO Comidas (id_comida, planfitness, nombre_comida, calorias) 
    VALUES ((SELECT NVL(MAX(id_comida), 0) + 1 FROM Comidas),
            (SELECT id_plan FROM PlanesFitness WHERE ROWNUM = 1),
            'Comida Extrema', 5000);
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar calorías > 3000');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 22. Violación carbohidratos negativo
BEGIN
    DBMS_OUTPUT.PUT_LINE('22. Violación CHECK: carbohidratos < 0');
    INSERT INTO Comidas (id_comida, planfitness, nombre_comida, carbohidratos) 
    VALUES ((SELECT NVL(MAX(id_comida), 0) + 1 FROM Comidas),
            (SELECT id_plan FROM PlanesFitness WHERE ROWNUM = 1),
            'Comida Negativa', -10.0);
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar carbohidratos negativos');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA EJERCICIOS
----------------------------

-- 23. Violación series cero
BEGIN
    DBMS_OUTPUT.PUT_LINE('23. Violación CHECK: series = 0');
    INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones) 
    VALUES ((SELECT NVL(MAX(id_ejercicio), 0) + 1 FROM Ejercicios),
            (SELECT id_rutina FROM Rutinas WHERE ROWNUM = 1),
            'Ejercicio Error', 0, 10);
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar series = 0');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 24. Violación FK - rutina que no existe
BEGIN
    DBMS_OUTPUT.PUT_LINE('24. Violación FK: id_rutina no existe');
    INSERT INTO Ejercicios (id_ejercicio, id_rutina, nombre_ejercicio, series, repeticiones) 
    VALUES (1, 999999, 'Ejercicio Fantasma', 3, 10);
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar FK inexistente');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLA RUTINASDEEJEMPLO
----------------------------

-- 25. Violación duración fuera de rango
BEGIN
    DBMS_OUTPUT.PUT_LINE('25. Violación CHECK: duracion_rutina > 500');
    INSERT INTO RutinasDeEjemplo (id_rutina_ejemplo, especialista_fitness, nombre_rutina, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento) 
    VALUES ((SELECT NVL(MAX(id_rutina_ejemplo), 0) + 1 FROM RutinasDeEjemplo),
            (SELECT id_persona FROM EspecialistasFitness WHERE ROWNUM = 1),
            'Rutina Larga', 'Lunes', 600, 'Intermedio', 'Fuerza');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar duración > 500');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 26. Violación FK - especialista que no existe
BEGIN
    DBMS_OUTPUT.PUT_LINE('26. Violación FK: especialista_fitness no existe');
    INSERT INTO RutinasDeEjemplo (id_rutina_ejemplo, especialista_fitness, nombre_rutina, dias_semana, duracion_rutina, nivel_dificultad, tipo_entrenamiento) 
    VALUES ((SELECT NVL(MAX(id_rutina_ejemplo), 0) + 1 FROM RutinasDeEjemplo),
            999999, 'Rutina Fantasma', 'Lunes', 45, 'Básico', 'Fuerza');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar FK inexistente');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

----------------------------
-- VIOLACIONES TABLAS INTERMEDIAS
----------------------------

-- 27. Violación PK duplicada en PlanesFitnessDeUsuarios
DECLARE
    v_usuario NUMBER;
    v_plan NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('27. Violación PK: combinación usuario+plan duplicada');
    
    SELECT usuario, planfitness INTO v_usuario, v_plan
    FROM PlanesFitnessDeUsuarios WHERE ROWNUM = 1;
    
    INSERT INTO PlanesFitnessDeUsuarios (usuario, planfitness, comentario_usuario) 
    VALUES (v_usuario, v_plan, 'Comentario duplicado');
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar PK duplicada');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/

-- 28. Violación FK en PlanesFitnessDeUsuarios
BEGIN
    DBMS_OUTPUT.PUT_LINE('28. Violación FK: usuario no existe');
    INSERT INTO PlanesFitnessDeUsuarios (usuario, planfitness) 
    VALUES (999999, (SELECT id_plan FROM PlanesFitness WHERE ROWNUM = 1));
    DBMS_OUTPUT.PUT_LINE('   ✗ ERROR: Debió rechazar FK inexistente');
    ROLLBACK;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('   ✓ CORRECTO: ' || SQLERRM);
        ROLLBACK;
END;
/


PROMPT '========================================';
PROMPT 'PRUEBAS DE PoblarNoOK COMPLETADAS';
